import MODELO.Personal;
import MODELO.ConexionBD;
import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

import java.net.URI;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static final String BASE_URI = "http://localhost:3000/api/";

    public static HttpServer startServer() {
        final ResourceConfig rc = new ResourceConfig()
        .packages("CONTROLADOR", "com.jojandev")
        .register(org.glassfish.jersey.jsonb.JsonBindingFeature.class);

        return GrizzlyHttpServerFactory.createHttpServer(URI.create(BASE_URI), rc);
    }

    public static void main(String[] args) {
        final HttpServer server = startServer();
        System.out.println("Servidor iniciado en " + BASE_URI);
    }   
}
