import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

import java.net.URI;

/**
 * Clase principal que arranca el servidor HTTP utilizando Grizzly y Jersey.
 */
public class Main {

    // URI base donde el servidor escucha las peticiones REST
    public static final String BASE_URI = "http://localhost:3000/api/";

    /**
     * Inicia y configura un HttpServer con recursos Jersey.
     *
     * @return instancia de HttpServer iniciada
     */
    public static HttpServer startServer() {
        // Configura Jersey para que busque recursos en los paquetes indicados
        final ResourceConfig rc = new ResourceConfig()
            .packages("CONTROLADOR", "com.jojandev")
            // Habilita Json-B para serializar y deserializar objetos JSON
            .register(org.glassfish.jersey.jsonb.JsonBindingFeature.class);

        // Crea el servidor Grizzly en la URI base usando la configuracion RC
        return GrizzlyHttpServerFactory.createHttpServer(
            URI.create(BASE_URI), 
            rc
        );
    }

    /**
     * Metodo principal de la aplicacion.
     * Inicia el servidor y muestra un mensaje en consola.
     *
     * @param args argumentos de linea de comandos (no usados)
     */
    public static void main(String[] args) {
        // Arranca el servidor HTTP
        final HttpServer server = startServer();
        // Informa en consola que el servidor esta corriendo
        System.out.println("Servidor iniciado en " + BASE_URI);
    }
}
