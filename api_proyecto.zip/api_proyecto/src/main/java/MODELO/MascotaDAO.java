/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

/**
 *
 * @author USUARIO
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MascotaDAO {

    public List<Mascota> getByClienteId(int idCliente) {
        List<Mascota> mascotas = new ArrayList<>();

        String sql = "SELECT * FROM mascotas WHERE id_cliente = ?";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idCliente);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Mascota m = new Mascota();
                    m.setId(rs.getInt("id"));
                    m.setId_cliente(rs.getInt("id_cliente"));
                    m.setNombre(rs.getString("nombre"));
                    m.setId_raza(rs.getInt("id_raza"));
                    m.setEdad_semanas(rs.getInt("edad_semanas"));
                    m.setSexo(rs.getString("sexo"));
                    m.setEstado_vital(rs.getString("estado_vital"));
                    mascotas.add(m);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return mascotas;
    }
}
