package modelo;

import MODELO.Cliente;
import MODELO.ClienteGetResponseDTO;
import MODELO.CrudDAO;
import MODELO.ICPGetResponseDTO;
import MODELO.InformacionClientesPersonal;
import MODELO.TipoDocumento;

/**
 * Clase utilitaria encargada de construir DTOs relacionados con Cliente.
 * Su propósito es separar la lógica de transformación de entidades a objetos de respuesta (DTOs),
 * manteniendo limpio el controlador.
 */
public class ClienteDtoBuilder {

    /**
     * Construye un ICPGetResponseDTO (InformacionClientesPersonal DTO para respuesta)
     * a partir del modelo de entidad InformacionClientesPersonal, incluyendo su TipoDocumento.
     *
     * @param info Objeto de entidad InformacionClientesPersonal (datos sin anidar)
     * @param dao DAO genérico para acceder a la base de datos
     * @return ICPGetResponseDTO con los datos completos y el objeto TipoDocumento anidado
     */
    public static ICPGetResponseDTO construirInfoDTO(InformacionClientesPersonal info, CrudDAO dao) {
        if (info == null) return null;

        // Se obtiene el TipoDocumento asociado al cliente por su id_tipo_documento
        TipoDocumento tipoDocumento = dao.getById(TipoDocumento.class, "tipos_documento", info.getIdTipoDocumento());
        if (tipoDocumento == null) return null;

        // Se crea y retorna el DTO con toda la información lista para enviar al frontend
        return new ICPGetResponseDTO(
            info.getId(),
            tipoDocumento,
            info.getNumeroDocumento(),
            info.getNombre(),
            info.getTelefono(),
            info.getCorreo(),
            info.getDireccion()
        );
    }

    /**
     * Construye un ClienteGetResponseDTO (DTO completo para enviar al frontend)
     * a partir del objeto Cliente, incluyendo la información personal anidada (ICPGetResponseDTO).
     *
     * @param cliente Objeto Cliente (contiene id y referencia a info)
     * @param dao DAO para obtener datos relacionados como InformacionClientesPersonal y TipoDocumento
     * @return ClienteGetResponseDTO completo o null si falta información asociada
     */
    public static ClienteGetResponseDTO construirClienteDTO(Cliente cliente, CrudDAO dao) {
        // Se obtiene la información personal del cliente
        InformacionClientesPersonal info = dao.getById(InformacionClientesPersonal.class, "informacion_clientes_personal", cliente.getId_info());

        // Se convierte esa info en su DTO correspondiente (con TipoDocumento anidado)
        ICPGetResponseDTO infoDTO = construirInfoDTO(info, dao);

        // Si hay datos válidos, se construye el DTO final del cliente
        if (infoDTO == null) return null;

        return new ClienteGetResponseDTO(cliente.getId(), infoDTO);
    }
}
