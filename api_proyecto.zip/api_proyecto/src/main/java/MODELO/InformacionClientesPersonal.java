package MODELO;

public class InformacionClientesPersonal {
    private int id;
    private int id_tipo_documento;
    private String numero_documento;
    private String nombre;
    private String telefono;
    private String correo;
    private String direccion;

    // Getters y Setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public int getIdTipoDocumento() {
        return id_tipo_documento;
    }
    public void setIdTipoDocumento(int idTipoDocumento) {
        this.id_tipo_documento = idTipoDocumento;
    }

    public String getNumeroDocumento() {
        return numero_documento;
    }
    public void setNumeroDocumento(String numeroDocumento) {
        this.numero_documento = numeroDocumento;
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}
