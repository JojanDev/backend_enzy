package MODELO;

/**
 * Modelo que representa la información de cliente asociada a un empleado.
 *  
 * Campos:
 * - id: identificador único de la información
 * - id_tipo_documento: clave foránea al tipo de documento
 * - numero_documento: número del documento de identificación
 * - nombre: nombre completo del cliente
 * - telefono: número de teléfono de contacto
 * - correo: dirección de correo electrónico
 * - direccion: dirección física
 */
public class InformacionClientesPersonal {

    /**
     * identificador único de la información de cliente
     */
    private int id;

    /**
     * clave foránea que referencia un TipoDocumento
     */
    private int id_tipo_documento;

    /**
     * número del documento de identificación del cliente
     */
    private String numero_documento;

    /**
     * nombre completo del cliente
     */
    private String nombre;

    /**
     * número de teléfono de contacto del cliente
     */
    private String telefono;

    /**
     * dirección de correo electrónico del cliente
     */
    private String correo;

    /**
     * dirección física del cliente
     */
    private String direccion;

    /**
     * Obtiene el identificador de esta información de cliente.
     *
     * @return valor de id
     */
    public int getId() {
        return id;
    }

    /**
     * Asigna el identificador de esta información de cliente.
     *
     * @param id nuevo valor de id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene la clave de tipo de documento asociada.
     *
     * @return valor de id_tipo_documento
     */
    public int getId_tipo_documento() {
        return id_tipo_documento;
    }

    /**
     * Asigna la clave de tipo de documento para esta información.
     *
     * @param id_tipo_documento nuevo valor de id_tipo_documento
     */
    public void setId_tipo_documento(int id_tipo_documento) {
        this.id_tipo_documento = id_tipo_documento;
    }

    /**
     * Obtiene el número de documento del cliente.
     *
     * @return valor de numero_documento
     */
    public String getNumero_documento() {
        return numero_documento;
    }

    /**
     * Asigna el número de documento del cliente.
     *
     * @param numero_documento nuevo valor de numero_documento
     */
    public void setNumero_documento(String numero_documento) {
        this.numero_documento = numero_documento;
    }

    /**
     * Obtiene el nombre completo del cliente.
     *
     * @return valor de nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Asigna el nombre completo del cliente.
     *
     * @param nombre nuevo valor de nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el teléfono de contacto del cliente.
     *
     * @return valor de telefono
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * Asigna el teléfono de contacto del cliente.
     *
     * @param telefono nuevo valor de telefono
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * Obtiene la dirección de correo electrónico del cliente.
     *
     * @return valor de correo
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * Asigna la dirección de correo electrónico del cliente.
     *
     * @param correo nuevo valor de correo
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    /**
     * Obtiene la dirección física del cliente.
     *
     * @return valor de direccion
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * Asigna la dirección física del cliente.
     *
     * @param direccion nuevo valor de direccion
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}
