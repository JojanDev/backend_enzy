package MODELO;

import java.time.LocalDateTime;

/**
 * Representa un antecedente médico de una mascota.
 * <p>
 * Cada objeto de esta clase almacena información sobre un evento médico o diagnóstico
 * relacionado con una mascota específica.
 * </p>
 * <p>
 * Incluye datos como título del antecedente, diagnóstico, fecha de creación y estado de actividad.
 * </p>
 * 
 * @author USUARIO
 */
public class Antecedente {

    /** Identificador único del antecedente (clave primaria). */
    private int id;

    /** Identificador de la mascota a la que pertenece el antecedente. */
    private int id_mascota;

    /** Título breve del antecedente (ej. "Otitis externa"). */
    private String titulo;

    /** Descripción detallada o diagnóstico asociado al antecedente. */
    private String diagnostico;

    /** Fecha y hora en que se creó el antecedente. */
    private LocalDateTime fecha_creado;

    /** Indica si el antecedente está activo o no. */
    private boolean activo;

    /**
     * Obtiene el estado de actividad del antecedente.
     * 
     * @return true si el antecedente está activo, false si no
     */
    public boolean isActivo() {
        return activo;
    }

    /**
     * Define el estado de actividad del antecedente.
     * 
     * @param activo true para marcar como activo, false para inactivo
     */
    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    /**
     * Obtiene el ID del antecedente.
     * 
     * @return identificador único del antecedente
     */
    public int getId() {
        return id;
    }

    /**
     * Establece el ID del antecedente.
     * 
     * @param id identificador único a asignar
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene el ID de la mascota asociada al antecedente.
     * 
     * @return ID de la mascota
     */
    public int getId_mascota() {
        return id_mascota;
    }

    /**
     * Establece el ID de la mascota asociada al antecedente.
     * 
     * @param id_mascota ID de la mascota
     */
    public void setId_mascota(int id_mascota) {
        this.id_mascota = id_mascota;
    }

    /**
     * Obtiene el título del antecedente.
     * 
     * @return título del antecedente
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * Establece el título del antecedente.
     * 
     * @param titulo título a asignar
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * Obtiene el diagnóstico o descripción del antecedente.
     * 
     * @return diagnóstico asociado
     */
    public String getDiagnostico() {
        return diagnostico;
    }

    /**
     * Establece el diagnóstico o descripción del antecedente.
     * 
     * @param diagnostico diagnóstico a asignar
     */
    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    /**
     * Obtiene la fecha y hora de creación del antecedente.
     * 
     * @return fecha de creación
     */
    public LocalDateTime getFecha_creado() {
        return fecha_creado;
    }

    /**
     * Establece la fecha y hora de creación del antecedente.
     * 
     * @param fecha_creado fecha y hora a asignar
     */
    public void setFecha_creado(LocalDateTime fecha_creado) {
        this.fecha_creado = fecha_creado;
    }
}
