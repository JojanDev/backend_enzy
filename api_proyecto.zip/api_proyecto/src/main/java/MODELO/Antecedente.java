package MODELO;

import java.time.LocalDateTime;

/**
 * Representa un antecedente médico de una mascota.
 * <p>
 * Cada objeto de esta clase almacena información sobre un evento médico o diagnóstico
 * relacionado con una mascota específica.
 * </p>
 * <p>
 * Incluye datos como título del antecedente, diagnóstico, fecha de creación y estado de actividad.
 * </p>
 * 
 * @author USUARIO
 */
public class Antecedente {

    /** Identificador único del antecedente (clave primaria). */
    private int id;

    /** Identificador de la mascota a la que pertenece el antecedente. */
    private int id_mascota;

    /** Título breve del antecedente (ej. "Otitis externa"). */
    private String titulo;

    /** Descripción detallada o diagnóstico asociado al antecedente. */
    private String diagnostico;

    /** Fecha y hora en que se creó el antecedente. */
    private LocalDateTime fecha_creado;

    /** Indica si el antecedente está activo o no. */
    private boolean activo;

    /**
     * Obtiene el estado de actividad del antecedente.
     *
     * @return true si el antecedente esta activo, false si esta inactivo
     */
    public boolean isActivo() {
        // devuelve el valor del campo 'activo' que indica si el antecedente esta activo
        return activo;
    }

    /**
     * Define el estado de actividad del antecedente.
     *
     * @param activo true para marcar el antecedente como activo, false para inactivo
     */
    public void setActivo(boolean activo) {
        // asigna el valor recibido al campo 'activo'
        this.activo = activo;
    }

    /**
     * Obtiene el identificador unico del antecedente.
     *
     * @return identificador unico del antecedente
     */
    public int getId() {
        // devuelve el valor del campo 'id'
        return id;
    }

    /**
     * Establece el identificador unico del antecedente.
     *
     * @param id identificador unico a asignar
     */
    public void setId(int id) {
        // asigna el valor recibido al campo 'id'
        this.id = id;
    }

    /**
     * Obtiene el identificador de la mascota asociada.
     *
     * @return identificador de la mascota
     */
    public int getId_mascota() {
        // devuelve el valor del campo 'id_mascota'
        return id_mascota;
    }

    /**
     * Establece el identificador de la mascota asociada.
     *
     * @param id_mascota identificador de la mascota a asignar
     */
    public void setId_mascota(int id_mascota) {
        // asigna el valor recibido al campo 'id_mascota'
        this.id_mascota = id_mascota;
    }

    /**
     * Obtiene el titulo breve del antecedente.
     *
     * @return titulo del antecedente
     */
    public String getTitulo() {
        // devuelve el valor del campo 'titulo'
        return titulo;
    }

    /**
     * Establece el titulo breve del antecedente.
     *
     * @param titulo titulo a asignar
     */
    public void setTitulo(String titulo) {
        // asigna el valor recibido al campo 'titulo'
        this.titulo = titulo;
    }

    /**
     * Obtiene el diagnostico o descripcion detallada del antecedente.
     *
     * @return diagnostico asociado al antecedente
     */
    public String getDiagnostico() {
        // devuelve el valor del campo 'diagnostico'
        return diagnostico;
    }

    /**
     * Establece el diagnostico o descripcion del antecedente.
     *
     * @param diagnostico diagnostico a asignar
     */
    public void setDiagnostico(String diagnostico) {
        // asigna el valor recibido al campo 'diagnostico'
        this.diagnostico = diagnostico;
    }

    /**
     * Obtiene la fecha y hora de creacion del antecedente.
     *
     * @return fecha y hora de creacion
     */
    public LocalDateTime getFecha_creado() {
        // devuelve el valor del campo 'fecha_creado'
        return fecha_creado;
    }

    /**
     * Establece la fecha y hora de creacion del antecedente.
     *
     * @param fecha_creado fecha y hora a asignar
     */
    public void setFecha_creado(LocalDateTime fecha_creado) {
        // asigna el valor recibido al campo 'fecha_creado'
        this.fecha_creado = fecha_creado;
    }

}
