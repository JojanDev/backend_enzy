/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author USUARIO
 */
public class MedicamentoTratamientoDAO {

    private Connection connection;

    public MedicamentoTratamientoDAO(Connection connection) {
        this.connection = connection;
    }

    /**
     * Soft delete de un medicamento en un tratamiento
     * @param idMedicamentoTratamiento ID del registro en medicamentos_tratamiento
     * @return true si se eliminó correctamente, false si no
     * @throws SQLException
     */
    public boolean eliminarMedicamentoTratamiento(int idMedicamentoTratamiento) throws SQLException {
        String sql = "UPDATE medicamentos_tratamiento SET activo = false WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idMedicamentoTratamiento);
            int filasAfectadas = stmt.executeUpdate();
            return filasAfectadas > 0;
        }
    }
}

