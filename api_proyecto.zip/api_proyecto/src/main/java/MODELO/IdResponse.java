package MODELO;

/**
 * Clase modelo para envolver un identificador en la respuesta.
 * Utilizada en endpoints que devuelven el ID de un recurso recien creado.
 */
public class IdResponse {

    /**
     * identificador del recurso
     */
    private int id;

    /**
     * Constructor que inicializa la instancia con el ID proporcionado.
     *
     * @param id identificador a retornar en la respuesta
     */
    public IdResponse(int id) {
        // asigna el parametro id al atributo id de la instancia
        this.id = id;
    }

    /**
     * Obtiene el identificador almacenado.
     *
     * @return valor del identificador
     */
    public int getId() {
        // retorna el valor del atributo id
        return id;
    }

    /**
     * Asigna un nuevo valor al identificador.
     *
     * @param id nuevo valor a establecer en el atributo id
     */
    public void setId(int id) {
        // actualiza el atributo id con el valor proporcionado
        this.id = id;
    }
}
