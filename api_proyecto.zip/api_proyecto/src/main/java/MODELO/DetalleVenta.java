package MODELO;

import java.math.BigDecimal;

/**
 * Representa un detalle de venta en el sistema. Cada detalle puede corresponder
 * a un producto, servicio o medicamento dentro de una venta específica.
 */
public class DetalleVenta {

    private int id;                   // ID del detalle (clave primaria)
    private int id_venta;             // ID de la venta a la que pertenece este detalle
    private Integer id_producto;      // ID del producto (puede ser null si es servicio o medicamento)
    private Integer id_servicio;      // ID del servicio (puede ser null si es producto o medicamento)
    private Integer id_medicamento;   // ID del medicamento (puede ser null si es producto o servicio)
    private int cantidad;             // Cantidad de unidades vendidas
    private BigDecimal subtotal;      // Subtotal calculado de este detalle
    private BigDecimal precio;        // Precio unitario del producto/servicio/medicamento
    private BigDecimal valor_adicional; // Valor adicional (si aplica)

    // =======================
    // Getters y Setters
    // =======================
    /**
     * Obtiene el id del detalle de venta.
     *
     * @return id del detalle de venta
     */
    public int getId() {
        // devuelve el valor del campo 'id'
        return id;
    }

    /**
     * Asigna el id del detalle de venta.
     *
     * @param id id del detalle de venta a asignar
     */
    public void setId(int id) {
        // asigna el valor recibido al campo 'id'
        this.id = id;
    }

    /**
     * Obtiene el id de la venta a la que pertenece este detalle.
     *
     * @return id de la venta asociada
     */
    public int getId_venta() {
        // devuelve el valor del campo 'id_venta'
        return id_venta;
    }

    /**
     * Asigna el id de la venta a la que pertenece este detalle.
     *
     * @param id_venta id de la venta a asignar
     */
    public void setId_venta(int id_venta) {
        // asigna el valor recibido al campo 'id_venta'
        this.id_venta = id_venta;
    }

    /**
     * Obtiene el id del producto asociado. Puede ser null si no aplica.
     *
     * @return id del producto asociado o null
     */
    public Integer getId_producto() {
        // devuelve el valor del campo 'id_producto'
        return id_producto;
    }

    /**
     * Asigna el id del producto asociado.
     *
     * @param id_producto id del producto a asignar
     */
    public void setId_producto(Integer id_producto) {
        // asigna el valor recibido al campo 'id_producto'
        this.id_producto = id_producto;
    }

    /**
     * Obtiene el id del servicio asociado. Puede ser null si no aplica.
     *
     * @return id del servicio asociado o null
     */
    public Integer getId_servicio() {
        // devuelve el valor del campo 'id_servicio'
        return id_servicio;
    }

    /**
     * Asigna el id del servicio asociado.
     *
     * @param id_servicio id del servicio a asignar
     */
    public void setId_servicio(Integer id_servicio) {
        // asigna el valor recibido al campo 'id_servicio'
        this.id_servicio = id_servicio;
    }

    /**
     * Obtiene el id del medicamento asociado. Puede ser null si no aplica.
     *
     * @return id del medicamento asociado o null
     */
    public Integer getId_medicamento() {
        // devuelve el valor del campo 'id_medicamento'
        return id_medicamento;
    }

    /**
     * Asigna el id del medicamento asociado.
     *
     * @param id_medicamento id del medicamento a asignar
     */
    public void setId_medicamento(Integer id_medicamento) {
        // asigna el valor recibido al campo 'id_medicamento'
        this.id_medicamento = id_medicamento;
    }

    /**
     * Obtiene la cantidad de unidades vendidas.
     *
     * @return cantidad de unidades vendidas
     */
    public int getCantidad() {
        // devuelve el valor del campo 'cantidad'
        return cantidad;
    }

    /**
     * Asigna la cantidad de unidades vendidas.
     *
     * @param cantidad cantidad de unidades a asignar
     */
    public void setCantidad(int cantidad) {
        // asigna el valor recibido al campo 'cantidad'
        this.cantidad = cantidad;
    }

    /**
     * Obtiene el subtotal calculado de este detalle.
     *
     * @return subtotal de este detalle
     */
    public BigDecimal getSubtotal() {
        // devuelve el valor del campo 'subtotal'
        return subtotal;
    }

    /**
     * Asigna el subtotal calculado de este detalle.
     *
     * @param subtotal subtotal a asignar
     */
    public void setSubtotal(BigDecimal subtotal) {
        // asigna el valor recibido al campo 'subtotal'
        this.subtotal = subtotal;
    }

    /**
     * Obtiene el precio unitario del item.
     *
     * @return precio unitario
     */
    public BigDecimal getPrecio() {
        // devuelve el valor del campo 'precio'
        return precio;
    }

    /**
     * Asigna el precio unitario del item.
     *
     * @param precio precio unitario a asignar
     */
    public void setPrecio(BigDecimal precio) {
        // asigna el valor recibido al campo 'precio'
        this.precio = precio;
    }

    /**
     * Obtiene el valor adicional asociado al detalle.
     *
     * @return valor adicional o null si no aplica
     */
    public BigDecimal getValor_adicional() {
        // devuelve el valor del campo 'valor_adicional'
        return valor_adicional;
    }

    /**
     * Asigna el valor adicional asociado al detalle.
     *
     * @param valor_adicional valor adicional a asignar
     */
    public void setValor_adicional(BigDecimal valor_adicional) {
        // asigna el valor recibido al campo 'valor_adicional'
        this.valor_adicional = valor_adicional;
    }
}
