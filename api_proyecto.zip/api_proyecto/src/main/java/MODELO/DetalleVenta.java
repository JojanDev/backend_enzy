package MODELO;

import java.math.BigDecimal;

/**
 * Representa un detalle de venta en el sistema.
 * Cada detalle puede corresponder a un producto, servicio o medicamento
 * dentro de una venta específica.
 */
public class DetalleVenta {

    private int id;                   // ID del detalle (clave primaria)
    private int id_venta;             // ID de la venta a la que pertenece este detalle
    private Integer id_producto;      // ID del producto (puede ser null si es servicio o medicamento)
    private Integer id_servicio;      // ID del servicio (puede ser null si es producto o medicamento)
    private Integer id_medicamento;   // ID del medicamento (puede ser null si es producto o servicio)
    private int cantidad;             // Cantidad de unidades vendidas
    private BigDecimal subtotal;      // Subtotal calculado de este detalle
    private BigDecimal precio;        // Precio unitario del producto/servicio/medicamento
    private BigDecimal valor_adicional; // Valor adicional (si aplica)

    // =======================
    // Getters y Setters
    // =======================

    /**
     * Obtiene el ID del detalle de venta.
     */
    public int getId() {
        return id;
    }

    /**
     * Asigna el ID del detalle de venta.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene el ID de la venta a la que pertenece este detalle.
     */
    public int getId_venta() {
        return id_venta;
    }

    /**
     * Asigna el ID de la venta a la que pertenece este detalle.
     */
    public void setId_venta(int id_venta) {
        this.id_venta = id_venta;
    }

    /**
     * Obtiene el ID del producto asociado.
     * Puede ser null si este detalle no corresponde a un producto.
     */
    public Integer getId_producto() {
        return id_producto;
    }

    /**
     * Asigna el ID del producto asociado.
     */
    public void setId_producto(Integer id_producto) {
        this.id_producto = id_producto;
    }

    /**
     * Obtiene el ID del servicio asociado.
     * Puede ser null si este detalle no corresponde a un servicio.
     */
    public Integer getId_servicio() {
        return id_servicio;
    }

    /**
     * Asigna el ID del servicio asociado.
     */
    public void setId_servicio(Integer id_servicio) {
        this.id_servicio = id_servicio;
    }

    /**
     * Obtiene el ID del medicamento asociado.
     * Puede ser null si este detalle no corresponde a un medicamento.
     */
    public Integer getId_medicamento() {
        return id_medicamento;
    }

    /**
     * Asigna el ID del medicamento asociado.
     */
    public void setId_medicamento(Integer id_medicamento) {
        this.id_medicamento = id_medicamento;
    }

    /**
     * Obtiene la cantidad de unidades vendidas.
     */
    public int getCantidad() {
        return cantidad;
    }

    /**
     * Asigna la cantidad de unidades vendidas.
     */
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    /**
     * Obtiene el subtotal de este detalle.
     */
    public BigDecimal getSubtotal() {
        return subtotal;
    }

    /**
     * Asigna el subtotal de este detalle.
     */
    public void setSubtotal(BigDecimal subtotal) {
        this.subtotal = subtotal;
    }

    /**
     * Obtiene el precio unitario.
     */
    public BigDecimal getPrecio() {
        return precio;
    }

    /**
     * Asigna el precio unitario.
     */
    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    /**
     * Obtiene un valor adicional asociado al detalle, si aplica.
     */
    public BigDecimal getValor_adicional() {
        return valor_adicional;
    }

    /**
     * Asigna un valor adicional asociado al detalle, si aplica.
     */
    public void setValor_adicional(BigDecimal valor_adicional) {
        this.valor_adicional = valor_adicional;
    }
}
