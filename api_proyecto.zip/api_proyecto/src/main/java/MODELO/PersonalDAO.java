package MODELO;

import MODELO.Personal;
import MODELO.ConexionBD;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

/**
 * Clase que maneja las operaciones de acceso a datos para la entidad Personal.
 * Proporciona m�todos para recuperar informaci�n sobre empleados y veterinarios.
 */
public class PersonalDAO {

    /**
     * Recupera un objeto Personal basado en el nombre de usuario.
     *
     * @param username Nombre de usuario del empleado.
     * @return Un objeto Personal si se encuentra, null si no.
     */
    public Personal getByUsername(String username) {
        // Consulta SQL para obtener un empleado por su nombre de usuario
        try (Connection con = ConexionBD.conectar(); 
             PreparedStatement ps = con.prepareStatement("SELECT * FROM personal WHERE usuario = ?")) {

            ps.setString(1, username); // Establece el nombre de usuario
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) { // Si hay resultados
                    Personal p = new Personal(); // Crea una nueva instancia de Personal
                    p.setId(rs.getInt("id")); // Establece el ID
                    p.setId_info(rs.getInt("id_info")); // Establece el ID de informaci�n
                    p.setId_rol(rs.getInt("id_rol")); // Establece el ID del rol
                    p.setContrasena(rs.getString("contrasena")); // Establece la contrase�a
                    p.setUsuario(rs.getString("usuario")); // Establece el nombre de usuario
                    p.setActivo(rs.getBoolean("activo")); // Establece el estado activo
                    return p; // Retorna el objeto Personal
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de errores
        }
        return null; // Retorna null si no se encuentra el empleado
    }

    /**
     * Recupera una lista de empleados que no est�n asociados a ning�n cliente.
     *
     * @return Lista de objetos InformacionClientesPersonal que representan a los empleados sin cliente.
     */
    public List<InformacionClientesPersonal> getEmpleadosSinCliente() {
        List<InformacionClientesPersonal> lista = new ArrayList<>(); // Lista para almacenar los empleados

        // Consulta SQL para obtener informaci�n de empleados sin cliente asociado
        String sql = """
        SELECT i.id, i.id_tipo_documento, i.numero_documento, 
               i.nombre, i.telefono, i.correo, i.direccion
        FROM informacion_clientes_personal i
        JOIN personal p ON p.id_info = i.id
        LEFT JOIN clientes c ON c.id_info = i.id
        WHERE c.id IS NULL
    """;

        // Usa try-with-resources para asegurar el cierre de recursos
        try (Connection con = ConexionBD.conectar(); 
             PreparedStatement ps = con.prepareStatement(sql); 
             ResultSet rs = ps.executeQuery()) {

            // Itera sobre los resultados de la consulta
            while (rs.next()) {
                InformacionClientesPersonal info = new InformacionClientesPersonal(); // Crea una nueva instancia
                info.setId(rs.getInt("id")); // Establece el ID
                info.setId_tipo_documento(rs.getInt("id_tipo_documento")); // Establece el tipo de documento
                info.setNumero_documento(rs.getString("numero_documento")); // Establece el n�mero de documento
                info.setNombre(rs.getString("nombre")); // Establece el nombre
                info.setTelefono(rs.getString("telefono")); // Establece el tel�fono
                info.setCorreo(rs.getString("correo")); // Establece el correo
                info.setDireccion(rs.getString("direccion")); // Establece la direcci�n
                lista.add(info); // Agrega el objeto a la lista
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de errores
        }

        return lista; // Retorna la lista de empleados
    }

    /**
     * Recupera una lista de veterinarios activos.
     *
     * @return Lista de objetos Personal que representan a los veterinarios activos.
     * @throws SQLException en caso de error con la base de datos.
     */
    public List<Personal> obtenerVeterinariosActivos() throws SQLException {
        List<Personal> lista = new ArrayList<>(); // Lista para almacenar los veterinarios

        // Consulta SQL para obtener veterinarios activos
        String sql = "SELECT p.id, p.id_info, p.contrasena, p.usuario, p.id_rol, p.activo " +
                     "FROM personal p " +
                     "JOIN informacion_clientes_personal i ON p.id_info = i.id " +
                     "WHERE p.id_rol = ? AND p.activo = ?";

        // Usa try-with-resources para asegurar el cierre de recursos
        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, 3);     // ID del rol veterinario
            stmt.setBoolean(2, true); // Solo activos

            // Ejecuta la consulta y obtiene los resultados
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Personal p = new Personal(); // Crea una nueva instancia de Personal
                    p.setId(rs.getInt("id")); // Establece el ID
                    p.setId_info(rs.getInt("id_info")); // Establece el ID de informaci�n
                    p.setContrasena(rs.getString("contrasena")); // Establece la contrase�a
                    p.setUsuario(rs.getString("usuario")); // Establece el nombre de usuario
                    p.setId_rol(rs.getInt("id_rol")); // Establece el ID del rol
                    p.setActivo(rs.getBoolean("activo")); // Establece el estado activo
                    lista.add(p); // Agrega el objeto a la lista
                }
            }
        }

        return lista; // Retorna la lista de veterinarios activos
    }
}
