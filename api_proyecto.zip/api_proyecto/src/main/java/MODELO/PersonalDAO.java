/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

import MODELO.Personal;
import MODELO.ConexionBD;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response; 
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

public class PersonalDAO {
    public Personal getByUsername(String username) {
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM personal WHERE usuario = ?")) {

            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Personal p = new Personal();
                    p.setId(rs.getInt("id"));
                    p.setId_info(rs.getInt("id_info"));
                    p.setContrasena(rs.getString("contrasena"));
                    p.setUsuario(rs.getString("usuario"));
                    return p;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    
//    public Personal create(Personal personal){
//        try (Connection con = ConexionBD.conectar();
//            PreparedStatement ps = con.prepareStatement("INSERT INTO personal (id_info, usuario, contrasena) VALUES (?, ?, ?)")) {
//            ps.setInt(1, personal.getId_info());
//            ps.setString(2, personal.getUsuario());
//            ps.setString(3, personal.getContrasena());
////            ps.setString(4, personal.getRoles());
//            ps.executeUpdate();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
}
