/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

import MODELO.Personal;
import MODELO.ConexionBD;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

public class PersonalDAO {

    public Personal getByUsername(String username) {
        try (Connection con = ConexionBD.conectar(); PreparedStatement ps = con.prepareStatement("SELECT * FROM personal WHERE usuario = ?")) {

            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Personal p = new Personal();
                    p.setId(rs.getInt("id"));
                    p.setId_info(rs.getInt("id_info"));
                    p.setId_rol(rs.getInt("id_rol"));
                    p.setContrasena(rs.getString("contrasena"));
                    p.setUsuario(rs.getString("usuario"));
                    p.setActivo(rs.getBoolean("activo"));
                    return p;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<InformacionClientesPersonal> getEmpleadosSinCliente() {
        List<InformacionClientesPersonal> lista = new ArrayList<>();

        String sql = """
        SELECT i.id, i.id_tipo_documento, i.numero_documento, 
               i.nombre, i.telefono, i.correo, i.direccion
        FROM informacion_clientes_personal i
        JOIN personal p ON p.id_info = i.id
        LEFT JOIN clientes c ON c.id_info = i.id
        WHERE c.id IS NULL
    """;

        try (Connection con = ConexionBD.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                InformacionClientesPersonal info = new InformacionClientesPersonal();
                info.setId(rs.getInt("id"));
                info.setId_tipo_documento(rs.getInt("id_tipo_documento"));
                info.setNumero_documento(rs.getString("numero_documento"));
                info.setNombre(rs.getString("nombre"));
                info.setTelefono(rs.getString("telefono"));
                info.setCorreo(rs.getString("correo"));
                info.setDireccion(rs.getString("direccion"));
                lista.add(info);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    public List<Personal> obtenerVeterinariosActivos() throws SQLException {
    List<Personal> lista = new ArrayList<>();

    String sql = "SELECT p.id, p.id_info, p.contrasena, p.usuario, p.id_rol, p.activo " +
                 "FROM personal p " +
                 "JOIN informacion_clientes_personal i ON p.id_info = i.id " +
                 "WHERE p.id_rol = ? AND p.activo = ?";

    try (Connection conn = ConexionBD.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setInt(1, 3);     // ID del rol veterinario
        stmt.setBoolean(2, true); // Solo activos

        try (ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Personal p = new Personal();
                p.setId(rs.getInt("id"));
                p.setId_info(rs.getInt("id_info"));
                p.setContrasena(rs.getString("contrasena"));
                p.setUsuario(rs.getString("usuario"));
                p.setId_rol(rs.getInt("id_rol"));
                p.setActivo(rs.getBoolean("activo"));
                lista.add(p);
            }
        }
    }

    return lista;
}


    
}
