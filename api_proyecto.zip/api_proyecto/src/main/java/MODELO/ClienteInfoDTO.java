/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

/**
 *
 * @author Propietario
 */
public class ClienteInfoDTO {
    private int id;           // ID del cliente (clave primaria)
    private InformacionClientesPersonal info;      // Clave foránea que apunta a la tabla informacion_clientes_personal

    // Constructor vacío (requerido para reflexión o frameworks)
    public ClienteInfoDTO() {}

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public InformacionClientesPersonal getInfo() {
        return info;
    }

    public void setInfo(InformacionClientesPersonal info) {
        this.info = info;
    }
}
