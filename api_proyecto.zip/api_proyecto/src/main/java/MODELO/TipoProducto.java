package MODELO;

/**
 * Representa un tipo de producto dentro del sistema.
 *
 * Campos:
 *   id     : identificador unico del tipo de producto (clave primaria)
 *   nombre : nombre descriptivo del tipo de producto
 */
public class TipoProducto {

    /** identificador unico del tipo de producto */
    private int id;

    /** nombre descriptivo del tipo de producto */
    private String nombre;

    /**
     * Obtiene el identificador unico del tipo de producto.
     *
     * @return identificador unico del tipo de producto
     */
    public int getId() {
        // devuelve el valor almacenado en 'id'
        return id;
    }

    /**
     * Establece el identificador unico del tipo de producto.
     *
     * @param id identificador unico a asignar
     */
    public void setId(int id) {
        // asigna el valor recibido al campo 'id'
        this.id = id;
    }

    /**
     * Obtiene el nombre descriptivo del tipo de producto.
     *
     * @return nombre del tipo de producto
     */
    public String getNombre() {
        // devuelve el valor almacenado en 'nombre'
        return nombre;
    }

    /**
     * Establece el nombre descriptivo del tipo de producto.
     *
     * @param nombre nombre a asignar al tipo de producto
     */
    public void setNombre(String nombre) {
        // asigna el valor recibido al campo 'nombre'
        this.nombre = nombre;
    }
}
