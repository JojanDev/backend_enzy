/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

public class ClientePostResponseDTO {
    private int id;
    private String nombre;
    private String numeroDocumento;
    private String telefono;
    private String correo;
    private String direccion;

    // Constructor completo
    public ClientePostResponseDTO(int id, String nombre, String numeroDocumento, String telefono, String correo, String direccion) {
        this.id = id;
        this.nombre = nombre;
        this.numeroDocumento = numeroDocumento;
        this.telefono = telefono;
        this.correo = correo;
        this.direccion = direccion;
    }   

    // Getters (no necesitas setters si es solo para responder)
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getNumeroDocumento() { return numeroDocumento; }
    public String getTelefono() { return telefono; }
    public String getCorreo() { return correo; }
    public String getDireccion() { return direccion; }
}
