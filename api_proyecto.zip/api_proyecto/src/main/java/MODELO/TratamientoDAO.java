package MODELO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Clase que maneja las operaciones de acceso a datos para la entidad Tratamiento.
 * Proporciona m�todos para gestionar tratamientos y su eliminaci�n.
 */
public class TratamientoDAO {

    private Connection con; // Conexi�n a la base de datos

    /**
     * Constructor que recibe una conexi�n a la base de datos.
     *
     * @param con Conexi�n a la base de datos.
     */
    public TratamientoDAO(Connection con) {
        this.con = con; // Inicializa la conexi�n
    }
    
    /**
     * Elimina un tratamiento realizando un SoftDelete, siempre que no tenga medicamentos asociados activos.
     *
     * @param idTratamiento ID del tratamiento a eliminar.
     * @return true si se elimin� correctamente, false si no fue posible.
     * @throws SQLException en caso de error con la base de datos.
     */
    public boolean eliminarTratamiento(int idTratamiento) throws SQLException {
        // Verificar si hay medicamentos asociados activos 
        String sqlVerificar = "SELECT COUNT(*) FROM medicamentos_tratamiento " +
                              "WHERE id_tratamiento = ? AND activo = true"; // Consulta SQL para verificar medicamentos activos
        try (PreparedStatement ps = con.prepareStatement(sqlVerificar)) {
            ps.setInt(1, idTratamiento); // Establece el ID del tratamiento
            ResultSet rs = ps.executeQuery(); // Ejecuta la consulta
            if (rs.next() && rs.getInt(1) > 0) {
                // Si hay medicamentos asociados, no se puede eliminar
                return false; // Retorna false si tiene medicamentos activos
            }
        }

        // SoftDelete del tratamiento
        String sqlSoftDelete = "UPDATE antecedentes_tratamientos SET activo = false WHERE id = ?"; // Consulta SQL para SoftDelete
        try (PreparedStatement ps = con.prepareStatement(sqlSoftDelete)) {
            ps.setInt(1, idTratamiento); // Establece el ID del tratamiento
            int filasAfectadas = ps.executeUpdate(); // Ejecuta la actualizaci�n
            return filasAfectadas > 0; // Retorna true si se actualiz�, false si no
        }
    }
}
