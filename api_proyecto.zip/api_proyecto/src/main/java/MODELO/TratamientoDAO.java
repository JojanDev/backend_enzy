package DAO;

import MODELO.Tratamiento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TratamientoDAO {

    private Connection con;

    public TratamientoDAO(Connection con) {
        this.con = con;
    }
    
    public boolean eliminarTratamiento(int idTratamiento) throws SQLException {
        //     Verificar si hay medicamentos asociados activos 
        String sqlVerificar = "SELECT COUNT(*) FROM medicamentos_tratamiento " +
                              "WHERE id_tratamiento = ? AND activo = true";
        try (PreparedStatement ps = con.prepareStatement(sqlVerificar)) {
            ps.setInt(1, idTratamiento);
            ResultSet rs = ps.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                // Tiene medicamentos asociados no se puede eliminar
                return false;
            }
        }

        // ️SoftDelete del tratamiento
        String sqlSoftDelete = "UPDATE antecedentes_tratamientos SET activo = false WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sqlSoftDelete)) {
            ps.setInt(1, idTratamiento);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0; // true si se actualizó
        }
    }
}
