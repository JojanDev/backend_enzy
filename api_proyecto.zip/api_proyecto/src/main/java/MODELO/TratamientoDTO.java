/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

import java.time.LocalDateTime;

/**
 *
 * @author USUARIO
 */
public class TratamientoDTO {
    private int id;           
    PersonalResponseDTO personal;
    private String titulo; 
    private String descripcion; 
    private LocalDateTime fecha_creado; 

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public LocalDateTime getFecha_creado() {
        return fecha_creado;
    }

    public void setFecha_creado(LocalDateTime fecha_creado) {
        this.fecha_creado = fecha_creado;
    }

    public PersonalResponseDTO getPersonal() {
        return personal;
    }

    public void setPersonal(PersonalResponseDTO personal) {
        this.personal = personal;
    }
    
    
}
