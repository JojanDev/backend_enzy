/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

/**
 *
 * @author USUARIO
 */
public class Mascota {
    private int id;
    private int id_cliente;
    private String nombre;
    private int id_raza;
    private int edad_semanas;
    private String sexo;
    private String estado_vital;
    
    public Mascota() {}

    // Getter y Setter para id
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEdad_semanas() {
        return edad_semanas;
    }

    public void setEdad_semanas(int edad_semanas) {
        this.edad_semanas = edad_semanas;
    }


    // Getter y Setter para id_cliente
    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    // Getter y Setter para nombre
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Getter y Setter para id_raza
    public int getId_raza() {
        return id_raza;
    }

    public void setId_raza(int id_raza) {
        this.id_raza = id_raza;
    }

    // Getter y Setter para sexo
    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    // Getter y Setter para estado_vital
    public String getEstado_vital() {
        return estado_vital;
    }

    public void setEstado_vital(String estado_vital) {
        this.estado_vital = estado_vital;
    }
}
