package MODELO;

/**
 * Modelo que representa una mascota asociada a un cliente.
 * 
 * Campos:
 * - id: identificador único de la mascota
 * - id_cliente: clave foránea al cliente propietario
 * - nombre: nombre de la mascota
 * - id_raza: clave foránea a la raza de la mascota
 * - edad_semanas: edad de la mascota en semanas
 * - sexo: sexo de la mascota ("M" o "F")
 * - estado_vital: indica si la mascota está viva (true) o no (false)
 */
public class Mascota {

    /**
     * identificador único de la mascota
     */
    private int id;

    /**
     * identificador del cliente propietario de la mascota
     */
    private int id_cliente;

    /**
     * nombre de la mascota
     */
    private String nombre;

    /**
     * identificador de la raza de la mascota
     */
    private int id_raza;

    /**
     * edad de la mascota en semanas
     */
    private int edad_semanas;

    /**
     * sexo de la mascota ("M" para macho, "F" para hembra)
     */
    private String sexo;

    /**
     * estado vital de la mascota: true si está viva, false si no
     */
    private boolean estado_vital;

    /**
     * Constructor sin argumentos para uso de frameworks y mapeo.
     */
    public Mascota() {
    }

    /**
     * Obtiene el identificador de la mascota.
     *
     * @return id de la mascota
     */
    public int getId() {
        return id;
    }

    /**
     * Asigna el identificador de la mascota.
     *
     * @param id nuevo identificador a establecer
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene el identificador del cliente propietario.
     *
     * @return id del cliente
     */
    public int getId_cliente() {
        return id_cliente;
    }

    /**
     * Asigna el identificador del cliente propietario.
     *
     * @param id_cliente nuevo id de cliente a asociar
     */
    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    /**
     * Obtiene el nombre de la mascota.
     *
     * @return nombre de la mascota
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Asigna el nombre de la mascota.
     *
     * @param nombre nuevo nombre a establecer
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el identificador de la raza de la mascota.
     *
     * @return id de la raza
     */
    public int getId_raza() {
        return id_raza;
    }

    /**
     * Asigna el identificador de la raza de la mascota.
     *
     * @param id_raza nuevo id de raza a establecer
     */
    public void setId_raza(int id_raza) {
        this.id_raza = id_raza;
    }

    /**
     * Obtiene la edad de la mascota en semanas.
     *
     * @return edad en semanas
     */
    public int getEdad_semanas() {
        return edad_semanas;
    }

    /**
     * Asigna la edad de la mascota en semanas.
     *
     * @param edad_semanas nueva edad en semanas a establecer
     */
    public void setEdad_semanas(int edad_semanes) {
        this.edad_semanas = edad_semanes;
    }

    /**
     * Obtiene el sexo de la mascota.
     *
     * @return sexo de la mascota ("M" o "F")
     */
    public String getSexo() {
        return sexo;
    }

    /**
     * Asigna el sexo de la mascota.
     *
     * @param sexo nuevo valor de sexo ("M" o "F")
     */
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    /**
     * Indica si la mascota está viva.
     *
     * @return true si la mascota está viva, false en caso contrario
     */
    public boolean isEstado_vital() {
        return estado_vital;
    }

    /**
     * Marca el estado vital de la mascota.
     *
     * @param estado_vital true para viva, false para no viva
     */
    public void setEstado_vital(boolean estado_vital) {
        this.estado_vital = estado_vital;
    }
}
