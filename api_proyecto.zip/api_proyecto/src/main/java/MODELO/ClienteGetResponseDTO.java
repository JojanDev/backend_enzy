package MODELO;

public class ClienteGetResponseDTO {
    private int id;
    private ICPGetResponseDTO info;

    // Constructor con todos los campos
    public ClienteGetResponseDTO(int id, ICPGetResponseDTO info) {
        this.id = id;
        this.info = info;
    }

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ICPGetResponseDTO getInfo() {
        return info;
    }

    public void setInfo(ICPGetResponseDTO info) {
        this.info = info;
    }
}
