/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

/**
 *
 * @author USUARIO
 */
public class MedicamentoTratamientoResponseDTO {
    private int id;
    private int id_tratamiento;
    private MedicamentoInfo medicamento;    
    private String dosis;
    private String frecuencia_aplicacion;
    private int duracion;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_tratamiento() {
        return id_tratamiento;
    }

    public void setId_tratamiento(int id_tratamiento) {
        this.id_tratamiento = id_tratamiento;
    }

    public MedicamentoInfo getMedicamento() {
        return medicamento;
    }

    public void setMedicamento(MedicamentoInfo medicamento) {
        this.medicamento = medicamento;
    }

    public String getDosis() {
        return dosis;
    }

    public void setDosis(String dosis) {
        this.dosis = dosis;
    }

    public String getFrecuencia_aplicacion() {
        return frecuencia_aplicacion;
    }

    public void setFrecuencia_aplicacion(String frecuencia_aplicacion) {
        this.frecuencia_aplicacion = frecuencia_aplicacion;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }
    
    
}
