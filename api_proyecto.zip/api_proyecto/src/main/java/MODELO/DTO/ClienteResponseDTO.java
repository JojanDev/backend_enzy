package MODELO.DTO;

/**
 * DTO para representar la respuesta de un cliente al frontend.
 *
 * Contiene:
 *   id   : identificador unico del cliente
 *   info : DTO con la informacion personal detallada del cliente
 */
public class ClienteResponseDTO {

    /** identificador unico del cliente */
    private int id;

    /** informacion personal detallada del cliente */
    private IcpResponseDTO info;

    /**
     * Constructor con todos los campos de la respuesta.
     *
     * @param id   identificador unico del cliente
     * @param info DTO con la informacion personal del cliente
     */
    public ClienteResponseDTO(int id, IcpResponseDTO info) {
        // asigna el identificador del cliente
        this.id = id;
        // asigna la informacion personal anidada
        this.info = info;
    }

    /**
     * Obtiene el identificador unico del cliente.
     *
     * @return identificador unico del cliente
     */
    public int getId() {
        // devuelve el valor del campo 'id'
        return id;
    }

    /**
     * Establece el identificador unico del cliente.
     *
     * @param id identificador unico a asignar
     */
    public void setId(int id) {
        // asigna el valor recibido al campo 'id'
        this.id = id;
    }

    /**
     * Obtiene la informacion personal detallada del cliente.
     *
     * @return DTO con la informacion personal
     */
    public IcpResponseDTO getInfo() {
        // devuelve el valor del campo 'info'
        return info;
    }

    /**
     * Establece la informacion personal detallada del cliente.
     *
     * @param info DTO de informacion personal a asignar
     */
    public void setInfo(IcpResponseDTO info) {
        // asigna el valor recibido al campo 'info'
        this.info = info;
    }
}
