package MODELO.DTO;

import java.time.LocalDateTime;

/**
 * DTO que representa un tratamiento con datos del personal responsable.
 *
 * Campos:
 * - id: identificador único del tratamiento
 * - personal: información del empleado que realizó el tratamiento
 * - titulo: título descriptivo del tratamiento
 * - descripcion: detalles del tratamiento
 * - fecha_creado: fecha y hora en que se registró el tratamiento
 */
public class TratamientoDTO {

    /**
     * identificador único del tratamiento
     */
    private int id;

    /**
     * datos del empleado que realizó el tratamiento
     */
    private PersonalResponseDTO personal;

    /**
     * título descriptivo del tratamiento
     */
    private String titulo;

    /**
     * descripción detallada del tratamiento
     */
    private String descripcion;

    /**
     * fecha y hora de registro del tratamiento
     */
    private LocalDateTime fecha_creado;

    /**
     * Obtiene el identificador único del tratamiento.
     *
     * @return id del tratamiento
     */
    public int getId() {
        return id;
    }

    /**
     * Asigna el identificador único del tratamiento.
     *
     * @param id nuevo valor de id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene los datos del empleado responsable.
     *
     * @return instancia de PersonalResponseDTO
     */
    public PersonalResponseDTO getPersonal() {
        return personal;
    }

    /**
     * Asigna los datos del empleado responsable.
     *
     * @param personal instancia de PersonalResponseDTO a asignar
     */
    public void setPersonal(PersonalResponseDTO personal) {
        this.personal = personal;
    }

    /**
     * Obtiene el título descriptivo del tratamiento.
     *
     * @return título del tratamiento
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * Asigna el título descriptivo del tratamiento.
     *
     * @param titulo nuevo título a establecer
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * Obtiene la descripción detallada del tratamiento.
     *
     * @return descripción del tratamiento
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Asigna la descripción detallada del tratamiento.
     *
     * @param descripcion nueva descripción a establecer
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Obtiene la fecha y hora en que se registró el tratamiento.
     *
     * @return fecha de creación
     */
    public LocalDateTime getFecha_creado() {
        return fecha_creado;
    }

    /**
     * Asigna la fecha y hora de registro del tratamiento.
     *
     * @param fecha_creado nueva fecha de creación a establecer
     */
    public void setFecha_creado(LocalDateTime fecha_creado) {
        this.fecha_creado = fecha_creado;
    }
}
