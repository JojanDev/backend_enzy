/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO.DTO;

import MODELO.DTO.RazaResponseDTO;
import java.sql.Date;
import java.time.LocalDate;

/**
 *
 * @author Propietario
 */
public class MascotaResponseDTO {
    private int id;
    private ClienteResponseDTO cliente;
    private String nombre;
    private RazaResponseDTO raza;
    private int edad_semanas;
    private String edadFormateada;    
    private String sexo;
    private boolean estado_vital;    
    private LocalDate ultimo_registro;

    public LocalDate getUltimo_registro() {
        return ultimo_registro;
    }

    public void setUltimo_registro(LocalDate ultimo_registro) {
        this.ultimo_registro = ultimo_registro;
    }    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ClienteResponseDTO getCliente() {
        return cliente;
    }

    public void setCliente(ClienteResponseDTO cliente) {
        this.cliente = cliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public RazaResponseDTO getRaza() {
        return raza;
    }

    public void setRaza(RazaResponseDTO raza) {
        this.raza = raza;
    }

    public int getEdad_semanas() {
        return edad_semanas;
    }

    public void setEdad_semanas(int edad_semanas) {
        this.edad_semanas = edad_semanas;
    }

    public String getEdadFormateada() {
        return edadFormateada;
    }

    public void setEdadFormateada(String edadFormateada) {
        this.edadFormateada = edadFormateada;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public boolean isEstado_vital() {
        return estado_vital;
    }

    public void setEstado_vital(boolean estado_vital) {
        this.estado_vital = estado_vital;
    }

    
}
