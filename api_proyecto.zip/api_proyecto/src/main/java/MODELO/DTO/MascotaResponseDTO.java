package MODELO.DTO;

import java.time.LocalDate;

/**
 * DTO de respuesta que representa una mascota.
 * Incluye información anidada de cliente y raza,
 * así como datos de edad, sexo, estado vital y fecha de último registro.
 */
public class MascotaResponseDTO {

    private int id;
    private ClienteResponseDTO cliente;
    private String nombre;
    private RazaResponseDTO raza;
    private int edad_semanas;
    private String edadFormateada;
    private String sexo;
    private boolean estado_vital;
    private LocalDate ultimo_registro;

    /**
     * Obtiene el identificador único de la mascota.
     *
     * @return id de la mascota
     */
    public int getId() {
        return id;
    }

    /**
     * Asigna el identificador único de la mascota.
     *
     * @param id nuevo identificador de la mascota
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene los datos del cliente propietario.
     *
     * @return instancia de ClienteResponseDTO asociada
     */
    public ClienteResponseDTO getCliente() {
        return cliente;
    }

    /**
     * Asigna los datos del cliente propietario.
     *
     * @param cliente DTO de cliente a asociar
     */
    public void setCliente(ClienteResponseDTO cliente) {
        this.cliente = cliente;
    }

    /**
     * Obtiene el nombre de la mascota.
     *
     * @return nombre de la mascota
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Asigna el nombre de la mascota.
     *
     * @param nombre nuevo nombre de la mascota
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene los datos de la raza de la mascota.
     *
     * @return instancia de RazaResponseDTO asociada
     */
    public RazaResponseDTO getRaza() {
        return raza;
    }

    /**
     * Asigna los datos de la raza de la mascota.
     *
     * @param raza DTO de raza a asociar
     */
    public void setRaza(RazaResponseDTO raza) {
        this.raza = raza;
    }

    /**
     * Obtiene la edad de la mascota en semanas.
     *
     * @return edad en semanas
     */
    public int getEdad_semanas() {
        return edad_semanas;
    }

    /**
     * Asigna la edad de la mascota en semanas.
     *
     * @param edad_semanas nueva edad en semanas
     */
    public void setEdad_semanas(int edad_semanas) {
        this.edad_semanas = edad_semanas;
    }

    /**
     * Obtiene la edad formateada como cadena.
     *
     * @return texto que representa la edad (por ejemplo, "12 semanas")
     */
    public String getEdadFormateada() {
        return edadFormateada;
    }

    /**
     * Asigna la edad formateada como cadena.
     *
     * @param edadFormateada nuevo texto de edad
     */
    public void setEdadFormateada(String edadFormateada) {
        this.edadFormateada = edadFormateada;
    }

    /**
     * Obtiene el sexo de la mascota.
     *
     * @return sexo ("M" para macho, "F" para hembra)
     */
    public String getSexo() {
        return sexo;
    }

    /**
     * Asigna el sexo de la mascota.
     *
     * @param sexo nuevo valor de sexo ("M" o "F")
     */
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    /**
     * Indica si la mascota está viva.
     *
     * @return true si está viva, false si no
     */
    public boolean isEstado_vital() {
        return estado_vital;
    }

    /**
     * Marca si la mascota está viva.
     *
     * @param estado_vital true para viva, false para no viva
     */
    public void setEstado_vital(boolean estado_vital) {
        this.estado_vital = estado_vital;
    }

    /**
     * Obtiene la fecha del último registro asociado a la mascota.
     *
     * @return fecha del último registro
     */
    public LocalDate getUltimo_registro() {
        return ultimo_registro;
    }

    /**
     * Asigna la fecha del último registro asociado a la mascota.
     *
     * @param ultimo_registro nueva fecha de último registro
     */
    public void setUltimo_registro(LocalDate ultimo_registro) {
        this.ultimo_registro = ultimo_registro;
    }
}
