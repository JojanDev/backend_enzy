package MODELO.DTO;

import MODELO.Rol;

/**
 * DTO de respuesta que representa un empleado del sistema.
 * Incluye información personal, rol asignado, nombre de usuario
 * y estado de la cuenta.
 */
public class PersonalResponseDTO {

    /**
     * identificador único del empleado
     */
    private int id;

    /**
     * datos anidados de información personal (IcpResponseDTO)
     */
    private IcpResponseDTO info;

    /**
     * rol asignado al empleado
     */
    private Rol rol;

    /**
     * nombre de usuario para autenticación
     */
    private String usuario;

    /**
     * indica si la cuenta del empleado está activa (true) o inactiva (false)
     */
    private boolean activo;

    /**
     * Obtiene el identificador del empleado.
     *
     * @return id del empleado
     */
    public int getId() {
        return id;
    }

    /**
     * Asigna el identificador del empleado.
     *
     * @param id nuevo identificador a establecer
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene la información personal anidada (IcpResponseDTO).
     *
     * @return instancia de IcpResponseDTO
     */
    public IcpResponseDTO getInfo() {
        return info;
    }

    /**
     * Asigna la información personal anidada (IcpResponseDTO).
     *
     * @param info instancia de IcpResponseDTO a asignar
     */
    public void setInfo(IcpResponseDTO info) {
        this.info = info;
    }

    /**
     * Obtiene el rol asignado al empleado.
     *
     * @return instancia de Rol
     */
    public Rol getRol() {
        return rol;
    }

    /**
     * Asigna el rol al empleado.
     *
     * @param rol instancia de Rol a asignar
     */
    public void setRol(Rol rol) {
        this.rol = rol;
    }

    /**
     * Obtiene el nombre de usuario para autenticación.
     *
     * @return nombre de usuario
     */
    public String getUsuario() {
        return usuario;
    }

    /**
     * Asigna el nombre de usuario para autenticación.
     *
     * @param usuario nuevo nombre de usuario
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    /**
     * Indica si la cuenta del empleado está activa.
     *
     * @return true si está activa, false si está inactiva
     */
    public boolean isActivo() {
        return activo;
    }

    /**
     * Marca el estado de la cuenta del empleado.
     *
     * @param activo true para cuenta activa, false para inactiva
     */
    public void setActivo(boolean activo) {
        this.activo = activo;
    }
}
