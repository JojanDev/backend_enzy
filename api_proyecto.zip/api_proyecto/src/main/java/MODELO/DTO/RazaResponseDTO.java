
package MODELO.DTO;

import MODELO.Especie;

/**
 * DTO de respuesta para representar una raza junto con su especie asociada.
 *
 * Campos:
 *   id      : identificador único de la raza
 *   nombre  : nombre descriptivo de la raza
 *   especie : objeto Especie con datos de la especie a la que pertenece
 */
public class RazaResponseDTO {

    /** identificador único de la raza */
    private int id;

    /** nombre descriptivo de la raza */
    private String nombre;

    /** objeto Especie con datos de la especie asociada */
    private Especie especie;

    /**
     * Obtiene el identificador único de la raza.
     *
     * @return identificador de la raza
     */
    public int getId() {
        // devuelve el valor almacenado en 'id'
        return id;
    }

    /**
     * Establece el identificador único de la raza.
     *
     * @param id identificador a asignar
     */
    public void setId(int id) {
        // asigna el valor recibido al campo 'id'
        this.id = id;
    }

    /**
     * Obtiene el nombre descriptivo de la raza.
     *
     * @return nombre de la raza
     */
    public String getNombre() {
        // devuelve el valor almacenado en 'nombre'
        return nombre;
    }

    /**
     * Establece el nombre descriptivo de la raza.
     *
     * @param nombre nombre a asignar
     */
    public void setNombre(String nombre) {
        // asigna el valor recibido al campo 'nombre'
        this.nombre = nombre;
    }

    /**
     * Obtiene la especie asociada a esta raza.
     *
     * @return objeto Especie que pertenece a la raza
     */
    public Especie getEspecie() {
        // devuelve el valor almacenado en 'especie'
        return especie;
    }

    /**
     * Establece la especie asociada a esta raza.
     *
     * @param especie objeto Especie a asignar
     */
    public void setEspecie(Especie especie) {
        // asigna el objeto recibido al campo 'especie'
        this.especie = especie;
    }
}
