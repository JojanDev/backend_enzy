package MODELO.DTO;

/**
 * DTO para encapsular la solicitud de inicio de sesión.
 *
 * Contiene las credenciales del usuario utilizadas para autenticación.
 *
 * Campos:
 *   usuario    : nombre de usuario
 *   contrasena : contraseña asociada al usuario
 */
public class LoginRequestDTO {

    /** nombre de usuario para autenticación */
    private String usuario;

    /** contraseña asociada al usuario */
    private String contrasena;

    /**
     * Obtiene el nombre de usuario para autenticación.
     *
     * @return usuario ingresado
     */
    public String getUsuario() {
        // devuelve el valor del campo 'usuario'
        return usuario;
    }

    /**
     * Establece el nombre de usuario para autenticación.
     *
     * @param usuario nombre de usuario a asignar
     */
    public void setUsuario(String usuario) {
        // asigna el valor recibido al campo 'usuario'
        this.usuario = usuario;
    }

    /**
     * Obtiene la contraseña asociada al usuario.
     *
     * @return contraseña ingresada
     */
    public String getContrasena() {
        // devuelve el valor del campo 'contrasena'
        return contrasena;
    }

    /**
     * Establece la contraseña asociada al usuario.
     *
     * @param contrasena contraseña a asignar
     */
    public void setContrasena(String contrasena) {
        // asigna el valor recibido al campo 'contrasena'
        this.contrasena = contrasena;
    }
}
