package MODELO.DTO;

import java.util.List;

/**
 * DTO que representa el perfil completo de una venta, incluyendo datos del
 * cliente, del empleado y los detalles asociados.
 *
 * Campos:
 *   idCliente        : identificador unico del cliente
 *   nombreCliente    : nombre completo del cliente
 *   documentoCliente : numero de documento del cliente
 *   idEmpleado       : identificador unico del empleado
 *   nombreEmpleado   : nombre completo del empleado
 *   idVenta          : identificador unico de la venta
 *   total            : total calculado de la venta
 *   fechaCreado      : fecha de creacion de la venta (como cadena)
 *   monto            : monto cobrado en la venta
 *   estado           : estado actual de la venta (por ejemplo, PAGADO, PENDIENTE)
 *   detalles         : lista de objetos DetalleVentaDTO con cada item vendido
 */
public class VentaPerfilDTO {

    /** identificador unico del cliente */
    private int idCliente;

    /** nombre completo del cliente */
    private String nombreCliente;

    /** numero de documento del cliente */
    private String documentoCliente;

    /** identificador unico del empleado */
    private int idEmpleado;

    /** nombre completo del empleado */
    private String nombreEmpleado;

    /** identificador unico de la venta */
    private int idVenta;

    /** total calculado de la venta */
    private double total;

    /** fecha de creacion de la venta (como cadena) */
    private String fechaCreado;

    /** monto cobrado en la venta */
    private double monto;

    /** estado actual de la venta */
    private String estado;

    /** lista de detalles de cada item de la venta */
    private List<DetalleVentaDTO> detalles;

    /**
     * Obtiene el identificador unico del cliente.
     *
     * @return idCliente
     */
    public int getIdCliente() {
        // devuelve el valor del campo 'idCliente'
        return idCliente;
    }

    /**
     * Establece el identificador unico del cliente.
     *
     * @param idCliente identificador a asignar
     */
    public void setIdCliente(int idCliente) {
        // asigna el valor recibido al campo 'idCliente'
        this.idCliente = idCliente;
    }

    /**
     * Obtiene el nombre completo del cliente.
     *
     * @return nombreCliente
     */
    public String getNombreCliente() {
        // devuelve el valor del campo 'nombreCliente'
        return nombreCliente;
    }

    /**
     * Establece el nombre completo del cliente.
     *
     * @param nombreCliente nombre a asignar
     */
    public void setNombreCliente(String nombreCliente) {
        // asigna el valor recibido al campo 'nombreCliente'
        this.nombreCliente = nombreCliente;
    }

    /**
     * Obtiene el numero de documento del cliente.
     *
     * @return documentoCliente
     */
    public String getDocumentoCliente() {
        // devuelve el valor del campo 'documentoCliente'
        return documentoCliente;
    }

    /**
     * Establece el numero de documento del cliente.
     *
     * @param documentoCliente documento a asignar
     */
    public void setDocumentoCliente(String documentoCliente) {
        // asigna el valor recibido al campo 'documentoCliente'
        this.documentoCliente = documentoCliente;
    }

    /**
     * Obtiene el identificador unico del empleado.
     *
     * @return idEmpleado
     */
    public int getIdEmpleado() {
        // devuelve el valor del campo 'idEmpleado'
        return idEmpleado;
    }

    /**
     * Establece el identificador unico del empleado.
     *
     * @param idEmpleado identificador a asignar
     */
    public void setIdEmpleado(int idEmpleado) {
        // asigna el valor recibido al campo 'idEmpleado'
        this.idEmpleado = idEmpleado;
    }

    /**
     * Obtiene el nombre completo del empleado.
     *
     * @return nombreEmpleado
     */
    public String getNombreEmpleado() {
        // devuelve el valor del campo 'nombreEmpleado'
        return nombreEmpleado;
    }

    /**
     * Establece el nombre completo del empleado.
     *
     * @param nombreEmpleado nombre a asignar
     */
    public void setNombreEmpleado(String nombreEmpleado) {
        // asigna el valor recibido al campo 'nombreEmpleado'
        this.nombreEmpleado = nombreEmpleado;
    }

    /**
     * Obtiene el identificador unico de la venta.
     *
     * @return idVenta
     */
    public int getIdVenta() {
        // devuelve el valor del campo 'idVenta'
        return idVenta;
    }

    /**
     * Establece el identificador unico de la venta.
     *
     * @param idVenta identificador a asignar
     */
    public void setIdVenta(int idVenta) {
        // asigna el valor recibido al campo 'idVenta'
        this.idVenta = idVenta;
    }

    /**
     * Obtiene el total calculado de la venta.
     *
     * @return total
     */
    public double getTotal() {
        // devuelve el valor del campo 'total'
        return total;
    }

    /**
     * Establece el total calculado de la venta.
     *
     * @param total valor a asignar
     */
    public void setTotal(double total) {
        // asigna el valor recibido al campo 'total'
        this.total = total;
    }

    /**
     * Obtiene la fecha de creacion de la venta.
     *
     * @return fechaCreado
     */
    public String getFechaCreado() {
        // devuelve el valor del campo 'fechaCreado'
        return fechaCreado;
    }

    /**
     * Establece la fecha de creacion de la venta.
     *
     * @param fechaCreado fecha a asignar
     */
    public void setFechaCreado(String fechaCreado) {
        // asigna el valor recibido al campo 'fechaCreado'
        this.fechaCreado = fechaCreado;
    }

    /**
     * Obtiene el monto cobrado en la venta.
     *
     * @return monto
     */
    public double getMonto() {
        // devuelve el valor del campo 'monto'
        return monto;
    }

    /**
     * Establece el monto cobrado en la venta.
     *
     * @param monto valor a asignar
     */
    public void setMonto(double monto) {
        // asigna el valor recibido al campo 'monto'
        this.monto = monto;
    }

    /**
     * Obtiene el estado actual de la venta.
     *
     * @return estado
     */
    public String getEstado() {
        // devuelve el valor del campo 'estado'
        return estado;
    }

    /**
     * Establece el estado actual de la venta.
     *
     * @param estado estado a asignar
     */
    public void setEstado(String estado) {
        // asigna el valor recibido al campo 'estado'
        this.estado = estado;
    }

    /**
     * Obtiene la lista de detalles asociados a la venta.
     *
     * @return lista de DetalleVentaDTO
     */
    public List<DetalleVentaDTO> getDetalles() {
        // devuelve el valor del campo 'detalles'
        return detalles;
    }

    /**
     * Establece la lista de detalles asociados a la venta.
     *
     * @param detalles lista de DetalleVentaDTO a asignar
     */
    public void setDetalles(List<DetalleVentaDTO> detalles) {
        // asigna la lista recibida al campo 'detalles'
        this.detalles = detalles;
    }
}
