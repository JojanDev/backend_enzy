/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO.DTO;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 *
 * @author USUARIO
 */
public class VentaResponseDTO {
    private int id;
    private BigDecimal monto;
    private BigDecimal total;
    private String estado;
    private LocalDateTime fecha;
    
    // Datos relacionados
    private ClienteResponseDTO cliente;
    private PersonalResponseDTO personal;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public BigDecimal getMonto() {
        return monto;
    }

    public void setMonto(BigDecimal monto) {
        this.monto = monto;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public ClienteResponseDTO getCliente() {
        return cliente;
    }

    public void setCliente(ClienteResponseDTO cliente) {
        this.cliente = cliente;
    }

    public PersonalResponseDTO getPersonal() {
        return personal;
    }

    public void setPersonal(PersonalResponseDTO personal) {
        this.personal = personal;
    }
    
    
}
