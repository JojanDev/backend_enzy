package MODELO.DTO;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO de respuesta que representa una venta.
 * Incluye información de montos, estado, fecha de creación
 * y datos anidados de cliente y personal responsable.
 */
public class VentaResponseDTO {

    /**
     * identificador único de la venta
     */
    private int id;

    /**
     * importe efectivamente pagado en la venta
     */
    private BigDecimal monto;

    /**
     * importe total que debía pagarse
     */
    private BigDecimal total;

    /**
     * estado de la venta (por ejemplo, completada o pendiente)
     */
    private String estado;

    /**
     * fecha y hora en que se registró la venta
     */
    private LocalDateTime fecha;

    // Datos relacionados

    /**
     * información del cliente que realizó la compra
     */
    private ClienteResponseDTO cliente;

    /**
     * información del personal que procesó la venta
     */
    private PersonalResponseDTO personal;

    /**
     * Obtiene el identificador único de la venta.
     *
     * @return valor de id
     */
    public int getId() {
        return id;
    }

    /**
     * Asigna el identificador único de la venta.
     *
     * @param id nuevo valor de id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene el importe efectivamente pagado.
     *
     * @return monto pagado
     */
    public BigDecimal getMonto() {
        return monto;
    }

    /**
     * Asigna el importe efectivamente pagado.
     *
     * @param monto nuevo valor de monto
     */
    public void setMonto(BigDecimal monto) {
        this.monto = monto;
    }

    /**
     * Obtiene el importe total que debía pagarse.
     *
     * @return total de la venta
     */
    public BigDecimal getTotal() {
        return total;
    }

    /**
     * Asigna el importe total que debía pagarse.
     *
     * @param total nuevo valor de total
     */
    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    /**
     * Obtiene el estado de la venta.
     *
     * @return estado de la venta
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Asigna el estado de la venta.
     *
     * @param estado nuevo estado a establecer
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * Obtiene la fecha y hora de registro de la venta.
     *
     * @return fecha de la venta
     */
    public LocalDateTime getFecha() {
        return fecha;
    }

    /**
     * Asigna la fecha y hora de registro de la venta.
     *
     * @param fecha nueva fecha a establecer
     */
    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    /**
     * Obtiene la información del cliente asociado.
     *
     * @return instancia de ClienteResponseDTO
     */
    public ClienteResponseDTO getCliente() {
        return cliente;
    }

    /**
     * Asigna la información del cliente asociado.
     *
     * @param cliente instancia de ClienteResponseDTO a asignar
     */
    public void setCliente(ClienteResponseDTO cliente) {
        this.cliente = cliente;
    }

    /**
     * Obtiene la información del personal que procesó la venta.
     *
     * @return instancia de PersonalResponseDTO
     */
    public PersonalResponseDTO getPersonal() {
        return personal;
    }

    /**
     * Asigna la información del personal que procesó la venta.
     *
     * @param personal instancia de PersonalResponseDTO a asignar
     */
    public void setPersonal(PersonalResponseDTO personal) {
        this.personal = personal;
    }
}
