package MODELO.DTO;

/**
 * DTO para encapsular la información necesaria al crear o actualizar un registro de personal.
 *
 * Campos:
 *   id_tipo_documento : clave foránea al tipo de documento del personal
 *   numero_documento  : número de documento de identidad
 *   nombre            : nombre completo del personal
 *   telefono          : número de contacto
 *   correo            : dirección de correo electrónico
 *   direccion         : dirección física
 *   usuario           : nombre de usuario para acceso al sistema
 *   contrasena        : contraseña asociada al usuario
 *   id_rol            : clave foránea al rol asignado al personal
 */
public class PersonalRequestDTO {

    /** clave foránea al tipo de documento del personal */
    private int id_tipo_documento;

    /** número de documento de identidad */
    private String numero_documento;

    /** nombre completo del personal */
    private String nombre;

    /** número de contacto telefónico */
    private String telefono;

    /** dirección de correo electrónico */
    private String correo;

    /** dirección física del personal */
    private String direccion;

    /** nombre de usuario para autenticación */
    private String usuario;

    /** contraseña asociada al usuario */
    private String contrasena;

    /** clave foránea al rol asignado al personal */
    private int id_rol;

    /**
     * Obtiene la clave foránea al tipo de documento.
     *
     * @return id_tipo_documento almacenado
     */
    public int getId_tipo_documento() {
        // devuelve el valor del campo 'id_tipo_documento'
        return id_tipo_documento;
    }

    /**
     * Define la clave foránea al tipo de documento.
     *
     * @param id_tipo_documento clave foránea a asignar
     */
    public void setId_tipo_documento(int id_tipo_documento) {
        // asigna el valor recibido al campo 'id_tipo_documento'
        this.id_tipo_documento = id_tipo_documento;
    }

    /**
     * Obtiene el número de documento de identidad.
     *
     * @return numero_documento almacenado
     */
    public String getNumero_documento() {
        // devuelve el valor del campo 'numero_documento'
        return numero_documento;
    }

    /**
     * Define el número de documento de identidad.
     *
     * @param numero_documento número de documento a asignar
     */
    public void setNumero_documento(String numero_documento) {
        // asigna el valor recibido al campo 'numero_documento'
        this.numero_documento = numero_documento;
    }

    /**
     * Obtiene el nombre completo del personal.
     *
     * @return nombre almacenado
     */
    public String getNombre() {
        // devuelve el valor del campo 'nombre'
        return nombre;
    }

    /**
     * Define el nombre completo del personal.
     *
     * @param nombre nombre a asignar
     */
    public void setNombre(String nombre) {
        // asigna el valor recibido al campo 'nombre'
        this.nombre = nombre;
    }

    /**
     * Obtiene el número de contacto telefónico.
     *
     * @return telefono almacenado
     */
    public String getTelefono() {
        // devuelve el valor del campo 'telefono'
        return telefono;
    }

    /**
     * Define el número de contacto telefónico.
     *
     * @param telefono teléfono a asignar
     */
    public void setTelefono(String telefono) {
        // asigna el valor recibido al campo 'telefono'
        this.telefono = telefono;
    }

    /**
     * Obtiene la dirección de correo electrónico.
     *
     * @return correo almacenado
     */
    public String getCorreo() {
        // devuelve el valor del campo 'correo'
        return correo;
    }

    /**
     * Define la dirección de correo electrónico.
     *
     * @param correo correo a asignar
     */
    public void setCorreo(String correo) {
        // asigna el valor recibido al campo 'correo'
        this.correo = correo;
    }

    /**
     * Obtiene la dirección física del personal.
     *
     * @return direccion almacenada
     */
    public String getDireccion() {
        // devuelve el valor del campo 'direccion'
        return direccion;
    }

    /**
     * Define la dirección física del personal.
     *
     * @param direccion dirección a asignar
     */
    public void setDireccion(String direccion) {
        // asigna el valor recibido al campo 'direccion'
        this.direccion = direccion;
    }

    /**
     * Obtiene el nombre de usuario para autenticación.
     *
     * @return usuario almacenado
     */
    public String getUsuario() {
        // devuelve el valor del campo 'usuario'
        return usuario;
    }

    /**
     * Define el nombre de usuario para autenticación.
     *
     * @param usuario usuario a asignar
     */
    public void setUsuario(String usuario) {
        // asigna el valor recibido al campo 'usuario'
        this.usuario = usuario;
    }

    /**
     * Obtiene la contraseña asociada al usuario.
     *
     * @return contrasena almacenada
     */
    public String getContrasena() {
        // devuelve el valor del campo 'contrasena'
        return contrasena;
    }

    /**
     * Define la contraseña asociada al usuario.
     *
     * @param contrasena contraseña a asignar
     */
    public void setContrasena(String contrasena) {
        // asigna el valor recibido al campo 'contrasena'
        this.contrasena = contrasena;
    }

    /**
     * Obtiene la clave foránea al rol asignado al personal.
     *
     * @return id_rol almacenado
     */
    public int getId_rol() {
        // devuelve el valor del campo 'id_rol'
        return id_rol;
    }

    /**
     * Define la clave foránea al rol asignado al personal.
     *
     * @param id_rol clave foránea a asignar
     */
    public void setId_rol(int id_rol) {
        // asigna el valor recibido al campo 'id_rol'
        this.id_rol = id_rol;
    }
}
