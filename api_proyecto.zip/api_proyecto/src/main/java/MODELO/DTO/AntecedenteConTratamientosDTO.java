package MODELO.DTO;

import java.time.LocalDateTime;
import java.util.List;

/**
 * DTO que representa un antecedente medico junto con sus tratamientos asociados.
 *
 * Campos:
 *   id           : identificador unico del antecedente
 *   titulo       : titulo breve del antecedente
 *   diagnostico  : descripcion o diagnostico asociado al antecedente
 *   fecha_creado : fecha y hora de creacion del antecedente
 *   tratamientos : lista de tratamientos asociados al antecedente
 */
public class AntecedenteConTratamientosDTO {

    private int id;
    private String titulo;
    private String diagnostico;
    private LocalDateTime fecha_creado;
    private List<TratamientoDTO> tratamientos;

    /**
     * Obtiene el identificador unico del antecedente.
     *
     * @return identificador unico del antecedente
     */
    public int getId() {
        // devuelve el valor del campo 'id'
        return id;
    }

    /**
     * Establece el identificador unico del antecedente.
     *
     * @param id identificador unico a asignar
     */
    public void setId(int id) {
        // asigna el valor recibido al campo 'id'
        this.id = id;
    }

    /**
     * Obtiene el titulo breve del antecedente.
     *
     * @return titulo del antecedente
     */
    public String getTitulo() {
        // devuelve el valor del campo 'titulo'
        return titulo;
    }

    /**
     * Establece el titulo breve del antecedente.
     *
     * @param titulo titulo a asignar
     */
    public void setTitulo(String titulo) {
        // asigna el valor recibido al campo 'titulo'
        this.titulo = titulo;
    }

    /**
     * Obtiene la descripcion o diagnostico asociado al antecedente.
     *
     * @return diagnostico del antecedente
     */
    public String getDiagnostico() {
        // devuelve el valor del campo 'diagnostico'
        return diagnostico;
    }

    /**
     * Establece la descripcion o diagnostico asociado al antecedente.
     *
     * @param diagnostico diagnostico a asignar
     */
    public void setDiagnostico(String diagnostico) {
        // asigna el valor recibido al campo 'diagnostico'
        this.diagnostico = diagnostico;
    }

    /**
     * Obtiene la fecha y hora de creacion del antecedente.
     *
     * @return fecha de creacion del antecedente
     */
    public LocalDateTime getFecha_creado() {
        // devuelve el valor del campo 'fecha_creado'
        return fecha_creado;
    }

    /**
     * Establece la fecha y hora de creacion del antecedente.
     *
     * @param fecha_creado fecha y hora a asignar
     */
    public void setFecha_creado(LocalDateTime fecha_creado) {
        // asigna el valor recibido al campo 'fecha_creado'
        this.fecha_creado = fecha_creado;
    }

    /**
     * Obtiene la lista de tratamientos asociados al antecedente.
     *
     * @return lista de TratamientoDTO
     */
    public List<TratamientoDTO> getTratamientos() {
        // devuelve la lista del campo 'tratamientos'
        return tratamientos;
    }

    /**
     * Establece la lista de tratamientos asociados al antecedente.
     *
     * @param tratamientos lista de TratamientoDTO a asignar
     */
    public void setTratamientos(List<TratamientoDTO> tratamientos) {
        // asigna la lista recibida al campo 'tratamientos'
        this.tratamientos = tratamientos;
    }
}
