/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO.DTO;

import MODELO.DTO.TratamientoDTO;
import java.time.LocalDateTime;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class AntecedenteConTratamientosDTO {
    private int id;
    private String titulo;
    private String diagnostico;
    private LocalDateTime fecha_creado;

    private List<TratamientoDTO> tratamientos; // Los tratamientos asociados

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    public LocalDateTime getFecha_creado() {
        return fecha_creado;
    }

    public void setFecha_creado(LocalDateTime fecha_creado) {
        this.fecha_creado = fecha_creado;
    }

    public List<TratamientoDTO> getTratamientos() {
        return tratamientos;
    }

    public void setTratamientos(List<TratamientoDTO> tratamientos) {
        this.tratamientos = tratamientos;
    }
}
