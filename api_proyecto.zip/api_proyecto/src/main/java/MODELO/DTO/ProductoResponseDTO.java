package MODELO.DTO;

import MODELO.TipoProducto;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * DTO de respuesta que representa un producto.
 * Incluye información detallada, tipo de producto anidado y stock disponible.
 */
public class ProductoResponseDTO {

    private int id;
    private String nombre;
    private BigDecimal precio;
    private String descripcion;
    private LocalDate fecha_caducidad;
    private TipoProducto tipoProducto;
    private int stock;

    /**
     * Obtiene el identificador único del producto.
     *
     * @return id del producto
     */
    public int getId() {
        return id;
    }

    /**
     * Asigna el identificador único del producto.
     *
     * @param id nuevo identificador del producto
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene el nombre comercial del producto.
     *
     * @return nombre del producto
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Asigna el nombre comercial del producto.
     *
     * @param nombre nuevo nombre del producto
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el precio unitario del producto.
     *
     * @return precio del producto
     */
    public BigDecimal getPrecio() {
        return precio;
    }

    /**
     * Asigna el precio unitario del producto.
     *
     * @param precio nuevo precio del producto
     */
    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    /**
     * Obtiene la descripción detallada del producto.
     *
     * @return descripción del producto
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Asigna la descripción detallada del producto.
     *
     * @param descripcion nueva descripción del producto
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Obtiene la fecha de caducidad del producto.
     *
     * @return fecha límite de venta o consumo
     */
    public LocalDate getFecha_caducidad() {
        return fecha_caducidad;
    }

    /**
     * Asigna la fecha de caducidad del producto.
     *
     * @param fecha_caducidad nueva fecha límite de venta o consumo
     */
    public void setFecha_caducidad(LocalDate fecha_caducidad) {
        this.fecha_caducidad = fecha_caducidad;
    }

    /**
     * Obtiene el tipo de producto anidado.
     *
     * @return instancia de TipoProducto
     */
    public TipoProducto getTipoProducto() {
        return tipoProducto;
    }

    /**
     * Asigna el tipo de producto anidado.
     *
     * @param tipoProducto instancia de TipoProducto a asociar
     */
    public void setTipoProducto(TipoProducto tipoProducto) {
        this.tipoProducto = tipoProducto;
    }

    /**
     * Obtiene el stock disponible en inventario.
     *
     * @return unidades en stock
     */
    public int getStock() {
        return stock;
    }

    /**
     * Asigna el stock disponible en inventario.
     *
     * @param stock nuevas unidades disponibles
     */
    public void setStock(int stock) {
        this.stock = stock;
    }
}
