package MODELO.DTO;

import MODELO.Cliente;
import MODELO.DAO.CrudDAO;
import MODELO.InformacionClientesPersonal;
import MODELO.TipoDocumento;

/**
 * Clase utilitaria encargada de construir DTOs relacionados con Cliente.
 * Su propósito es separar la lógica de transformación de entidades a objetos de
 * respuesta, manteniendo limpio el controlador.
 *
 * Métodos:
 *   construirInfoDTO: crea un IcpResponseDTO a partir de InformacionClientesPersonal.
 *   construirClienteDTO: crea un ClienteResponseDTO a partir de Cliente e información personal.
 */
public class ClienteDtoBuilder {

    /**
     * Construye un IcpResponseDTO (información personal del cliente) a partir
     * del modelo de entidad InformacionClientesPersonal, incluyendo su TipoDocumento.
     *
     * @param info objeto de entidad InformacionClientesPersonal con datos a transformar
     * @param dao DAO genérico para acceder a la base de datos
     * @return IcpResponseDTO con datos completos y TipoDocumento anidado, o null si falta info
     */
    public static IcpResponseDTO construirInfoDTO(InformacionClientesPersonal info, CrudDAO dao) {
        // valida que el objeto de info no sea nulo
        if (info == null) {
            return null;
        }

        // obtiene el TipoDocumento asociado por su id_tipo_documento
        TipoDocumento tipoDocumento = dao.getById(
            TipoDocumento.class,
            "tipos_documento",
            info.getId_tipo_documento()
        );
        // si no existe el TipoDocumento, retorna null para indicar fallo en construcción
        if (tipoDocumento == null) {
            return null;
        }

        // crea y retorna el DTO con todos los campos listos para enviar al frontend
        return new IcpResponseDTO(
            info.getId(),
            tipoDocumento,
            info.getNumero_documento(),
            info.getNombre(),
            info.getTelefono(),
            info.getCorreo(),
            info.getDireccion()
        );
    }

    /**
     * Construye un ClienteResponseDTO completo a partir de un objeto Cliente,
     * anidando su información personal transformada en IcpResponseDTO.
     *
     * @param cliente objeto Cliente que contiene id e id_info
     * @param dao DAO para obtener entidades relacionadas como InformacionClientesPersonal
     * @return ClienteResponseDTO con info personal anidada, o null si falta información
     */
    public static ClienteResponseDTO construirClienteDTO(Cliente cliente, CrudDAO dao) {
        // obtiene la información personal de la base de datos según id_info
        InformacionClientesPersonal info = dao.getById(
            InformacionClientesPersonal.class,
            "informacion_clientes_personal",
            cliente.getId_info()
        );

        // transforma la entidad de info en su DTO correspondiente
        IcpResponseDTO infoDTO = construirInfoDTO(info, dao);

        // si la transformación falla, retorna null para indicar ausencia de datos completos
        if (infoDTO == null) {
            return null;
        }

        // crea y retorna el DTO final del cliente con su información personal anidada
        return new ClienteResponseDTO(
            cliente.getId(),
            infoDTO
        );
    }
}
