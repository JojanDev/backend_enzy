package MODELO.DTO;

/**
 * DTO que representa un detalle dentro de una venta.
 *
 * Campos:
 * - idDetalleVenta: identificador unico del detalle de venta
 * - producto: nombre del producto, servicio o medicamento
 * - categoria: categoria del item
 * - precio: precio unitario del item
 * - cantidad: cantidad de unidades vendidas
 * - subtotal: subtotal calculado (precio * cantidad)
 * - valorAdicional: valor adicional aplicado al detalle
 */
public class DetalleVentaDTO {

    /**
     * identificador unico del detalle de venta
     */
    private int idDetalleVenta;

    /**
     * nombre del producto, servicio o medicamento
     */
    private String producto;

    /**
     * categoria del item (producto, servicio o medicamento)
     */
    private String categoria;

    /**
     * precio unitario del item
     */
    private double precio;

    /**
     * cantidad de unidades vendidas
     */
    private int cantidad;

    /**
     * subtotal calculado (precio * cantidad)
     */
    private double subtotal;

    /**
     * valor adicional aplicado al detalle
     */
    private double valorAdicional;

    /**
     * Obtiene el identificador unico del detalle de venta.
     *
     * @return idDetalleVenta del detalle
     */
    public int getIdDetalleVenta() {
        return idDetalleVenta;
    }

    /**
     * Asigna el identificador unico del detalle de venta.
     *
     * @param idDetalleVenta nuevo valor de idDetalleVenta
     */
    public void setIdDetalleVenta(int idDetalleVenta) {
        this.idDetalleVenta = idDetalleVenta;
    }

    /**
     * Obtiene el nombre del producto, servicio o medicamento.
     *
     * @return producto asociado al detalle
     */
    public String getProducto() {
        return producto;
    }

    /**
     * Asigna el nombre del producto, servicio o medicamento.
     *
     * @param producto nuevo nombre del item
     */
    public void setProducto(String producto) {
        this.producto = producto;
    }

    /**
     * Obtiene la categoria del item.
     *
     * @return categoria del detalle
     */
    public String getCategoria() {
        return categoria;
    }

    /**
     * Asigna la categoria del item.
     *
     * @param categoria nueva categoria del detalle
     */
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    /**
     * Obtiene el precio unitario del item.
     *
     * @return precio unitario
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * Asigna el precio unitario del item.
     *
     * @param precio nuevo precio unitario
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    /**
     * Obtiene la cantidad de unidades vendidas.
     *
     * @return cantidad de unidades
     */
    public int getCantidad() {
        return cantidad;
    }

    /**
     * Asigna la cantidad de unidades vendidas.
     *
     * @param cantidad nueva cantidad de unidades
     */
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    /**
     * Obtiene el subtotal calculado para el detalle.
     *
     * @return subtotal del detalle
     */
    public double getSubtotal() {
        return subtotal;
    }

    /**
     * Asigna el subtotal calculado para el detalle.
     *
     * @param subtotal nuevo valor de subtotal
     */
    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    /**
     * Obtiene el valor adicional aplicado al detalle.
     *
     * @return valorAdicional del detalle
     */
    public double getValorAdicional() {
        return valorAdicional;
    }

    /**
     * Asigna el valor adicional aplicado al detalle.
     *
     * @param valorAdicional nuevo valor adicional
     */
    public void setValorAdicional(double valorAdicional) {
        this.valorAdicional = valorAdicional;
    }
}
