package MODELO.DTO;

import MODELO.Raza;
import java.util.List;

/**
 * DTO de respuesta para representar una especie junto con sus razas asociadas.
 *
 * Campos:
 *   id     : identificador unico de la especie
 *   nombre : nombre comun de la especie (por ejemplo, "Perro", "Gato")
 *   razas  : lista de objetos Raza pertenecientes a esta especie
 */
public class EspecieResponseDTO {

    /** identificador unico de la especie */
    private int id;

    /** nombre comun de la especie */
    private String nombre;

    /** lista de razas asociadas a la especie */
    private List<Raza> razas;

    /**
     * Constructor con todos los campos de la respuesta.
     *
     * @param id     identificador unico de la especie
     * @param nombre nombre de la especie
     * @param razas  lista de objetos Raza asociados
     */
    public EspecieResponseDTO(int id, String nombre, List<Raza> razas) {
        // asigna el identificador de la especie
        this.id = id;
        // asigna el nombre de la especie
        this.nombre = nombre;
        // asigna la lista de razas asociadas
        this.razas = razas;
    }

    /**
     * Obtiene el identificador unico de la especie.
     *
     * @return identificador unico de la especie
     */
    public int getId() {
        // devuelve el valor del campo 'id'
        return id;
    }

    /**
     * Establece el identificador unico de la especie.
     *
     * @param id identificador unico a asignar
     */
    public void setId(int id) {
        // asigna el valor recibido al campo 'id'
        this.id = id;
    }

    /**
     * Obtiene el nombre de la especie.
     *
     * @return nombre de la especie
     */
    public String getNombre() {
        // devuelve el valor del campo 'nombre'
        return nombre;
    }

    /**
     * Establece el nombre de la especie.
     *
     * @param nombre nombre de la especie a asignar
     */
    public void setNombre(String nombre) {
        // asigna el valor recibido al campo 'nombre'
        this.nombre = nombre;
    }

    /**
     * Obtiene la lista de razas asociadas a la especie.
     *
     * @return lista de objetos Raza
     */
    public List<Raza> getRazas() {
        // devuelve el valor del campo 'razas'
        return razas;
    }

    /**
     * Establece la lista de razas asociadas a la especie.
     *
     * @param razas lista de objetos Raza a asignar
     */
    public void setRazas(List<Raza> razas) {
        // asigna la lista recibida al campo 'razas'
        this.razas = razas;
    }
}
