/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO.DTO;

import MODELO.Raza;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class EspecieConRazasGetResponseDTO {
    private int id;
    private String nombre;
    private List<Raza> razas;

    public EspecieConRazasGetResponseDTO(int id, String nombre, List<Raza> razas) {
        this.id = id;
        this.nombre = nombre;
        this.razas = razas;
    }

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Raza> getRazas() {
        return razas;
    }

    public void setRazas(List<Raza> razas) {
        this.razas = razas;
    }
}
