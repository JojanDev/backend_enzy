package MODELO.DTO;

import MODELO.MedicamentoInfo;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * DTO de respuesta para representar un registro de medicamento en inventario.
 *
 * Campos:
 *   id              : identificador único del registro de medicamento
 *   precio          : precio unitario del medicamento
 *   fecha_caducidad : fecha de caducidad del lote
 *   cantidad        : cantidad disponible en stock
 *   numero_lote     : número de lote del medicamento
 *   info            : información detallada del medicamento (MedicamentoInfo)
 */
public class MedicamentoResponseDTO {

    /** identificador único del registro de medicamento */
    private int id;

    /** precio unitario del medicamento */
    private BigDecimal precio;

    /** fecha de caducidad del lote */
    private LocalDate fecha_caducidad;

    /** cantidad disponible en stock */
    private int cantidad;

    /** número de lote del medicamento */
    private String numero_lote;

    /** información detallada del medicamento */
    private MedicamentoInfo info;

    /**
     * Obtiene el identificador único del medicamento en inventario.
     *
     * @return identificador del registro de medicamento
     */
    public int getId() {
        // devuelve el valor almacenado en 'id'
        return id;
    }

    /**
     * Establece el identificador único del medicamento en inventario.
     *
     * @param id identificador a asignar
     */
    public void setId(int id) {
        // asigna el valor recibido al campo 'id'
        this.id = id;
    }

    /**
     * Obtiene el precio unitario del medicamento.
     *
     * @return precio unitario
     */
    public BigDecimal getPrecio() {
        // devuelve el valor almacenado en 'precio'
        return precio;
    }

    /**
     * Establece el precio unitario del medicamento.
     *
     * @param precio precio a asignar
     */
    public void setPrecio(BigDecimal precio) {
        // asigna el valor recibido al campo 'precio'
        this.precio = precio;
    }

    /**
     * Obtiene la fecha de caducidad del lote del medicamento.
     *
     * @return fecha de caducidad
     */
    public LocalDate getFecha_caducidad() {
        // devuelve el valor almacenado en 'fecha_caducidad'
        return fecha_caducidad;
    }

    /**
     * Establece la fecha de caducidad del lote del medicamento.
     *
     * @param fecha_caducidad fecha a asignar
     */
    public void setFecha_caducidad(LocalDate fecha_caducidad) {
        // asigna el valor recibido al campo 'fecha_caducidad'
        this.fecha_caducidad = fecha_caducidad;
    }

    /**
     * Obtiene la cantidad disponible en stock.
     *
     * @return cantidad en stock
     */
    public int getCantidad() {
        // devuelve el valor almacenado en 'cantidad'
        return cantidad;
    }

    /**
     * Establece la cantidad disponible en stock.
     *
     * @param cantidad cantidad a asignar
     */
    public void setCantidad(int cantidad) {
        // asigna el valor recibido al campo 'cantidad'
        this.cantidad = cantidad;
    }

    /**
     * Obtiene el número de lote del medicamento.
     *
     * @return número de lote
     */
    public String getNumero_lote() {
        // devuelve el valor almacenado en 'numero_lote'
        return numero_lote;
    }

    /**
     * Establece el número de lote del medicamento.
     *
     * @param numero_lote número de lote a asignar
     */
    public void setNumero_lote(String numero_lote) {
        // asigna el valor recibido al campo 'numero_lote'
        this.numero_lote = numero_lote;
    }

    /**
     * Obtiene la información detallada del medicamento.
     *
     * @return objeto MedicamentoInfo con datos adicionales
     */
    public MedicamentoInfo getInfo() {
        // devuelve el valor almacenado en 'info'
        return info;
    }

    /**
     * Establece la información detallada del medicamento.
     *
     * @param info instancia de MedicamentoInfo a asignar
     */
    public void setInfo(MedicamentoInfo info) {
        // asigna el objeto recibido al campo 'info'
        this.info = info;
    }
}

