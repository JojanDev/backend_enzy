package MODELO.DTO;

import java.time.LocalDateTime;

/**
 * DTO de respuesta que representa un antecedente de mascota,
 * incluyendo información básica y fecha de registro.
 */
public class AntecedenteResponseDTO {

    /**
     * identificador único del antecedente
     */
    private int id;

    /**
     * datos de la mascota asociada al antecedente
     */
    private MascotaResponseDTO mascota;

    /**
     * titulo descriptivo del antecedente
     */
    private String titulo;

    /**
     * diagnostico realizado en el antecedente
     */
    private String diagnostico;

    /**
     * fecha y hora en que se registro el antecedente
     */
    private LocalDateTime fecha_creado;

    /**
     * Obtiene el identificador único del antecedente.
     *
     * @return id del antecedente
     */
    public int getId() {
        return id;
    }

    /**
     * Asigna el identificador único del antecedente.
     *
     * @param id nuevo valor de identificador
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene los datos de la mascota asociada.
     *
     * @return instancia de MascotaResponseDTO
     */
    public MascotaResponseDTO getMascota() {
        return mascota;
    }

    /**
     * Asigna los datos de la mascota asociada.
     *
     * @param mascota DTO con la informacion de la mascota
     */
    public void setMascota(MascotaResponseDTO mascota) {
        this.mascota = mascota;
    }

    /**
     * Obtiene el titulo descriptivo del antecedente.
     *
     * @return titulo del antecedente
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * Asigna el titulo descriptivo del antecedente.
     *
     * @param titulo nuevo titulo a establecer
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * Obtiene el diagnostico registrado en el antecedente.
     *
     * @return diagnostico del antecedente
     */
    public String getDiagnostico() {
        return diagnostico;
    }

    /**
     * Asigna el diagnostico del antecedente.
     *
     * @param diagnostico nueva descripcion diagnostica
     */
    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    /**
     * Obtiene la fecha y hora en que se registro el antecedente.
     *
     * @return fecha de creacion del antecedente
     */
    public LocalDateTime getFecha_creado() {
        return fecha_creado;
    }

    /**
     * Asigna la fecha y hora de registro del antecedente.
     *
     * @param fecha_creado nueva fecha y hora a asignar
     */
    public void setFecha_creado(LocalDateTime fecha_creado) {
        this.fecha_creado = fecha_creado;
    }
}
