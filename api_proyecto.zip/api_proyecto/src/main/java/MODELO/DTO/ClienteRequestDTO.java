package MODELO.DTO;

/**
 * DTO de solicitud para crear o actualizar un cliente.
 *
 * Campos:
 * - idTipoDocumento: clave foránea al tipo de documento del cliente
 * - numeroDocumento: número del documento de identificación
 * - nombre: nombre completo del cliente
 * - telefono: número de teléfono de contacto
 * - correo: dirección de correo electrónico
 * - direccion: dirección física del cliente
 */
public class ClienteRequestDTO {

    private int idTipoDocumento;
    private String numeroDocumento;
    private String nombre;
    private String telefono;
    private String correo;
    private String direccion;

    /**
     * Obtiene la clave de tipo de documento del cliente.
     *
     * @return idTipoDocumento del cliente
     */
    public int getIdTipoDocumento() {
        return idTipoDocumento;
    }

    /**
     * Asigna la clave de tipo de documento del cliente.
     *
     * @param idTipoDocumento nueva clave de tipo de documento
     */
    public void setIdTipoDocumento(int idTipoDocumento) {
        this.idTipoDocumento = idTipoDocumento;
    }

    /**
     * Obtiene el número de documento de identificación.
     *
     * @return numeroDocumento del cliente
     */
    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    /**
     * Asigna el número de documento de identificación.
     *
     * @param numeroDocumento nuevo número de documento
     */
    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    /**
     * Obtiene el nombre completo del cliente.
     *
     * @return nombre del cliente
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Asigna el nombre completo del cliente.
     *
     * @param nombre nuevo nombre del cliente
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el número de teléfono de contacto.
     *
     * @return telefono del cliente
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * Asigna el número de teléfono de contacto.
     *
     * @param telefono nuevo teléfono del cliente
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * Obtiene la dirección de correo electrónico.
     *
     * @return correo del cliente
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * Asigna la dirección de correo electrónico.
     *
     * @param correo nueva dirección de correo electrónico
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    /**
     * Obtiene la dirección física del cliente.
     *
     * @return direccion del cliente
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * Asigna la dirección física del cliente.
     *
     * @param direccion nueva dirección física
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}


