package MODELO.DTO;

import MODELO.TipoDocumento;

/**
 * DTO de respuesta para la informacion de clientes personal.
 * Se utiliza para enviar al frontend los datos anidados
 * del objeto TipoDocumento junto con la informacion de contacto.
 */
public class IcpResponseDTO {

    private int id;
    private TipoDocumento tipoDocumento;
    private String numero_documento;
    private String nombre;
    private String telefono;
    private String correo;
    private String direccion;

    /**
     * Constructor completo que inicializa todos los campos del DTO.
     *
     * @param id               identificador unico de la informacion
     * @param tipoDocumento    objeto TipoDocumento anidado con su metadata
     * @param numero_documento numero de documento del cliente o empleado
     * @param nombre           nombre completo del cliente o empleado
     * @param telefono         numero de telefono de contacto
     * @param correo           direccion de correo electronico
     * @param direccion        direccion fisica del cliente o empleado
     */
    public IcpResponseDTO(
            int id,
            TipoDocumento tipoDocumento,
            String numero_documento,
            String nombre,
            String telefono,
            String correo,
            String direccion) {
        // asigna el parametro id al atributo id de la instancia
        this.id = id;
        // asigna el objeto TipoDocumento al atributo correspondiente
        this.tipoDocumento = tipoDocumento;
        // asigna el numero de documento al atributo numero_documento
        this.numero_documento = numero_documento;
        // asigna el nombre al atributo nombre
        this.nombre = nombre;
        // asigna el telefono al atributo telefono
        this.telefono = telefono;
        // asigna el correo al atributo correo
        this.correo = correo;
        // asigna la direccion al atributo direccion
        this.direccion = direccion;
    }

    /**
     * Obtiene el identificador unico de la informacion.
     *
     * @return valor del atributo id
     */
    public int getId() {
        // retorna el valor almacenado en id
        return id;
    }

    /**
     * Asigna el identificador unico de la informacion.
     *
     * @param id nuevo identificador a establecer
     */
    public void setId(int id) {
        // actualiza el atributo id con el valor proporcionado
        this.id = id;
    }

    /**
     * Obtiene el objeto TipoDocumento anidado.
     *
     * @return instancia de TipoDocumento
     */
    public TipoDocumento getTipoDocumento() {
        // retorna el objeto TipoDocumento asociado
        return tipoDocumento;
    }

    /**
     * Asigna el objeto TipoDocumento anidado.
     *
     * @param tipoDocumento instancia de TipoDocumento a establecer
     */
    public void setTipoDocumento(TipoDocumento tipoDocumento) {
        // actualiza el atributo tipoDocumento con la instancia proporcionada
        this.tipoDocumento = tipoDocumento;
    }

    /**
     * Obtiene el numero de documento.
     *
     * @return valor del atributo numero_documento
     */
    public String getNumeroDocumento() {
        // retorna el numero de documento almacenado
        return numero_documento;
    }

    /**
     * Asigna el numero de documento.
     *
     * @param numeroDocumento nuevo numero de documento a establecer
     */
    public void setNumeroDocumento(String numeroDocumento) {
        // actualiza el atributo numero_documento con el valor proporcionado
        this.numero_documento = numeroDocumento;
    }

    /**
     * Obtiene el nombre completo del cliente o empleado.
     *
     * @return valor del atributo nombre
     */
    public String getNombre() {
        // retorna el nombre almacenado
        return nombre;
    }

    /**
     * Asigna el nombre completo del cliente o empleado.
     *
     * @param nombre nuevo nombre a establecer
     */
    public void setNombre(String nombre) {
        // actualiza el atributo nombre con el valor proporcionado
        this.nombre = nombre;
    }

    /**
     * Obtiene el numero de telefono de contacto.
     *
     * @return valor del atributo telefono
     */
    public String getTelefono() {
        // retorna el telefono almacenado
        return telefono;
    }

    /**
     * Asigna el numero de telefono de contacto.
     *
     * @param telefono nuevo telefono a establecer
     */
    public void setTelefono(String telefono) {
        // actualiza el atributo telefono con el valor proporcionado
        this.telefono = telefono;
    }

    /**
     * Obtiene la direccion de correo electronico.
     *
     * @return valor del atributo correo
     */
    public String getCorreo() {
        // retorna el correo almacenado
        return correo;
    }

    /**
     * Asigna la direccion de correo electronico.
     *
     * @param correo nueva direccion de correo a establecer
     */
    public void setCorreo(String correo) {
        // actualiza el atributo correo con el valor proporcionado
        this.correo = correo;
    }

    /**
     * Obtiene la direccion fisica del cliente o empleado.
     *
     * @return valor del atributo direccion
     */
    public String getDireccion() {
        // retorna la direccion almacenada
        return direccion;
    }

    /**
     * Asigna la direccion fisica del cliente o empleado.
     *
     * @param direccion nueva direccion a establecer
     */
    public void setDireccion(String direccion) {
        // actualiza el atributo direccion con el valor proporcionado
        this.direccion = direccion;
    }
}
