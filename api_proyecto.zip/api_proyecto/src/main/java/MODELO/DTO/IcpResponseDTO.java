/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO.DTO;

import MODELO.TipoDocumento;

/**
 *
 * @author USUARIO
 * Clase de Informacion Clientes Personal Get Response DTO
 * Es una clase que se usa para enviar informacion al frontend anidando el objeto TipoDocumento
 */
public class IcpResponseDTO {
    private int id;
    private TipoDocumento tipoDocumento;
    private String numero_documento;
    private String nombre;
    private String telefono;
    private String correo;
    private String direccion;

    // Constructor completo
    public IcpResponseDTO(int id, TipoDocumento tipoDocumento, String numero_documento,
                             String nombre, String telefono, String correo, String direccion) {
        this.id = id;
        this.tipoDocumento = tipoDocumento;
        this.numero_documento = numero_documento;
        this.nombre = nombre;
        this.telefono = telefono;
        this.correo = correo;
        this.direccion = direccion;
    }
    
    // Getters y Setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public TipoDocumento getTipoDocumento() {
        return tipoDocumento;
    }
    public void setTipoDocumento(TipoDocumento tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNumeroDocumento() {
        return numero_documento;
    }
    public void setNumeroDocumento(String numeroDocumento) {
        this.numero_documento = numeroDocumento;
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}
