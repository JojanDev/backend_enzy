package MODELO.DTO;

import MODELO.MedicamentoInfo;

/**
 * DTO de respuesta que representa la relación entre un tratamiento y un medicamento.
 * Incluye detalles de dosis, frecuencia y duración formateada.
 *
 * Campos:
 * - id: identificador único de la relación
 * - id_tratamiento: clave foránea al tratamiento asociado
 * - medicamento: objeto con la información base del medicamento
 * - dosis: indicación de la dosis a aplicar
 * - frecuencia_aplicacion: frecuencia con que se aplica la dosis
 * - duracion: duración en unidades (días, semanas, etc.)
 * - duracionFormateada: representación de la duración en texto legible
 */
public class MedicamentoTratamientoResponseDTO {

    private int id;
    private int id_tratamiento;
    private MedicamentoInfo medicamento;
    private String dosis;
    private String frecuencia_aplicacion;
    private int duracion;
    private String[] duracionFormateada;

    /**
     * Obtiene el identificador único de la relación medicamento-tratamiento.
     *
     * @return id de la relación
     */
    public int getId() {
        // retorna el valor del atributo id
        return id;
    }

    /**
     * Asigna el identificador único de la relación medicamento-tratamiento.
     *
     * @param id nuevo identificador a establecer
     */
    public void setId(int id) {
        // actualiza el atributo id con el valor proporcionado
        this.id = id;
    }

    /**
     * Obtiene la clave foránea al tratamiento asociado.
     *
     * @return id_tratamiento del tratamiento
     */
    public int getId_tratamiento() {
        // retorna el valor del atributo id_tratamiento
        return id_tratamiento;
    }

    /**
     * Asigna la clave foránea al tratamiento asociado.
     *
     * @param id_tratamiento nuevo id_tratamiento a establecer
     */
    public void setId_tratamiento(int id_tratamiento) {
        // actualiza el atributo id_tratamiento con el valor proporcionado
        this.id_tratamiento = id_tratamiento;
    }

    /**
     * Obtiene el objeto MedicamentoInfo asociado.
     *
     * @return instancia de MedicamentoInfo
     */
    public MedicamentoInfo getMedicamento() {
        // retorna el objeto medicamento almacenado
        return medicamento;
    }

    /**
     * Asigna el objeto MedicamentoInfo asociado.
     *
     * @param medicamento instancia de MedicamentoInfo a establecer
     */
    public void setMedicamento(MedicamentoInfo medicamento) {
        // actualiza el atributo medicamento con la instancia proporcionada
        this.medicamento = medicamento;
    }

    /**
     * Obtiene la dosis indicada para el tratamiento.
     *
     * @return dosis a aplicar
     */
    public String getDosis() {
        // retorna el valor del atributo dosis
        return dosis;
    }

    /**
     * Asigna la dosis indicada para el tratamiento.
     *
     * @param dosis nueva dosis a establecer
     */
    public void setDosis(String dosis) {
        // actualiza el atributo dosis con el valor proporcionado
        this.dosis = dosis;
    }

    /**
     * Obtiene la frecuencia de aplicación de la dosis.
     *
     * @return frecuencia_aplicacion del tratamiento
     */
    public String getFrecuencia_aplicacion() {
        // retorna el valor del atributo frecuencia_aplicacion
        return frecuencia_aplicacion;
    }

    /**
     * Asigna la frecuencia de aplicación de la dosis.
     *
     * @param frecuencia_aplicacion nueva frecuencia a establecer
     */
    public void setFrecuencia_aplicacion(String frecuencia_aplicacion) {
        // actualiza el atributo frecuencia_aplicacion con el valor proporcionado
        this.frecuencia_aplicacion = frecuencia_aplicacion;
    }

    /**
     * Obtiene la duración en unidades numéricas.
     *
     * @return duracion del tratamiento
     */
    public int getDuracion() {
        // retorna el valor del atributo duracion
        return duracion;
    }

    /**
     * Asigna la duración en unidades numéricas.
     *
     * @param duracion nueva duración a establecer
     */
    public void setDuracion(int duracion) {
        // actualiza el atributo duracion con el valor proporcionado
        this.duracion = duracion;
    }

    /**
     * Obtiene la duración formateada en texto legible.
     *
     * @return array de cadenas con la duración formateada
     */
    public String[] getDuracionFormateada() {
        // retorna el array de duracionFormateada
        return duracionFormateada;
    }

    /**
     * Asigna la duración formateada en texto legible.
     *
     * @param duracionFormateada array de cadenas a establecer
     */
    public void setDuracionFormateada(String[] duracionFormateada) {
        // actualiza el atributo duracionFormateada con el array proporcionado
        this.duracionFormateada = duracionFormateada;
    }
}

