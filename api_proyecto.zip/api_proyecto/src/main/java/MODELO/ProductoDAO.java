package MODELO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Clase que maneja las operaciones de acceso a datos para la entidad Producto.
 * Proporciona m�todos para gestionar el stock de productos.
 */
public class ProductoDAO {

    /**
     * Resta una cantidad espec�fica del stock del producto.
     *
     * @param idProducto ID del producto.
     * @param cantidadRestar Cantidad a descontar.
     * @return true si la operaci�n fue exitosa, false en caso contrario.
     */
    public boolean restarStock(int idProducto, int cantidadRestar) {
        // Consulta SQL para restar una cantidad del stock del producto
        String sql = "UPDATE productos SET stock = stock - ? WHERE id = ?";

        // Usa try-with-resources para asegurar el cierre de recursos
        try (Connection con = ConexionBD.conectar(); 
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, cantidadRestar); // Establece la cantidad a restar
            ps.setInt(2, idProducto); // Establece el ID del producto

            int filasAfectadas = ps.executeUpdate(); // Ejecuta la actualizaci�n y obtiene el n�mero de filas afectadas
            return filasAfectadas > 0; // Retorna true si se afectaron filas, false si no

        } catch (SQLException e) {
            System.err.println("Error al restar stock de producto: " + e.getMessage()); // Manejo de errores
            return false; // Retorna false en caso de error
        }
    }
}
