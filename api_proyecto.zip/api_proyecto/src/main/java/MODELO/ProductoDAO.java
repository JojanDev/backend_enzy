package MODELO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ProductoDAO {

    /**
     * Resta una cantidad específica del stock del producto.
     * @param idProducto ID del producto.
     * @param cantidadRestar Cantidad a descontar.
     * @return true si la operación fue exitosa.
     */
    public boolean restarStock(int idProducto, int cantidadRestar) {
        String sql = "UPDATE productos SET stock = stock - ? WHERE id = ?";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, cantidadRestar);
            ps.setInt(2, idProducto);

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al restar stock de producto: " + e.getMessage());
            return false;
        }
    }
}
