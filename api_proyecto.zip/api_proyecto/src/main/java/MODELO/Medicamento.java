package MODELO;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Modelo que representa un medicamento en inventario.
 *
 * Campos:
 * - id: identificador unico del medicamento
 * - id_medicamento_info: referencia a la informacion base del medicamento
 * - precio: precio unitario del medicamento
 * - fecha_caducidad: fecha de caducidad del medicamento
 * - cantidad: cantidad disponible en inventario
 * - numero_lote: numero de lote del medicamento
 */
public class Medicamento {

    /**
     * identificador unico del medicamento
     */
    private int id;

    /**
     * clave foranea a MedicamentoInfo con datos base del medicamento
     */
    private int id_medicamento_info;

    /**
     * precio unitario del medicamento
     */
    private BigDecimal precio;

    /**
     * fecha de caducidad del medicamento
     */
    private LocalDate fecha_caducidad;

    /**
     * cantidad de unidades disponibles en inventario
     */
    private int cantidad;

    /**
     * numero de lote asignado al medicamento
     */
    private String numero_lote;

    /**
     * Obtiene el identificador unico del medicamento.
     *
     * @return id del medicamento
     */
    public int getId() {
        return id;
    }

    /**
     * Asigna el identificador unico del medicamento.
     *
     * @param id nuevo valor de id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene la clave foranea a la informacion base del medicamento.
     *
     * @return id_medicamento_info
     */
    public int getId_medicamento_info() {
        return id_medicamento_info;
    }

    /**
     * Asigna la clave foranea a la informacion base del medicamento.
     *
     * @param id_medicamento_info nuevo valor de id_medicamento_info
     */
    public void setId_medicamento_info(int id_medicamento_info) {
        this.id_medicamento_info = id_medicamento_info;
    }

    /**
     * Obtiene el precio unitario del medicamento.
     *
     * @return precio
     */
    public BigDecimal getPrecio() {
        return precio;
    }

    /**
     * Asigna el precio unitario del medicamento.
     *
     * @param precio nuevo valor de precio
     */
    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    /**
     * Obtiene la fecha de caducidad del medicamento.
     *
     * @return fecha_caducidad
     */
    public LocalDate getFecha_caducidad() {
        return fecha_caducidad;
    }

    /**
     * Asigna la fecha de caducidad del medicamento.
     *
     * @param fecha_caducidad nuevo valor de fecha_caducidad
     */
    public void setFecha_caducidad(LocalDate fecha_caducidad) {
        this.fecha_caducidad = fecha_caducidad;
    }

    /**
     * Obtiene la cantidad de unidades disponibles.
     *
     * @return cantidad
     */
    public int getCantidad() {
        return cantidad;
    }

    /**
     * Asigna la cantidad de unidades disponibles.
     *
     * @param cantidad nuevo valor de cantidad
     */
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    /**
     * Obtiene el numero de lote del medicamento.
     *
     * @return numero_lote
     */
    public String getNumero_lote() {
        return numero_lote;
    }

    /**
     * Asigna el numero de lote del medicamento.
     *
     * @param numero_lote nuevo valor de numero_lote
     */
    public void setNumero_lote(String numero_lote) {
        this.numero_lote = numero_lote;
    }
}
