package MODELO;

/**
 * Representa una especie de mascota dentro del sistema.
 *
 * Campos:
 *   id     : identificador unico de la especie (clave primaria)
 *   nombre : nombre comun de la especie (por ejemplo, perro, gato)
 */
public class Especie {

    /** identificador unico de la especie (clave primaria) */
    private int id;

    /** nombre comun de la especie */
    private String nombre;

    /**
     * Constructor vacio para soporte de reflexion y frameworks.
     */
    public Especie() {
        // constructor por defecto
    }
    
    /**
     * Obtiene el identificador unico de la especie.
     *
     * @return identificador unico de la especie
     */
    public int getId() {
        // devuelve el valor del campo 'id'
        return id;
    }

    /**
     * Establece el identificador unico de la especie.
     *
     * @param id identificador unico a asignar
     */
    public void setId(int id) {
        // asigna el valor recibido al campo 'id'
        this.id = id;
    }

    /**
     * Obtiene el nombre de la especie.
     *
     * @return nombre de la especie
     */
    public String getNombre() {
        // devuelve el valor del campo 'nombre'
        return nombre;
    }

    /**
     * Establece el nombre de la especie.
     *
     * @param nombre nombre de la especie a asignar
     */
    public void setNombre(String nombre) {
        // asigna el valor recibido al campo 'nombre'
        this.nombre = nombre;
    }
}
