package MODELO;

import java.math.BigDecimal;

/**
 * Representa un servicio disponible en la veterinaria.
 *
 * Campos:
 *   id         : identificador unico del servicio (clave primaria)
 *   nombre     : nombre descriptivo del servicio
 *   descripcion: descripcion detallada de lo que incluye el servicio
 *   precio     : costo unitario del servicio
 */
public class Servicio {

    /** identificador unico del servicio (clave primaria) */
    private int id;

    /** nombre descriptivo del servicio */
    private String nombre;

    /** descripcion detallada del servicio */
    private String descripcion;

    /** costo unitario del servicio */
    private BigDecimal precio;

    /**
     * Obtiene el identificador unico del servicio.
     *
     * @return identificador unico del servicio
     */
    public int getId() {
        // devuelve el valor del campo 'id'
        return id;
    }

    /**
     * Establece el identificador unico del servicio.
     *
     * @param id identificador unico a asignar
     */
    public void setId(int id) {
        // asigna el valor recibido al campo 'id'
        this.id = id;
    }

    /**
     * Obtiene el nombre descriptivo del servicio.
     *
     * @return nombre del servicio
     */
    public String getNombre() {
        // devuelve el valor del campo 'nombre'
        return nombre;
    }

    /**
     * Establece el nombre descriptivo del servicio.
     *
     * @param nombre nombre a asignar al servicio
     */
    public void setNombre(String nombre) {
        // asigna el valor recibido al campo 'nombre'
        this.nombre = nombre;
    }

    /**
     * Obtiene la descripcion detallada del servicio.
     *
     * @return descripcion del servicio
     */
    public String getDescripcion() {
        // devuelve el valor del campo 'descripcion'
        return descripcion;
    }

    /**
     * Establece la descripcion detallada del servicio.
     *
     * @param descripcion descripcion a asignar al servicio
     */
    public void setDescripcion(String descripcion) {
        // asigna el valor recibido al campo 'descripcion'
        this.descripcion = descripcion;
    }

    /**
     * Obtiene el costo unitario del servicio.
     *
     * @return precio unitario del servicio
     */
    public BigDecimal getPrecio() {
        // devuelve el valor del campo 'precio'
        return precio;
    }

    /**
     * Establece el costo unitario del servicio.
     *
     * @param precio precio a asignar al servicio
     */
    public void setPrecio(BigDecimal precio) {
        // asigna el valor recibido al campo 'precio'
        this.precio = precio;
    }
}
