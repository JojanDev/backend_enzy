package MODELO;

/**
 * Representa una raza de mascota dentro del sistema.
 *
 * Campos:
 *   id         : identificador unico de la raza (clave primaria)
 *   nombre     : nombre de la raza (por ejemplo, "Bulldog")
 *   id_especie : identificador de la especie a la que pertenece la raza
 */
public class Raza {

    /** identificador unico de la raza (clave primaria) */
    private int id;

    /** nombre de la raza */
    private String nombre;

    /** identificador de la especie a la que pertenece la raza */
    private int id_especie;

    /**
     * Constructor vacio requerido para reflexion y frameworks.
     */
    public Raza() {
        // constructor por defecto
    }

    /**
     * Obtiene el identificador unico de la raza.
     *
     * @return identificador unico de la raza
     */
    public int getId() {
        // devuelve el valor del campo 'id'
        return id;
    }

    /**
     * Establece el identificador unico de la raza.
     *
     * @param id identificador unico de la raza a asignar
     */
    public void setId(int id) {
        // asigna el valor recibido al campo 'id'
        this.id = id;
    }

    /**
     * Obtiene el nombre de la raza.
     *
     * @return nombre de la raza
     */
    public String getNombre() {
        // devuelve el valor del campo 'nombre'
        return nombre;
    }

    /**
     * Establece el nombre de la raza.
     *
     * @param nombre nombre de la raza a asignar
     */
    public void setNombre(String nombre) {
        // asigna el valor recibido al campo 'nombre'
        this.nombre = nombre;
    }

    /**
     * Obtiene el identificador de la especie asociada.
     *
     * @return identificador de la especie
     */
    public int getId_especie() {
        // devuelve el valor del campo 'id_especie'
        return id_especie;
    }

    /**
     * Establece el identificador de la especie asociada.
     *
     * @param id_especie identificador de la especie a asignar
     */
    public void setId_especie(int id_especie) {
        // asigna el valor recibido al campo 'id_especie'
        this.id_especie = id_especie;
    }
}


