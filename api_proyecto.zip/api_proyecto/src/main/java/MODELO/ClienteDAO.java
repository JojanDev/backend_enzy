/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class ClienteDAO {

    public List<InformacionClientesPersonal> getClientesSinEmpleado() {
        List<InformacionClientesPersonal> lista = new ArrayList<>();

        String sql = """
            SELECT i.id, i.id_tipo_documento, i.numero_documento, 
                   i.nombre, i.telefono, i.correo, i.direccion
            FROM informacion_clientes_personal i
            JOIN clientes c ON c.id_info = i.id
            LEFT JOIN personal p ON p.id_info = i.id
            WHERE p.id IS NULL
        """;

        try (Connection con = ConexionBD.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                InformacionClientesPersonal info = new InformacionClientesPersonal();
                info.setId(rs.getInt("id"));
                info.setId_tipo_documento(rs.getInt("id_tipo_documento"));
                info.setNumero_documento(rs.getString("numero_documento"));
                info.setNombre(rs.getString("nombre"));
                info.setTelefono(rs.getString("telefono"));
                info.setCorreo(rs.getString("correo"));
                info.setDireccion(rs.getString("direccion"));
                lista.add(info);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

}
