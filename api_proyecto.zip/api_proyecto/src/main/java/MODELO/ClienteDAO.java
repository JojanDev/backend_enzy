/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase que maneja las operaciones de acceso a datos para la entidad Cliente.
 * Proporciona m�todos para recuperar informaci�n de clientes que no est�n asociados a un empleado.
 * 
 * @author USUARIO
 */
public class ClienteDAO {

    /**
     * Recupera una lista de clientes que no est�n asociados a ning�n empleado.
     *
     * @return Lista de objetos InformacionClientesPersonal que representan a los clientes sin empleado.
     */
    public List<InformacionClientesPersonal> getClientesSinEmpleado() {
        List<InformacionClientesPersonal> lista = new ArrayList<>(); // Lista para almacenar los clientes

        // Consulta SQL para obtener informaci�n de clientes sin empleado asociado
        String sql = """
            SELECT i.id, i.id_tipo_documento, i.numero_documento, 
                   i.nombre, i.telefono, i.correo, i.direccion
            FROM informacion_clientes_personal i
            JOIN clientes c ON c.id_info = i.id
            LEFT JOIN personal p ON p.id_info = i.id
            WHERE p.id IS NULL
        """;

        // Usa try-with-resources para asegurar el cierre de recursos
        try (Connection con = ConexionBD.conectar(); 
             PreparedStatement ps = con.prepareStatement(sql); 
             ResultSet rs = ps.executeQuery()) {

            // Itera sobre los resultados de la consulta
            while (rs.next()) {
                InformacionClientesPersonal info = new InformacionClientesPersonal(); // Crea una nueva instancia de InformacionClientesPersonal
                info.setId(rs.getInt("id")); // Establece el ID del cliente
                info.setId_tipo_documento(rs.getInt("id_tipo_documento")); // Establece el tipo de documento
                info.setNumero_documento(rs.getString("numero_documento")); // Establece el n�mero de documento
                info.setNombre(rs.getString("nombre")); // Establece el nombre del cliente
                info.setTelefono(rs.getString("telefono")); // Establece el tel�fono del cliente
                info.setCorreo(rs.getString("correo")); // Establece el correo del cliente
                info.setDireccion(rs.getString("direccion")); // Establece la direcci�n del cliente
                lista.add(info); // Agrega el objeto a la lista
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de errores
        }

        return lista; // Retorna la lista de clientes
    }

}
