package MODELO;

import java.time.LocalDateTime;

/**
 * Modelo que representa un tratamiento aplicado a un antecedente de mascota.
 *
 * Campos:
 * - id: identificador unico del tratamiento
 * - id_antecedente: clave foranea al antecedente asociado
 * - id_personal: clave foranea al empleado que realizo el tratamiento
 * - titulo: titulo descriptivo del tratamiento
 * - descripcion: detalles del tratamiento
 * - fecha_creado: fecha y hora de registro del tratamiento
 * - activo: indica si el tratamiento esta vigente
 */
public class Tratamiento {

    /**
     * identificador unico del tratamiento
     */
    private int id;

    /**
     * clave foranea al antecedente de la mascota
     */
    private int id_antecedente;

    /**
     * clave foranea al empleado que realizo el tratamiento
     */
    private int id_personal;

    /**
     * titulo descriptivo del tratamiento
     */
    private String titulo;

    /**
     * descripcion detallada del tratamiento
     */
    private String descripcion;

    /**
     * fecha y hora en que se registro el tratamiento
     */
    private LocalDateTime fecha_creado;

    /**
     * estado del tratamiento: true si esta activo, false si esta inactivo
     */
    private boolean activo;

    /**
     * Constructor sin argumentos para uso de frameworks y mapeo.
     */
    public Tratamiento() {
    }

    /**
     * Obtiene el identificador unico del tratamiento.
     *
     * @return id del tratamiento
     */
    public int getId() {
        return id;
    }

    /**
     * Asigna el identificador unico del tratamiento.
     *
     * @param id nuevo valor de id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene la clave foranea al antecedente asociado.
     *
     * @return id_antecedente del antecedente
     */
    public int getId_antecedente() {
        return id_antecedente;
    }

    /**
     * Asigna la clave foranea al antecedente asociado.
     *
     * @param id_antecedente nuevo valor de id_antecedente
     */
    public void setId_antecedente(int id_antecedente) {
        this.id_antecedente = id_antecedente;
    }

    /**
     * Obtiene la clave foranea al empleado que realizo el tratamiento.
     *
     * @return id_personal del empleado
     */
    public int getId_personal() {
        return id_personal;
    }

    /**
     * Asigna la clave foranea al empleado que realizo el tratamiento.
     *
     * @param id_personal nuevo valor de id_personal
     */
    public void setId_personal(int id_personal) {
        this.id_personal = id_personal;
    }

    /**
     * Obtiene el titulo descriptivo del tratamiento.
     *
     * @return titulo del tratamiento
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * Asigna el titulo descriptivo del tratamiento.
     *
     * @param titulo nuevo valor de titulo
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * Obtiene la descripcion detallada del tratamiento.
     *
     * @return descripcion del tratamiento
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Asigna la descripcion detallada del tratamiento.
     *
     * @param descripcion nuevo valor de descripcion
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Obtiene la fecha y hora en que se registro el tratamiento.
     *
     * @return fecha_creado del tratamiento
     */
    public LocalDateTime getFecha_creado() {
        return fecha_creado;
    }

    /**
     * Asigna la fecha y hora en que se registro el tratamiento.
     *
     * @param fecha_creado nuevo valor de fecha_creado
     */
    public void setFecha_creado(LocalDateTime fecha_creado) {
        this.fecha_creado = fecha_creado;
    }

    /**
     * Indica si el tratamiento esta vigente.
     *
     * @return true si activo, false si inactivo
     */
    public boolean isActivo() {
        return activo;
    }

    /**
     * Marca el estado vigente del tratamiento.
     *
     * @param activo true para activo, false para inactivo
     */
    public void setActivo(boolean activo) {
        this.activo = activo;
    }
}
