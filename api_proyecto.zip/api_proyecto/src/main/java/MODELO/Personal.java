package MODELO;

public class Personal {
    private int id;
    private int id_info;
    private String contrasena;
    private int id_rol; 
    private String usuario;
    private boolean activo; 
    
    public Personal() {}

    public Personal(int id, int id_info, String contrasena, String usuario, int id_rol) {
        this.id = id;
        this.id_info = id_info;
        this.id_rol = id_rol;
        this.contrasena = contrasena;
//        this.roles = roles;
        this.usuario = usuario;
    }

    public int getId_rol() {
        return id_rol;
    }

    public void setId_rol(int id_rol) {
        this.id_rol = id_rol;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_info() {
        return id_info;
    }

    public void setId_info(int id_info) {
        this.id_info = id_info;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

//    public String getRoles() {
//        return roles;
//    }
//
//    public void setRoles(String roles) {
//        this.roles = roles;
//    }
    
    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
}
