package MODELO;

/**
 * Modelo que representa un empleado del sistema.
 *
 * Campos:
 * - id: identificador único del empleado
 * - id_info: clave foránea a la información personal del cliente
 * - contrasena: clave de acceso del empleado
 * - usuario: nombre de usuario para autenticación
 * - id_rol: clave foránea al rol que define sus permisos
 * - activo: indica si la cuenta está activa
 */
public class Personal {

    /**
     * identificador único del empleado
     */
    private int id;

    /**
     * clave foránea a InformacionClientesPersonal
     */
    private int id_info;

    /**
     * clave de acceso del empleado
     */
    private String contrasena;

    /**
     * nombre de usuario para autenticación
     */
    private String usuario;

    /**
     * clave foránea al rol asignado
     */
    private int id_rol;

    /**
     * indica si la cuenta está activa (true) o desactivada (false)
     */
    private boolean activo;

    /**
     * Constructor sin argumentos para uso de frameworks y mapeo.
     */
    public Personal() {
    }

    /**
     * Constructor que inicializa los campos principales del empleado.
     *
     * @param id            identificador del empleado
     * @param id_info       clave foránea a la información personal
     * @param contrasena    clave de acceso del empleado
     * @param usuario       nombre de usuario para autenticación
     * @param id_rol        clave foránea al rol asignado
     */
    public Personal(int id, int id_info, String contrasena, String usuario, int id_rol) {
        this.id = id;
        this.id_info = id_info;
        this.contrasena = contrasena;
        this.usuario = usuario;
        this.id_rol = id_rol;
    }

    /**
     * Obtiene el identificador del empleado.
     *
     * @return id del empleado
     */
    public int getId() {
        return id;
    }

    /**
     * Asigna el identificador del empleado.
     *
     * @param id nuevo valor de id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene la clave foránea a la información personal.
     *
     * @return id_info de la información personal
     */
    public int getId_info() {
        return id_info;
    }

    /**
     * Asigna la clave foránea a la información personal.
     *
     * @param id_info nuevo valor de id_info
     */
    public void setId_info(int id_info) {
        this.id_info = id_info;
    }

    /**
     * Obtiene la clave de acceso del empleado.
     *
     * @return contrasena del empleado
     */
    public String getContrasena() {
        return contrasena;
    }

    /**
     * Asigna la clave de acceso del empleado.
     *
     * @param contrasena nuevo valor de contrasena
     */
    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    /**
     * Obtiene el nombre de usuario para autenticación.
     *
     * @return usuario del empleado
     */
    public String getUsuario() {
        return usuario;
    }

    /**
     * Asigna el nombre de usuario para autenticación.
     *
     * @param usuario nuevo valor de usuario
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    /**
     * Obtiene la clave foránea al rol asignado.
     *
     * @return id_rol del empleado
     */
    public int getId_rol() {
        return id_rol;
    }

    /**
     * Asigna la clave foránea al rol asignado.
     *
     * @param id_rol nuevo valor de id_rol
     */
    public void setId_rol(int id_rol) {
        this.id_rol = id_rol;
    }

    /**
     * Indica si la cuenta del empleado está activa.
     *
     * @return true si está activa, false si está desactivada
     */
    public boolean isActivo() {
        return activo;
    }

    /**
     * Marca el estado activo o desactivado de la cuenta.
     *
     * @param activo true para activa, false para desactivada
     */
    public void setActivo(boolean activo) {
        this.activo = activo;
    }
}
