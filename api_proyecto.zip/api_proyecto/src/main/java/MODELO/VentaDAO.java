package MODELO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase DAO encargada de gestionar operaciones relacionadas con la entidad Venta.
 * Permite actualizar el monto pagado y obtener el perfil completo de una venta.
 */
public class VentaDAO {

    /**
     * Actualiza el monto pagado de una venta. Si el nuevo monto acumulado es igual o
     * mayor al total de la venta, se actualiza el estado a "completada".
     *
     * @param idVenta ID de la venta a actualizar.
     * @param montoNuevo Monto adicional que se desea sumar al monto actual.
     * @return true si la actualizaci�n fue exitosa, false si no se encontr� la venta o hubo error.
     */
    public boolean actualizarMonto(int idVenta, double montoNuevo) {
        // Declaraci�n de recursos JDBC
        Connection conn = null;
        PreparedStatement stmtSelect = null;
        PreparedStatement stmtUpdate = null;
        ResultSet rs = null;

        try {
            // Establecer conexi�n con la base de datos
            conn = ConexionBD.conectar();

            // Consulta para obtener el monto actual y el total de la venta
            String sqlSelect = "SELECT monto, total FROM ventas WHERE id = ?";
            stmtSelect = conn.prepareStatement(sqlSelect);
            stmtSelect.setInt(1, idVenta);
            rs = stmtSelect.executeQuery();

            // Si no se encuentra la venta, se retorna false
            if (!rs.next()) {
                return false;
            }

            // Obtener valores actuales
            double montoActual = rs.getDouble("monto");
            double total = rs.getDouble("total");

            // Calcular el nuevo monto acumulado
            double nuevoMonto = montoActual + montoNuevo;

            // Determinar el nuevo estado de la venta
            String nuevoEstado = (nuevoMonto >= total) ? "completada" : "pendiente";

            // Consulta para actualizar el monto y estado de la venta
            String sqlUpdate = "UPDATE ventas SET monto = ?, estado = ? WHERE id = ?";
            stmtUpdate = conn.prepareStatement(sqlUpdate);
            stmtUpdate.setDouble(1, nuevoMonto);
            stmtUpdate.setString(2, nuevoEstado);
            stmtUpdate.setInt(3, idVenta);

            // Ejecutar actualizaci�n y retornar resultado
            return stmtUpdate.executeUpdate() > 0;

        } catch (SQLException e) {
            // Manejo de errores
            e.printStackTrace();
            return false;
        } finally {
            // Liberar recursos en orden inverso
            try {
                if (rs != null) rs.close();
                if (stmtSelect != null) stmtSelect.close();
                if (stmtUpdate != null) stmtUpdate.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Obtiene el perfil completo de una venta, incluyendo informaci�n del cliente,
     * empleado responsable y detalles de productos/servicios vendidos.
     *
     * @param idVenta ID de la venta a consultar.
     * @return Objeto VentaPerfilDTO con toda la informaci�n asociada.
     * @throws SQLException Si ocurre un error durante la consulta.
     */
    public VentaPerfilDTO obtenerVentaPerfil(int idVenta) throws SQLException {
        VentaPerfilDTO ventaPerfil = null;

        // Consulta SQL para obtener la cabecera de la venta (cliente, empleado, totales)
        String sqlCabecera = """
            SELECT 
                c.id AS id_cliente,
                icp.nombre AS nombre_cliente,
                icp.numero_documento AS documento_cliente,
                p.id AS id_empleado,
                icp_emp.nombre AS nombre_empleado,
                v.id AS id_venta,
                v.total,
                v.fecha_creado,
                v.monto,
                v.estado
            FROM ventas v
            INNER JOIN clientes c ON v.id_cliente = c.id
            INNER JOIN informacion_clientes_personal icp ON c.id_info = icp.id
            INNER JOIN personal p ON v.id_personal = p.id
            INNER JOIN informacion_clientes_personal icp_emp ON p.id_info = icp_emp.id
            WHERE v.id = ?
        """;

        // Ejecutar consulta de cabecera
        try (PreparedStatement stmt = ConexionBD.conectar().prepareStatement(sqlCabecera)) {
            stmt.setInt(1, idVenta);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    // Crear DTO y asignar valores obtenidos
                    ventaPerfil = new VentaPerfilDTO();
                    ventaPerfil.setIdCliente(rs.getInt("id_cliente"));
                    ventaPerfil.setNombreCliente(rs.getString("nombre_cliente"));
                    ventaPerfil.setDocumentoCliente(rs.getString("documento_cliente"));
                    ventaPerfil.setIdEmpleado(rs.getInt("id_empleado"));
                    ventaPerfil.setNombreEmpleado(rs.getString("nombre_empleado"));
                    ventaPerfil.setIdVenta(rs.getInt("id_venta"));
                    ventaPerfil.setEstado(rs.getString("estado"));
                    ventaPerfil.setTotal(rs.getDouble("total"));
                    ventaPerfil.setMonto(rs.getDouble("monto"));

                    // Convertir timestamp a String legible
                    Timestamp ts = rs.getTimestamp("fecha_creado");
                    if (ts != null) {
                        ventaPerfil.setFechaCreado(ts.toLocalDateTime().toString());
                    }
                }
            }
        }

        // Si no se encontr� la venta, retornar null
        if (ventaPerfil == null) {
            return null;
        }

        // Consulta SQL para obtener los detalles de la venta (productos, servicios, medicamentos)
        // LEFT JOIN productos prod ON dv.id_producto = prod.id " = Une cada detalle con la tabla productos, si el detalle tiene un producto asociado.
        // "LEFT JOIN servicios serv ON dv.id_servicio = serv.id" = Une con la tabla servicios, si el detalle tiene un servicio.
        // "LEFT JOIN medicamentos med ON dv.id_medicamento = med.id" = Une con medicamentos, y luego con medicamentos_info para obtener el nombre del medicamento.
        // "LEFT JOIN medicamentos_info mi ON med.id_medicamento_info = mi.id"
        String sqlDetalles = """
            SELECT 
                dv.id AS id_detalle_venta,
                COALESCE(prod.nombre, serv.nombre, mi.nombre) AS producto,
                dv.precio,
                dv.cantidad,
                dv.subtotal,
                dv.valor_adicional
            FROM detalles_ventas dv
            LEFT JOIN productos prod ON dv.id_producto = prod.id 
            LEFT JOIN servicios serv ON dv.id_servicio = serv.id
            LEFT JOIN medicamentos med ON dv.id_medicamento = med.id
            LEFT JOIN medicamentos_info mi ON med.id_medicamento_info = mi.id
            WHERE dv.id_venta = ?
        """;

        // Lista para almacenar los detalles
        List<DetalleVentaDTO> listaDetalles = new ArrayList<>();

        // Ejecutar consulta de detalles
        try (PreparedStatement stmt = ConexionBD.conectar().prepareStatement(sqlDetalles)) {
            stmt.setInt(1, idVenta);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    // Crear DTO de detalle y asignar valores
                    DetalleVentaDTO detalle = new DetalleVentaDTO();
                    detalle.setIdDetalleVenta(rs.getInt("id_detalle_venta"));
                    detalle.setProducto(rs.getString("producto"));
                    detalle.setPrecio(rs.getDouble("precio"));
                    detalle.setCantidad(rs.getInt("cantidad"));
                    detalle.setSubtotal(rs.getDouble("subtotal"));
                    detalle.setValorAdicional(rs.getDouble("valor_adicional"));
                    listaDetalles.add(detalle);
                }
            }
        }

        // Asignar lista de detalles al perfil de venta
        ventaPerfil.setDetalles(listaDetalles);
        return ventaPerfil;
    }
}
