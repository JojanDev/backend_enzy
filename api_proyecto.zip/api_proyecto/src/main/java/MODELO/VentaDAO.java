package MODELO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VentaDAO {

    /**
 * Actualiza el monto pagado de una venta.
 * Si el monto pagado es igual o mayor al total, la venta pasa a estado "completada".
 *
 * @param idVenta     ID de la venta a actualizar.
 * @param montoNuevo  Nuevo monto a sumar al monto actual.
 * @return true si la actualización fue exitosa, false si no.
 */
public boolean actualizarMonto(int idVenta, double montoNuevo) {
    Connection conn = null;
    PreparedStatement stmtSelect = null;
    PreparedStatement stmtUpdate = null;
    ResultSet rs = null;

    try {
        conn = ConexionBD.conectar();

        // 1️⃣ Obtener el monto actual y el total
        String sqlSelect = "SELECT monto, total FROM ventas WHERE id = ?";
        stmtSelect = conn.prepareStatement(sqlSelect);
        stmtSelect.setInt(1, idVenta);
        rs = stmtSelect.executeQuery();

        if (!rs.next()) {
            return false; // Venta no encontrada
        }

        double montoActual = rs.getDouble("monto");
        double total = rs.getDouble("total");

        // 2️⃣ Calcular el nuevo monto
        double nuevoMonto = montoActual + montoNuevo;

        // 3️⃣ Determinar el nuevo estado
        String nuevoEstado = (nuevoMonto >= total) ? "completada" : "pendiente";

        // 4️⃣ Actualizar la venta
        String sqlUpdate = "UPDATE ventas SET monto = ?, estado = ? WHERE id = ?";
        stmtUpdate = conn.prepareStatement(sqlUpdate);
        stmtUpdate.setDouble(1, nuevoMonto);
        stmtUpdate.setString(2, nuevoEstado);
        stmtUpdate.setInt(3, idVenta);

        return stmtUpdate.executeUpdate() > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    } finally {
        try {
            if (rs != null) rs.close();
            if (stmtSelect != null) stmtSelect.close();
            if (stmtUpdate != null) stmtUpdate.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

}
