/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

import java.sql.Date;

/**
 *
 * @author Propietario
 */
public class MascotaResponseDTO {
    private int id;
    private ClienteResponseDTO cliente;
    private String nombre;
    private RazaResponseDTO raza;
    private int edad_semanas;
    private String edadFormateada;    
    private String sexo;
    private String estado_vital;        

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ClienteResponseDTO getCliente() {
        return cliente;
    }

    public void setCliente(ClienteResponseDTO cliente) {
        this.cliente = cliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public RazaResponseDTO getRaza() {
        return raza;
    }

    public void setRaza(RazaResponseDTO raza) {
        this.raza = raza;
    }

    public int getEdad_semanas() {
        return edad_semanas;
    }

    public void setEdad_semanas(int edad_semanas) {
        this.edad_semanas = edad_semanas;
    }

    public String getEdadFormateada() {
        return edadFormateada;
    }

    public void setEdadFormateada(String edadFormateada) {
        this.edadFormateada = edadFormateada;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getEstado_vital() {
        return estado_vital;
    }

    public void setEstado_vital(String estado_vital) {
        this.estado_vital = estado_vital;
    }

    
}
