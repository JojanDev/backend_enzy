/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

/**
 *
 * @author USUARIO
 */
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AntecedenteDAO {

    public static Date getUltimaFechaAntecedenteByIdMascota(int idMascota) {
        String sql = "SELECT fecha_creado FROM antecedentes WHERE id_mascota = ? ORDER BY fecha_creado DESC LIMIT 1";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idMascota);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getDate("fecha_creado");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null; // Si no hay antecedentes o hay error
    }
}
