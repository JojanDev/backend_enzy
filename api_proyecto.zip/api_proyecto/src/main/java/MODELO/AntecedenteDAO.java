/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

/**
 *
 * @author USUARIO
 */
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AntecedenteDAO {

    public static Date getUltimaFechaAntecedenteByIdMascota(int idMascota) {
        String sql = "SELECT fecha_creado FROM antecedentes WHERE id_mascota = ? ORDER BY fecha_creado DESC LIMIT 1";

        try (Connection con = ConexionBD.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idMascota);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getDate("fecha_creado");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null; // Si no hay antecedentes o hay error
    }

    /**
     * Verifica si un antecedente tiene tratamientos asociados.
     *
     * @param idAntecedente ID del antecedente a verificar.
     * @return true si tiene tratamientos, false si no.
     * @throws SQLException en caso de error con la base de datos.
     */
    public boolean tieneTratamientos(int idAntecedente) throws SQLException {
        String sql = "SELECT COUNT(*) FROM antecedentes_tratamientos WHERE id_antecedente = ? AND activo = true";

        try (Connection con = ConexionBD.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idAntecedente);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    /**
     * Realiza un SoftDelete de un antecedente, siempre que no tenga
     * tratamientos activos asociados.
     *
     * @param idAntecedente ID del antecedente a eliminar.
     * @return true si se eliminó correctamente, false si no fue posible.
     * @throws SQLException en caso de error con la base de datos.
     */
    public boolean softDeleteAntecedente(int idAntecedente) throws SQLException {
        // Primero validamos
        if (tieneTratamientos(idAntecedente)) {
            return false;
        }

        String sql = "UPDATE antecedentes SET activo = false WHERE id = ?";

        try (Connection con = ConexionBD.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idAntecedente);
            int filasAfectadas = ps.executeUpdate();

            if (filasAfectadas > 0) {
                return true;
            } else {
                return false;
            }
        }
    }
}
