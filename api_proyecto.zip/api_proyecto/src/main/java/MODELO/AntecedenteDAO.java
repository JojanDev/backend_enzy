package MODELO;

/**
 * Clase que maneja las operaciones de acceso a datos para la entidad Antecedente.
 * Proporciona m�todos para recuperar informaci�n sobre antecedentes de mascotas,
 * verificar tratamientos asociados y realizar eliminaciones suaves.
 * 
 * @author USUARIO
 */
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AntecedenteDAO {

    /**
     * Recupera la �ltima fecha de antecedente para una mascota espec�fica.
     *
     * @param idMascota ID de la mascota.
     * @return La �ltima fecha de antecedente o null si no hay antecedentes.
     */
    public static Date getUltimaFechaAntecedenteByIdMascota(int idMascota) {
        String sql = "SELECT fecha_creado FROM antecedentes WHERE id_mascota = ? ORDER BY fecha_creado DESC LIMIT 1"; // Consulta SQL

        // Usa try-with-resources para asegurar el cierre de recursos
        try (Connection con = ConexionBD.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idMascota); // Establece el ID de la mascota
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) { // Si hay resultados
                    return rs.getDate("fecha_creado"); // Retorna la fecha del antecedente
                }
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de errores
        }

        return null; // Si no hay antecedentes o hay error
    }

    /**
     * Verifica si un antecedente tiene tratamientos asociados.
     *
     * @param idAntecedente ID del antecedente a verificar.
     * @return true si tiene tratamientos, false si no.
     * @throws SQLException en caso de error con la base de datos.
     */
    public boolean tieneTratamientos(int idAntecedente) throws SQLException {
        String sql = "SELECT COUNT(*) FROM antecedentes_tratamientos WHERE id_antecedente = ? AND activo = true"; // Consulta SQL

        // Usa try-with-resources para asegurar el cierre de recursos
        try (Connection con = ConexionBD.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idAntecedente); // Establece el ID del antecedente
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) { // Si hay resultados
                    return rs.getInt(1) > 0; // Retorna true si hay tratamientos activos
                }
            }
        }
        return false; // Retorna false si no hay tratamientos
    }

    /**
     * Realiza un SoftDelete de un antecedente, siempre que no tenga
     * tratamientos activos asociados.
     *
     * @param idAntecedente ID del antecedente a eliminar.
     * @return true si se elimin� correctamente, false si no fue posible.
     * @throws SQLException en caso de error con la base de datos.
     */
    public boolean softDeleteAntecedente(int idAntecedente) throws SQLException {
        // Primero validamos si tiene tratamientos asociados
        if (tieneTratamientos(idAntecedente)) {
            return false; // No se puede eliminar si tiene tratamientos activos
        }

        String sql = "UPDATE antecedentes SET activo = false WHERE id = ?"; // Consulta SQL para realizar el SoftDelete

        // Usa try-with-resources para asegurar el cierre de recursos
        try (Connection con = ConexionBD.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idAntecedente); // Establece el ID del antecedente
            int filasAfectadas = ps.executeUpdate(); // Ejecuta la actualizaci�n

            return filasAfectadas > 0; // Retorna true si se afectaron filas, false si no
        }
    }
}
