/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

/**
 *
 * @author USUARIO
 */
public class MascotaSinDuenoGetResponseDTO {
    private int id;
    private String nombre;
    private RazaGetResponseDTO raza;
    private int edadSemanas;
    private String edadFormateada;
    private String sexo;
    private String estado_vital;

    public String getEdadFormateada() {
        return edadFormateada;
    }

    public void setEdadFormateada(String edadFormateada) {
        this.edadFormateada = edadFormateada;
    }

    // Getters y setters (igual que antes, pero sin el campo 'dueno')

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public RazaGetResponseDTO getRaza() {
        return raza;
    }

    public void setRaza(RazaGetResponseDTO raza) {
        this.raza = raza;
    }

    public int getEdadSemanas() {
        return edadSemanas;
    }

    public void setEdadSemanas(int edadSemanas) {
        this.edadSemanas = edadSemanas;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getEstado_vital() {
        return estado_vital;
    }

    public void setEstado_vital(String estado_vital) {
        this.estado_vital = estado_vital;
    }
}

