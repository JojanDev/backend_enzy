/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

/**
 *
 * @author USUARIO
 */
public class Cliente {
    private int id;           // ID del cliente (clave primaria)
    private int id_info;      // Clave foránea que apunta a la tabla informacion_clientes_personal

    // Constructor vacío (requerido para reflexión o frameworks)
    public Cliente() {}

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_info() {
        return id_info;
    }

    public void setId_info(int id_info) {
        this.id_info = id_info;
    }
}
