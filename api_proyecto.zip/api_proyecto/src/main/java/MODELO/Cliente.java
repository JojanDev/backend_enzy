package MODELO;

/**
 * Representa un cliente dentro del sistema de la veterinaria.
 * <p>
 * Cada objeto de esta clase contiene información básica de identificación del cliente,
 * asociándose a información detallada en otra tabla mediante la clave foránea {@code id_info}.
 * </p>
 * <p>
 * Esta clase es utilizada principalmente en operaciones CRUD y requiere un constructor vacío
 * para soporte de reflexión y frameworks.
 * </p>
 * 
 * @author USUARIO
 */
public class Cliente {

    /** Identificador único del cliente (clave primaria). */
    private int id;

    /** Clave foránea que apunta a la tabla {@code informacion_clientes_personal} donde se almacena información detallada del cliente. */
    private int id_info;

    /**
     * Constructor vacío requerido para reflexión o frameworks.
     */
    public Cliente() {}

    /**
     * Obtiene el ID del cliente.
     * 
     * @return identificador único del cliente
     */
    public int getId() {
        return id;
    }

    /**
     * Establece el ID del cliente.
     * 
     * @param id identificador único a asignar
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene la clave foránea que apunta a la información detallada del cliente.
     * 
     * @return ID de la información asociada
     */
    public int getId_info() {
        return id_info;
    }

    /**
     * Establece la clave foránea que apunta a la información detallada del cliente.
     * 
     * @param id_info ID de la información asociada a asignar
     */
    public void setId_info(int id_info) {
        this.id_info = id_info;
    }
}
    