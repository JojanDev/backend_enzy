package MODELO;

/**
 * Representa un cliente dentro del sistema de la veterinaria.
 *
 * Campos:
 *   id: identificador unico del cliente (clave primaria)
 *   id_info: clave foranea que apunta a la tabla informacion_clientes_personal
 *
 * Esta clase es utilizada principalmente en operaciones CRUD y requiere constructor
 * vacio para soporte de reflexion y frameworks.
 */
public class Cliente {

    /** identificador unico del cliente (clave primaria) */
    private int id;

    /** clave foranea que apunta a la tabla informacion_clientes_personal */
    private int id_info;

    /**
     * Constructor vacio requerido para reflexion o frameworks.
     */
    public Cliente() {
        // constructor por defecto
    }

    /**
     * Obtiene el identificador unico del cliente.
     *
     * @return identificador unico del cliente
     */
    public int getId() {
        // devuelve el valor del campo 'id'
        return id;
    }

    /**
     * Establece el identificador unico del cliente.
     *
     * @param id identificador unico a asignar
     */
    public void setId(int id) {
        // asigna el valor recibido al campo 'id'
        this.id = id;
    }

    /**
     * Obtiene la clave foranea que apunta a la informacion detallada del cliente.
     *
     * @return clave foranea de la informacion asociada
     */
    public int getId_info() {
        // devuelve el valor del campo 'id_info'
        return id_info;
    }

    /**
     * Establece la clave foranea que apunta a la informacion detallada del cliente.
     *
     * @param id_info clave foranea a asignar
     */
    public void setId_info(int id_info) {
        // asigna el valor recibido al campo 'id_info'
        this.id_info = id_info;
    }
}

    