/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

import java.math.BigDecimal;

/**
 *
 * @author USUARIO
 */
public class MedicamentoResponseDTO {
    private int id;
    private MedicamentoInfo info;
    private BigDecimal precio;
    private int stock;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public MedicamentoInfo getInfo() {
        return info;
    }

    public void setInfo(MedicamentoInfo info) {
        this.info = info;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
    
    
}
