package MODELO;

public class ClienteResponseDTO {
    private int id;
    private IcpResponseDTO info;

    // Constructor con todos los campos
    public ClienteResponseDTO(int id, IcpResponseDTO info) {
        this.id = id;
        this.info = info;
    }

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public IcpResponseDTO getInfo() {
        return info;
    }

    public void setInfo(IcpResponseDTO info) {
        this.info = info;
    }
}
