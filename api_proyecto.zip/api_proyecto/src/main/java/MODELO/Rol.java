package MODELO;

/**
 * Modelo que representa un rol dentro del sistema.
 *
 * Campos:
 * - id: identificador unico del rol
 * - nombre: nombre descriptivo del rol (ej. administrador, usuario)
 */
public class Rol {

    /**
     * identificador unico del rol
     */
    private int id;

    /**
     * nombre descriptivo del rol
     */
    private String nombre;

    /**
     * Obtiene el identificador unico del rol.
     *
     * @return id del rol
     */
    public int getId() {
        return id;
    }

    /**
     * Asigna el identificador unico del rol.
     *
     * @param id nuevo valor de id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene el nombre descriptivo del rol.
     *
     * @return nombre del rol
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Asigna el nombre descriptivo del rol.
     *
     * @param nombre nuevo nombre a asignar al rol
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}

