/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

/**
 *
 * @author USUARIO
 */
public class MascotaUtils {
    public static String formatearEdad(int semanas) {
        int años = semanas / 52;
        int semanasRestantes = semanas % 52;
        int meses = semanasRestantes / 4;
        int semanasFinales = semanasRestantes % 4;

        StringBuilder edadFormateada = new StringBuilder();

        if (años > 0) {
            edadFormateada.append(años).append(" ").append(años == 1 ? "año" : "años");
        }

        if (meses > 0) {
            if (edadFormateada.length() > 0) edadFormateada.append(" y ");
            edadFormateada.append(meses).append(" ").append("mes");
        }

        if (semanasFinales > 0 || (años == 0 && meses == 0)) {
            if (edadFormateada.length() > 0) edadFormateada.append(" y ");
            edadFormateada.append((semanasFinales < 1) ? "1" : semanasFinales).append(" ").append("sem");
        }

        return edadFormateada.toString();
    }
}
