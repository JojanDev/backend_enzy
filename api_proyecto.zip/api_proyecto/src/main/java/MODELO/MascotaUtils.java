package MODELO;

/**
 * Clase utilitaria para operaciones relacionadas con mascotas.
 *
 * Proporciona métodos estáticos para formatear datos de mascotas,
 * como convertir edad en semanas a una cadena legible en anios, meses y semanas.
 *
 * Métodos:
 *   formatearEdad(int semanas): convierte semanas a una representacion de tiempo.
 */
public class MascotaUtils {

    /**
     * Formatea la edad dada en semanas a una representacion de anios, meses y semanas.
     *
     * @param semanas edad en semanas a formatear
     * @return cadena que describe la edad en anios, meses y semanas
     */
    public static String formatearEdad(int semanas) {
        // calcula la cantidad de anios completos en base a 52 semanas por anio
        int anios = semanas / 52;
        // obtiene las semanas restantes despues de extraer los anios
        int semanasRestantes = semanas % 52;
        // calcula los meses completos a partir de las semanas restantes (4 semanas por mes)
        int meses = semanasRestantes / 4;
        // determina las semanas que sobran despues de extraer meses
        int semanasFinales = semanasRestantes % 4;

        // construye paso a paso la representacion de la edad
        StringBuilder edadFormateada = new StringBuilder();

        // agrega la parte de anios si corresponde
        if (anios > 0) {
            edadFormateada
                .append(anios)
                .append(" ")
                .append(anios == 1 ? "anio" : "anios");
        }

        // agrega la parte de meses si corresponde, separada por " y " si ya hay anios
        if (meses > 0) {
            if (edadFormateada.length() > 0) {
                edadFormateada.append(" y ");
            }
            edadFormateada
                .append(meses)
                .append(" ")
                .append(meses == 1 ? "mes" : "meses");
        }

        // agrega la parte de semanas finales; siempre muestra al menos 1 semana
        if (semanasFinales > 0 || (anios == 0 && meses == 0)) {
            if (edadFormateada.length() > 0) {
                edadFormateada.append(" y ");
            }
            // si semanasFinales es 0 pero no hay anios ni meses, mostramos "1 sem"
            int semDisplay = semanasFinales < 1 ? 1 : semanasFinales;
            edadFormateada
                .append(semDisplay)
                .append(" sem");
        }

        // devuelve la cadena completa con la edad formateada
        return edadFormateada.toString();
    }
}
