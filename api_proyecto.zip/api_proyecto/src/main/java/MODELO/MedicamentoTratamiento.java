/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

/**
 *
 * @author USUARIO
 */
public class MedicamentoTratamiento {
    private int id;
    private int id_tratamiento;
    private int id_medicamento_info;    
    private String dosis;
    private String frecuencia_aplicacion;
    private int duracion;
    private boolean activo;

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
        

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_tratamiento() {
        return id_tratamiento;
    }

    public void setId_tratamiento(int id_tratamiento) {
        this.id_tratamiento = id_tratamiento;
    }

    public int getId_medicamento_info() {
        return id_medicamento_info;
    }

    public void setId_medicamento_info(int id_medicamento_info) {
        this.id_medicamento_info = id_medicamento_info;
    }

    public String getDosis() {
        return dosis;
    }

    public void setDosis(String dosis) {
        this.dosis = dosis;
    }

    public String getFrecuencia_aplicacion() {
        return frecuencia_aplicacion;
    }

    public void setFrecuencia_aplicacion(String frecuencia_aplicacion) {
        this.frecuencia_aplicacion = frecuencia_aplicacion;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }
    
   
}
