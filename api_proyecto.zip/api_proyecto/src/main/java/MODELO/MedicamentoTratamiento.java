package MODELO;

/**
 * Representa la asociacion entre un tratamiento y un medicamento.
 *
 * Campos:
 *   id                    : identificador unico de la relacion
 *   id_tratamiento        : identificador del tratamiento asociado
 *   id_medicamento_info   : identificador de la informacion del medicamento
 *   dosis                 : dosis a administrar (cantidad y unidad)
 *   frecuencia_aplicacion : frecuencia con que se aplica la dosis
 *   duracion              : duracion del tratamiento en dias
 *   activo                : indica si la asociacion esta activa o inactiva
 */
public class MedicamentoTratamiento {

    private int id;
    private int id_tratamiento;
    private int id_medicamento_info;    
    private String dosis;
    private String frecuencia_aplicacion;
    private int duracion;
    private boolean activo;

    /**
     * Devuelve si la relacion medicamento-tratamiento esta activa.
     *
     * @return true si la relacion esta activa, false en caso contrario
     */
    public boolean isActivo() {
        // devuelve el valor almacenado en 'activo'
        return activo;
    }

    /**
     * Define si la relacion medicamento-tratamiento esta activa.
     *
     * @param activo true para activar la relacion, false para inactivarla
     */
    public void setActivo(boolean activo) {
        // asigna el estado de actividad al campo 'activo'
        this.activo = activo;
    }
        
    /**
     * Obtiene el identificador unico de la relacion.
     *
     * @return id de la relacion
     */
    public int getId() {
        // devuelve el valor almacenado en 'id'
        return id;
    }

    /**
     * Establece el identificador unico de la relacion.
     *
     * @param id identificador unico a asignar
     */
    public void setId(int id) {
        // asigna el valor recibido al campo 'id'
        this.id = id;
    }

    /**
     * Obtiene el identificador del tratamiento asociado.
     *
     * @return id del tratamiento
     */
    public int getId_tratamiento() {
        // devuelve el valor almacenado en 'id_tratamiento'
        return id_tratamiento;
    }

    /**
     * Establece el identificador del tratamiento asociado.
     *
     * @param id_tratamiento id del tratamiento a asignar
     */
    public void setId_tratamiento(int id_tratamiento) {
        // asigna el valor recibido al campo 'id_tratamiento'
        this.id_tratamiento = id_tratamiento;
    }

    /**
     * Obtiene el identificador de la informacion del medicamento.
     *
     * @return id de la informacion del medicamento
     */
    public int getId_medicamento_info() {
        // devuelve el valor almacenado en 'id_medicamento_info'
        return id_medicamento_info;
    }

    /**
     * Establece el identificador de la informacion del medicamento.
     *
     * @param id_medicamento_info id a asignar
     */
    public void setId_medicamento_info(int id_medicamento_info) {
        // asigna el valor recibido al campo 'id_medicamento_info'
        this.id_medicamento_info = id_medicamento_info;
    }

    /**
     * Obtiene la dosis a administrar.
     *
     * @return cadena con la dosis (cantidad y unidad)
     */
    public String getDosis() {
        // devuelve el valor almacenado en 'dosis'
        return dosis;
    }

    /**
     * Define la dosis a administrar.
     *
     * @param dosis cadena con la dosis (cantidad y unidad)
     */
    public void setDosis(String dosis) {
        // asigna el valor recibido al campo 'dosis'
        this.dosis = dosis;
    }

    /**
     * Obtiene la frecuencia de aplicacion de la dosis.
     *
     * @return cadena con la frecuencia de aplicacion
     */
    public String getFrecuencia_aplicacion() {
        // devuelve el valor almacenado en 'frecuencia_aplicacion'
        return frecuencia_aplicacion;
    }

    /**
     * Define la frecuencia de aplicacion de la dosis.
     *
     * @param frecuencia_aplicacion frecuencia a asignar
     */
    public void setFrecuencia_aplicacion(String frecuencia_aplicacion) {
        // asigna el valor recibido al campo 'frecuencia_aplicacion'
        this.frecuencia_aplicacion = frecuencia_aplicacion;
    }

    /**
     * Obtiene la duracion del tratamiento en dias.
     *
     * @return numero de dias de duracion
     */
    public int getDuracion() {
        // devuelve el valor almacenado en 'duracion'
        return duracion;
    }

    /**
     * Establece la duracion del tratamiento en dias.
     *
     * @param duracion numero de dias a asignar
     */
    public void setDuracion(int duracion) {
        // asigna el valor recibido al campo 'duracion'
        this.duracion = duracion;
    }
}
