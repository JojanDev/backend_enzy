package MODELO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MedicamentoDAO {

    /**
     * Resta una cantidad espec�fica al stock del medicamento.
     *
     * @param idMedicamento ID del medicamento.
     * @param cantidadRestar Cantidad a descontar.
     * @return true si la operaci�n fue exitosa.
     */
    public boolean restarCantidad(int idMedicamento, int cantidadRestar) {
        String sql = "UPDATE medicamentos SET cantidad = cantidad - ? WHERE id = ?"; // Consulta SQL para restar cantidad

        // Usa try-with-resources para asegurar el cierre de recursos
        try (Connection con = ConexionBD.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, cantidadRestar); // Establece la cantidad a restar
            ps.setInt(2, idMedicamento); // Establece el ID del medicamento

            int filasAfectadas = ps.executeUpdate(); // Ejecuta la actualizaci�n y obtiene el n�mero de filas afectadas
            return filasAfectadas > 0; // Retorna true si se afectaron filas, false si no

        } catch (SQLException e) {
            System.err.println("Error al restar cantidad de medicamento: " + e.getMessage()); // Manejo de errores
            return false; // Retorna false en caso de error
        }
    }

    /**
     * Verifica si existe un lote espec�fico de un medicamento.
     *
     * @param idMedicamento ID del medicamento.
     * @param lote N�mero de lote a verificar.
     * @return true si el lote existe, false si no.
     */
    public boolean existeLoteDeMedicamento(int idMedicamento, String lote) {
        String sql = "SELECT COUNT(*) FROM medicamentos WHERE id_medicamento_info = ? AND numero_lote = ?"; // Consulta SQL

        // Usa try-with-resources para asegurar el cierre de recursos
        try (Connection conn = ConexionBD.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idMedicamento); // Establece el ID del medicamento
            stmt.setString(2, lote); // Establece el n�mero de lote

            // Ejecuta la consulta y obtiene el resultado
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) { // Si hay resultados
                    int count = rs.getInt(1); // Obtiene el conteo
                    return count > 0; // Retorna true si ya existe, false si no
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de errores
        }

        return false; // Por defecto, si algo falla, asumimos que no existe
    }
}