package MODELO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MedicamentoDAO {

    /**
     * Resta una cantidad específica al stock del medicamento.
     *
     * @param idMedicamento ID del medicamento.
     * @param cantidadRestar Cantidad a descontar.
     * @return true si la operación fue exitosa.
     */
    public boolean restarCantidad(int idMedicamento, int cantidadRestar) {
        String sql = "UPDATE medicamentos SET cantidad = cantidad - ? WHERE id = ?";

        try (Connection con = ConexionBD.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, cantidadRestar);
            ps.setInt(2, idMedicamento);

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al restar cantidad de medicamento: " + e.getMessage());
            return false;
        }
    }

    public boolean existeLoteDeMedicamento(int idMedicamento, String lote) {
        String sql = "SELECT COUNT(*) FROM medicamentos WHERE id_medicamento_info = ? AND numero_lote = ?";

        try (Connection conn = ConexionBD.conectar(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idMedicamento);
            stmt.setString(2, lote);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count > 0; // true si ya existe, false si no
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false; // Por defecto, si algo falla, asumimos que no existe
    }

}
