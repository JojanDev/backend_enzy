package MODELO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MedicamentoDAO {

    /**
     * Resta una cantidad específica al stock del medicamento.
     * @param idMedicamento ID del medicamento.
     * @param cantidadRestar Cantidad a descontar.
     * @return true si la operación fue exitosa.
     */
    public boolean restarCantidad(int idMedicamento, int cantidadRestar) {
        String sql = "UPDATE medicamentos SET cantidad = cantidad - ? WHERE id = ?";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, cantidadRestar);
            ps.setInt(2, idMedicamento);

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al restar cantidad de medicamento: " + e.getMessage());
            return false;
        }
    }
}
