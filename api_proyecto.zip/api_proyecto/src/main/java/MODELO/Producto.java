package MODELO;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Modelo que representa un producto disponible en inventario.
 *
 * Campos:
 * - id: identificador unico del producto
 * - nombre: nombre comercial del producto
 * - precio: costo unitario por unidad
 * - descripcion: detalles o caracteristicas del producto
 * - fecha_caducidad: fecha limite de consumo o venta
 * - id_tipo: clave foranea que referencia al tipo de producto
 * - stock: unidades disponibles en inventario
 */
public class Producto {

    /**
     * identificador unico del producto
     */
    private int id;

    /**
     * nombre comercial del producto
     */
    private String nombre;

    /**
     * costo unitario por unidad
     */
    private BigDecimal precio;

    /**
     * detalles o caracteristicas del producto
     */
    private String descripcion;

    /**
     * fecha limite de consumo o venta
     */
    private LocalDate fecha_caducidad;

    /**
     * clave foranea que referencia al tipo de producto
     */
    private int id_tipo;

    /**
     * unidades disponibles en inventario
     */
    private int stock;

    /**
     * Obtiene el identificador unico del producto.
     *
     * @return id del producto
     */
    public int getId() {
        return id;
    }

    /**
     * Asigna el identificador unico del producto.
     *
     * @param id nuevo identificador del producto
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene el nombre comercial del producto.
     *
     * @return nombre del producto
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Asigna el nombre comercial del producto.
     *
     * @param nombre nuevo nombre del producto
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el costo unitario por unidad.
     *
     * @return precio del producto
     */
    public BigDecimal getPrecio() {
        return precio;
    }

    /**
     * Asigna el costo unitario por unidad.
     *
     * @param precio nuevo precio del producto
     */
    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    /**
     * Obtiene los detalles o caracteristicas del producto.
     *
     * @return descripcion del producto
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Asigna los detalles o caracteristicas del producto.
     *
     * @param descripcion nueva descripcion del producto
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Obtiene la fecha limite de consumo o venta.
     *
     * @return fecha de caducidad
     */
    public LocalDate getFecha_caducidad() {
        return fecha_caducidad;
    }

    /**
     * Asigna la fecha limite de consumo o venta.
     *
     * @param fecha_caducidad nueva fecha de caducidad
     */
    public void setFecha_caducidad(LocalDate fecha_caducidad) {
        this.fecha_caducidad = fecha_caducidad;
    }

    /**
     * Obtiene la clave foranea que referencia al tipo de producto.
     *
     * @return id_tipo del producto
     */
    public int getId_tipo() {
        return id_tipo;
    }

    /**
     * Asigna la clave foranea que referencia al tipo de producto.
     *
     * @param id_tipo nueva clave foranea al tipo de producto
     */
    public void setId_tipo(int id_tipo) {
        this.id_tipo = id_tipo;
    }

    /**
     * Obtiene las unidades disponibles en inventario.
     *
     * @return stock disponible
     */
    public int getStock() {
        return stock;
    }

    /**
     * Asigna las unidades disponibles en inventario.
     *
     * @param stock nuevo valor de stock
     */
    public void setStock(int stock) {
        this.stock = stock;
    }
}
