package MODELO.DAO;

import MODELO.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Clase DAO para la entidad Medicamento.
 * Proporciona metodos para:
 * - restar cantidad del stock
 * - verificar existencia de lote de medicamento
 */
public class MedicamentoDAO {

    /**
     * Descuenta una cantidad especifica del stock del medicamento.
     *
     * @param idMedicamento  identificador del medicamento
     * @param cantidadRestar cantidad a restar del stock
     * @return true si la operacion fue exitosa; false en caso contrario
     */
    public boolean restarCantidad(int idMedicamento, int cantidadRestar) {
        // SQL para decrementar el campo 'cantidad' segun el id
        String sql = "UPDATE medicamentos SET cantidad = cantidad - ? WHERE id = ?";

        // Usa try-with-resources para cerrar conexion y statement automaticamente
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            // Asigna la cantidad a restar al primer parametro
            ps.setInt(1, cantidadRestar);
            // Asigna el id del medicamento al segundo parametro
            ps.setInt(2, idMedicamento);

            // Ejecuta la actualizacion y devuelve el numero de filas afectadas
            int filasAfectadas = ps.executeUpdate();
            // Retorna true si al menos un registro fue modificado
            return filasAfectadas > 0;

        } catch (SQLException e) {
            // Muestra error en consola si ocurre excepcion SQL
            System.err.println("Error al descontar cantidad de medicamento: " + e.getMessage());
            return false;
        }
    }

    /**
     * Verifica si existe un lote especifico de un medicamento.
     *
     * @param idMedicamento  identificador del medicamento
     * @param lote           numero de lote a verificar
     * @return true si el lote existe; false si no existe o hay error
     */
    public boolean existeLoteDeMedicamento(int idMedicamento, String lote) {
        // SQL para contar registros con el lote especificado
        String sql = "SELECT COUNT(*) FROM medicamentos "
                   + "WHERE id_medicamento_info = ? AND numero_lote = ?";

        // Abre conexion y prepara la sentencia
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            // Asigna idMedicamento al primer placeholder
            ps.setInt(1, idMedicamento);
            // Asigna lote al segundo placeholder
            ps.setString(2, lote);

            // Ejecuta la consulta y procesa el resultado
            try (ResultSet rs = ps.executeQuery()) {
                // Retorna true si el conteo es mayor que cero
                return rs.next() && rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            // Muestra error en consola si ocurre excepcion SQL
            System.err.println("Error al verificar lote de medicamento: " + e.getMessage());
            return false;
        }
    }
}
