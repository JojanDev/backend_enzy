package MODELO.DAO;

import MODELO.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Clase que maneja las operaciones de acceso a datos para la entidad Medicamento.
 * Proporciona metodos para gestionar el stock y verificar lotes de medicamentos.
 */
public class MedicamentoDAO {

    /**
     * Descuenta una cantidad especifica del stock del medicamento.
     *
     * @param idMedicamento Identificador del medicamento.
     * @param cantidadRestar Cantidad que se desea descontar del stock.
     * @return true si la operacion fue exitosa, false en caso contrario.
     */
    public boolean restarCantidad(int idMedicamento, int cantidadRestar) {
        // Consulta SQL para actualizar el campo 'cantidad'
        String sql = "UPDATE medicamentos SET cantidad = cantidad - ? WHERE id = ?";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, cantidadRestar); // Parametro: cantidad a restar
            ps.setInt(2, idMedicamento);  // Parametro: ID del medicamento

            int filasAfectadas = ps.executeUpdate(); // Ejecuta la actualizacion
            return filasAfectadas > 0; // Retorna true si se modifico al menos una fila

        } catch (SQLException e) {
            System.err.println("Error al descontar cantidad de medicamento: " + e.getMessage());
            return false;
        }
    }

    /**
     * Verifica si existe un lote especifico de un medicamento.
     *
     * @param idMedicamento Identificador del medicamento.
     * @param lote Numero de lote a verificar.
     * @return true si el lote existe, false si no.
     */
    public boolean existeLoteDeMedicamento(int idMedicamento, String lote) {
        // Consulta SQL para verificar existencia del lote
        String sql = "SELECT COUNT(*) FROM medicamentos WHERE id_medicamento_info = ? AND numero_lote = ?";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idMedicamento); // Parametro: ID del medicamento
            stmt.setString(2, lote);       // Parametro: numero de lote

            try (ResultSet rs = stmt.executeQuery()) {
                // Si hay al menos un resultado, el lote existe
                return rs.next() && rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            System.err.println("Error al verificar lote de medicamento: " + e.getMessage());
            return false;
        }
    }
}
