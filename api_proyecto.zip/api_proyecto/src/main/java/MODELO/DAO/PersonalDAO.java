package MODELO.DAO;

import MODELO.ConexionBD;
import MODELO.InformacionClientesPersonal;
import MODELO.Personal;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

/**
 * Clase DAO para la entidad Personal.
 * Proporciona metodos para:
 * - obtener un usuario por nombre de usuario
 * - listar empleados sin cliente asociado
 * - listar veterinarios activos
 */
public class PersonalDAO {

    /**
     * Recupera un objeto Personal usando el nombre de usuario.
     *
     * @param username nombre de usuario a buscar
     * @return instancia de Personal si existe; null si no
     */
    public Personal getByUsername(String username) {
        // SQL para seleccionar todos los campos del usuario indicado
        String sql = "SELECT * FROM personal WHERE usuario = ?";

        // Abre conexion y prepara la consulta
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            // Asigna el valor de username al primer parametro
            ps.setString(1, username);

            // Ejecuta la consulta y obtiene el resultado
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // Mapea columnas del ResultSet a un objeto Personal
                    Personal p = new Personal();
                    p.setId(rs.getInt("id"));
                    p.setId_info(rs.getInt("id_info"));
                    p.setId_rol(rs.getInt("id_rol"));
                    p.setContrasena(rs.getString("contrasena"));
                    p.setUsuario(rs.getString("usuario"));
                    p.setActivo(rs.getBoolean("activo"));
                    return p; 
                }
            }

        } catch (SQLException e) {
            // Muestra mensaje de error si falla la consulta
            System.err.println("Error al obtener usuario: " + e.getMessage());
        }

        // Retorna null si no se encontro usuario o hubo un error
        return null;
    }

    /**
     * Obtiene una lista de empleados que no estan ligados a ningun cliente.
     *
     * @return lista de InformacionClientesPersonal con empleados sin cliente
     */
    public List<InformacionClientesPersonal> getEmpleadosSinCliente() {
        // Prepara lista para guardar los resultados
        List<InformacionClientesPersonal> lista = new ArrayList<>();

        // SQL para seleccionar empleados cuyo id_info no aparece en clientes
        String sql =
            "SELECT i.id, i.id_tipo_documento, i.numero_documento, "
          + "i.nombre, i.telefono, i.correo, i.direccion "
          + "FROM informacion_clientes_personal i "
          + "JOIN personal p ON p.id_info = i.id "
          + "LEFT JOIN clientes c ON c.id_info = i.id "
          + "WHERE c.id IS NULL";

        // Abre conexion, ejecuta la consulta y recorre el conjunto de resultados
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                // Crea DTO y asigna valores leidos de cada columna
                InformacionClientesPersonal info = new InformacionClientesPersonal();
                info.setId(rs.getInt("id"));
                info.setId_tipo_documento(rs.getInt("id_tipo_documento"));
                info.setNumero_documento(rs.getString("numero_documento"));
                info.setNombre(rs.getString("nombre"));
                info.setTelefono(rs.getString("telefono"));
                info.setCorreo(rs.getString("correo"));
                info.setDireccion(rs.getString("direccion"));

                // Agrega el DTO a la lista
                lista.add(info);
            }

        } catch (SQLException e) {
            // Muestra mensaje de error si falla la consulta
            System.err.println("Error al obtener empleados sin cliente: " + e.getMessage());
        }

        // Devuelve la lista, vacia si no hay resultados o hubo un error
        return lista;
    }

    /**
     * Recupera la lista de veterinarios activos (rol = 3).
     *
     * @return lista de objetos Personal con rol veterinario y estado activo
     * @throws SQLException si falla la consulta en la base de datos
     */
    public List<Personal> obtenerVeterinariosActivos() throws SQLException {
        // Lista para almacenar veterinarios encontrados
        List<Personal> lista = new ArrayList<>();

        // SQL para seleccionar personal con rol veterinario y activo = true
        String sql =
            "SELECT p.id, p.id_info, p.contrasena, p.usuario, p.id_rol, p.activo "
          + "FROM personal p "
          + "JOIN informacion_clientes_personal i ON p.id_info = i.id "
          + "WHERE p.id_rol = ? AND p.activo = ?";

        // Abre conexion y prepara la instruccion
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            // Asigna parametros: rol veterinario (3) y solo activos
            ps.setInt(1, 3);
            ps.setBoolean(2, true);

            // Ejecuta la consulta y procesa cada fila del resultado
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    // Crea y puebla un objeto Personal con datos de la fila
                    Personal p = new Personal();
                    p.setId(rs.getInt("id"));
                    p.setId_info(rs.getInt("id_info"));
                    p.setContrasena(rs.getString("contrasena"));
                    p.setUsuario(rs.getString("usuario"));
                    p.setId_rol(rs.getInt("id_rol"));
                    p.setActivo(rs.getBoolean("activo"));

                    // Agrega el objeto a la lista
                    lista.add(p);
                }
            }
        }

        // Retorna la lista de veterinarios activos
        return lista;
    }
}
