package MODELO.DAO;

import MODELO.ConexionBD;
import MODELO.InformacionClientesPersonal;
import MODELO.Personal;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

/**
 * Clase que maneja las operaciones de acceso a datos para la entidad Personal.
 * Proporciona metodos para recuperar informacion sobre empleados y veterinarios.
 */
public class PersonalDAO {

    /**
     * Recupera un objeto Personal basado en el nombre de usuario.
     *
     * @param username Nombre de usuario del empleado.
     * @return Un objeto Personal si se encuentra, null si no.
     */
    public Personal getByUsername(String username) {
        String sql = "SELECT * FROM personal WHERE usuario = ?";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Personal p = new Personal();
                    p.setId(rs.getInt("id"));
                    p.setId_info(rs.getInt("id_info"));
                    p.setId_rol(rs.getInt("id_rol"));
                    p.setContrasena(rs.getString("contrasena"));
                    p.setUsuario(rs.getString("usuario"));
                    p.setActivo(rs.getBoolean("activo"));
                    return p;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener usuario: " + e.getMessage());
        }

        return null;
    }

    /**
     * Recupera una lista de empleados que no estan asociados a ningun cliente.
     *
     * @return Lista de objetos InformacionClientesPersonal que representan a los empleados sin cliente.
     */
    public List<InformacionClientesPersonal> getEmpleadosSinCliente() {
        List<InformacionClientesPersonal> lista = new ArrayList<>();

        String sql = """
            SELECT i.id, i.id_tipo_documento, i.numero_documento, 
                   i.nombre, i.telefono, i.correo, i.direccion
            FROM informacion_clientes_personal i
            JOIN personal p ON p.id_info = i.id
            LEFT JOIN clientes c ON c.id_info = i.id
            WHERE c.id IS NULL
        """;

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                InformacionClientesPersonal info = new InformacionClientesPersonal();
                info.setId(rs.getInt("id"));
                info.setId_tipo_documento(rs.getInt("id_tipo_documento"));
                info.setNumero_documento(rs.getString("numero_documento"));
                info.setNombre(rs.getString("nombre"));
                info.setTelefono(rs.getString("telefono"));
                info.setCorreo(rs.getString("correo"));
                info.setDireccion(rs.getString("direccion"));
                lista.add(info);
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener empleados sin cliente: " + e.getMessage());
        }

        return lista;
    }

    /**
     * Recupera una lista de veterinarios activos.
     *
     * @return Lista de objetos Personal que representan a los veterinarios activos.
     * @throws SQLException Si ocurre un error al acceder a la base de datos.
     */
    public List<Personal> obtenerVeterinariosActivos() throws SQLException {
        List<Personal> lista = new ArrayList<>();

        String sql = """
            SELECT p.id, p.id_info, p.contrasena, p.usuario, p.id_rol, p.activo
            FROM personal p
            JOIN informacion_clientes_personal i ON p.id_info = i.id
            WHERE p.id_rol = ? AND p.activo = ?
        """;

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, 3); // ID del rol veterinario
            ps.setBoolean(2, true); // Solo activos

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Personal p = new Personal();
                    p.setId(rs.getInt("id"));
                    p.setId_info(rs.getInt("id_info"));
                    p.setContrasena(rs.getString("contrasena"));
                    p.setUsuario(rs.getString("usuario"));
                    p.setId_rol(rs.getInt("id_rol"));
                    p.setActivo(rs.getBoolean("activo"));
                    lista.add(p);
                }
            }
        }

        return lista;
    }
}
