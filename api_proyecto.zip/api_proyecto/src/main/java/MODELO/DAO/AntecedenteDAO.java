package MODELO.DAO;

import MODELO.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

/**
 * Clase que maneja las operaciones de acceso a datos para la entidad
 * Antecedente. Proporciona métodos para consultar, verificar y desactivar
 * antecedentes de mascotas.
 */
public class AntecedenteDAO {

    /**
     * Recupera la última fecha de antecedente registrada para una mascota
     * específica.
     *
     * @param idMascota ID de la mascota.
     * @return La fecha más reciente de antecedente o null si no hay registros.
     */
    public static LocalDate getUltimaFechaAntecedenteByIdMascota(int idMascota) {
        String sql = "SELECT fecha_creado FROM antecedentes WHERE id_mascota = ? ORDER BY fecha_creado DESC LIMIT 1";

        // Se utiliza try-with-resources para asegurar el cierre automático de la conexión y recursos
        try (Connection con = ConexionBD.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idMascota); // Asigna el ID de la mascota al parámetro de la consulta

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // Convierte la fecha SQL a LocalDate y la retorna
                    return rs.getDate("fecha_creado").toLocalDate();
                }
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Imprime el error en consola si ocurre una excepción
        }

        return null; // Retorna null si no hay resultados o ocurre un error
    }

    /**
     * Verifica si un antecedente tiene tratamientos activos asociados.
     *
     * @param idAntecedente ID del antecedente a verificar.
     * @return true si tiene tratamientos activos, false si no.
     * @throws SQLException en caso de error con la base de datos.
     */
    public boolean tieneTratamientos(int idAntecedente) throws SQLException {
        String sql = "SELECT COUNT(*) FROM antecedentes_tratamientos WHERE id_antecedente = ? AND activo = true";

        try (Connection con = ConexionBD.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idAntecedente); // Asigna el ID del antecedente

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // Retorna true si el conteo es mayor a cero
                    return rs.getInt(1) > 0;
                }
            }
        }

        return false; // Retorna false si no hay tratamientos o ocurre un error
    }

    /**
     * Realiza una eliminación lógica (SoftDelete) de un antecedente, siempre
     * que no tenga tratamientos activos asociados.
     *
     * @param idAntecedente ID del antecedente a desactivar.
     * @return true si se desactivó correctamente, false si no fue posible.
     * @throws SQLException en caso de error con la base de datos.
     */
    public boolean softDeleteAntecedente(int idAntecedente) throws SQLException {
        // Verifica si el antecedente tiene tratamientos activos
        if (tieneTratamientos(idAntecedente)) {
            return false; // No se puede desactivar si tiene tratamientos activos
        }

        String sql = "UPDATE antecedentes SET activo = false WHERE id = ?";

        try (Connection con = ConexionBD.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idAntecedente); // Asigna el ID del antecedente
            int filasAfectadas = ps.executeUpdate(); // Ejecuta la actualización

            return filasAfectadas > 0; // Retorna true si se modificó al menos una fila
        }
    }
}
