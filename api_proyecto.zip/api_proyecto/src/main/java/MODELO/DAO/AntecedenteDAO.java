package MODELO.DAO;

import MODELO.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

/**
 * Clase DAO para la entidad Antecedente.
 * Proporciona metodos para:
 * - obtener la ultima fecha de antecedente de una mascota
 * - verificar si un antecedente tiene tratamientos activos
 * - desactivar logicamente un antecedente sin tratamientos activos
 */
public class AntecedenteDAO {

    /**
     * Recupera la ultima fecha de antecedente registrada para una mascota.
     *
     * @param idMascota ID de la mascota
     * @return fecha mas reciente de antecedente o null si no hay registros
     */
    public static LocalDate getUltimaFechaAntecedenteByIdMascota(int idMascota) {
        // Consulta SQL para obtener la fecha mas reciente
        String sql = 
            "SELECT fecha_creado "
          + "FROM antecedentes "
          + "WHERE id_mascota = ? "
          + "ORDER BY fecha_creado DESC "
          + "LIMIT 1";

        // Ejecuta la consulta y cierra recursos automaticamente
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            // Asigna el ID de la mascota al parametro
            ps.setInt(1, idMascota);

            // Ejecuta la consulta y procesa el resultado
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // Convierte la fecha SQL a LocalDate y la retorna
                    return rs.getDate("fecha_creado").toLocalDate();
                }
            }

        } catch (SQLException e) {
            // Imprime la traza de error en caso de excepcion
            e.printStackTrace();
        }

        // Retorna null si no hay resultados o ocurre un error
        return null;
    }

    /**
     * Verifica si un antecedente tiene tratamientos activos asociados.
     *
     * @param idAntecedente ID del antecedente a verificar
     * @return true si hay al menos un tratamiento activo; false en caso contrario
     * @throws SQLException si ocurre un error en la consulta
     */
    public boolean tieneTratamientos(int idAntecedente) throws SQLException {
        // SQL para contar tratamientos activos de un antecedente
        String sql = 
            "SELECT COUNT(*) "
          + "FROM antecedentes_tratamientos "
          + "WHERE id_antecedente = ? "
          + "AND activo = true";

        // Ejecuta la consulta y cierra recursos automaticamente
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            // Asigna el ID del antecedente al parametro
            ps.setInt(1, idAntecedente);

            // Ejecuta la consulta y obtiene el conteo
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // Retorna true si el conteo es mayor a cero
                    return rs.getInt(1) > 0;
                }
            }
        }

        // Retorna false si no hay tratamientos o falla la consulta
        return false;
    }

    /**
     * Desactiva logicamente un antecedente si no tiene tratamientos activos.
     *
     * @param idAntecedente ID del antecedente a desactivar
     * @return true si la desactivacion fue exitosa; false si tenia tratamientos activos o no se actualizo
     * @throws SQLException si ocurre un error al ejecutar la actualizacion
     */
    public boolean softDeleteAntecedente(int idAntecedente) throws SQLException {
        // Verifica primero si el antecedente tiene tratamientos activos
        if (tieneTratamientos(idAntecedente)) {
            // No desactiva si hay tratamientos activos
            return false;
        }

        // SQL para marcar el antecedente como inactivo
        String sql = 
            "UPDATE antecedentes "
          + "SET activo = false "
          + "WHERE id = ?";

        // Ejecuta la actualizacion y cierra recursos automaticamente
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            // Asigna el ID del antecedente al parametro
            ps.setInt(1, idAntecedente);

            // Ejecuta la actualizacion y verifica filas afectadas
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;
        }
    }
}
