package MODELO.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Clase DAO para la entidad Tratamiento.
 * Proporciona metodos para gestionar tratamientos y su eliminacion logica.
 */
public class TratamientoDAO {

    private Connection con;  // Conexion a la base de datos

    /**
     * Constructor que recibe la conexion a la base de datos.
     *
     * @param con Conexion JDBC existente
     */
    public TratamientoDAO(Connection con) {
        this.con = con;
    }

    /**
     * Desactiva logicamente un tratamiento (soft delete) si no tiene
     * medicamentos activos asociados.
     *
     * @param idTratamiento ID del tratamiento a desactivar
     * @return true si se desactivo el tratamiento; false si tiene
     *         medicamentos activos o no se pudo actualizar
     * @throws SQLException si ocurre un error de BD
     */
    public boolean eliminarTratamiento(int idTratamiento) throws SQLException {
        // Verifica si hay medicamentos activos para este tratamiento
        String sqlVerificar =
            "SELECT COUNT(*) FROM medicamentos_tratamiento "
          + "WHERE id_tratamiento = ? AND activo = true";
        try (PreparedStatement ps = con.prepareStatement(sqlVerificar)) {
            ps.setInt(1, idTratamiento);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() && rs.getInt(1) > 0) {
                    // Existen medicamentos activos: no se elimina
                    return false;
                }
            }
        }

        // Marca el tratamiento como inactivo (soft delete)
        String sqlSoftDelete =
            "UPDATE antecedentes_tratamientos SET activo = false "
          + "WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sqlSoftDelete)) {
            ps.setInt(1, idTratamiento);
            int filasAfectadas = ps.executeUpdate();
            // Retorna true si se actualizo al menos una fila
            return filasAfectadas > 0;
        }
    }
}
