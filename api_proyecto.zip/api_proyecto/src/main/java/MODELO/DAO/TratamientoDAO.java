package MODELO.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Clase que maneja las operaciones de acceso a datos para la entidad
 * Tratamiento. Proporciona metodos para gestionar tratamientos y su
 * eliminacion.
 */
public class TratamientoDAO {

    private Connection con; // Conexion a la base de datos

    /**
     * Constructor que recibe una conexion a la base de datos.
     *
     * @param con Conexion a la base de datos.
     */
    public TratamientoDAO(Connection con) {
        this.con = con; // Inicializa la conexion
    }

    /**
     * Desactiva logicamente un tratamiento (SoftDelete) si no tiene
     * medicamentos activos asociados.
     *
     * Este metodo verifica primero si existen medicamentos activos vinculados
     * al tratamiento en la tabla 'medicamentos_tratamiento'. Si no hay ninguno,
     * actualiza el campo 'activo' a false en la tabla
     * 'antecedentes_tratamientos'.
     *
     * @param idTratamiento Identificador del tratamiento a desactivar.
     * @return true si el tratamiento fue desactivado correctamente, false si
     * tiene medicamentos activos o no se pudo actualizar.
     * @throws SQLException Si ocurre un error al acceder o modificar los datos
     * en la base de datos.
     */
    public boolean eliminarTratamiento(int idTratamiento) throws SQLException {
        // Verificar si hay medicamentos asociados activos 
        String sqlVerificar = "SELECT COUNT(*) FROM medicamentos_tratamiento "
                + "WHERE id_tratamiento = ? AND activo = true"; // Consulta SQL para verificar medicamentos activos
        try (PreparedStatement ps = con.prepareStatement(sqlVerificar)) {
            ps.setInt(1, idTratamiento); // Establece el ID del tratamiento
            ResultSet rs = ps.executeQuery(); // Ejecuta la consulta
            if (rs.next() && rs.getInt(1) > 0) {
                // Si hay medicamentos asociados, no se puede eliminar
                return false; // Retorna false si tiene medicamentos activos
            }
        }

        // SoftDelete del tratamiento
        String sqlSoftDelete = "UPDATE antecedentes_tratamientos SET activo = false WHERE id = ?"; // Consulta SQL para SoftDelete
        try (PreparedStatement ps = con.prepareStatement(sqlSoftDelete)) {
            ps.setInt(1, idTratamiento); // Establece el ID del tratamiento
            int filasAfectadas = ps.executeUpdate(); // Ejecuta la actualizacion
            return filasAfectadas > 0; // Retorna true si se actualizo, false si no
        }
    }
}
