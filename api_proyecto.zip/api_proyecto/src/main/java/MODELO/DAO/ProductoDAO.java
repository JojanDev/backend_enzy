package MODELO.DAO;

import MODELO.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Clase que maneja las operaciones de acceso a datos para la entidad Producto.
 * Proporciona metodos para gestionar el stock de productos.
 */
public class ProductoDAO {

    /**
     * Descuenta una cantidad especifica del stock del producto.
     * 
     * Este metodo actualiza el campo 'stock' en la tabla 'productos',
     * restando la cantidad indicada al producto con el ID especificado.
     *
     * @param idProducto Identificador del producto.
     * @param cantidadRestar Cantidad que se desea descontar del stock.
     * @return true si la operacion fue exitosa, false en caso contrario.
     */
    public boolean restarStock(int idProducto, int cantidadRestar) {
        String sql = "UPDATE productos SET stock = stock - ? WHERE id = ?";

        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, cantidadRestar);
            ps.setInt(2, idProducto);

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al descontar stock del producto: " + e.getMessage());
            return false;
        }
    }
}
