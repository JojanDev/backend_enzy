package MODELO.DAO;

import MODELO.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Clase DAO para la entidad Producto.
 * Proporciona metodos para gestionar el stock de productos.
 */
public class ProductoDAO {

    /**
     * Resta una cantidad especifica del stock de un producto.
     * Actualiza el campo 'stock' en la tabla 'productos' asi:
     *   stock = stock - cantidadRestar
     *
     * @param idProducto      ID del producto cuyo stock se descuenta
     * @param cantidadRestar  Cantidad a restar del stock actual
     * @return true si al menos una fila fue actualizada; false en caso contrario
     */
    public boolean restarStock(int idProducto, int cantidadRestar) {
        // SQL con placeholders para cantidad y id
        String sql = "UPDATE productos SET stock = stock - ? WHERE id = ?";

        // try-with-resources asegura que conexion y statement se cierren
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            // Asigna el valor a cada placeholder
            ps.setInt(1, cantidadRestar);
            ps.setInt(2, idProducto);

            // Ejecuta la actualizacion y comprueba filas afectadas
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            // Imprime mensaje de error y retorna false
            System.err.println("Error al descontar stock: " + e.getMessage());
            return false;
        }
    }
}
