package MODELO.DAO;

import MODELO.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Clase que maneja las operaciones de acceso a datos para la entidad Mascota.
 * Permite realizar acciones como desactivar mascotas en la base de datos.
 */
public class MascotaDAO {

    /**
     * Desactiva una mascota marcando su estado como no viva (estado_vital = false).
     *
     * Este metodo realiza una actualizacion en la tabla 'mascotas',
     * cambiando el campo 'estado_vital' a false para indicar que la mascota ha fallecido.
     *
     * @param idMascota Identificador de la mascota a desactivar.
     * @return true si la actualizacion fue exitosa, false si no se encontro la mascota.
     * @throws SQLException Si ocurre un error al acceder a la base de datos.
     */
    public boolean desactivarMascota(int idMascota) throws SQLException {
        String sql = "UPDATE mascotas SET estado_vital = ? WHERE id = ?";

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setBoolean(1, false); // Marca la mascota como no viva
            ps.setInt(2, idMascota); // ID de la mascota a actualizar

            int filasAfectadas = ps.executeUpdate(); // Ejecuta la actualizacion
            return filasAfectadas > 0; // Retorna true si se modifico al menos una fila

        }
    }
}
