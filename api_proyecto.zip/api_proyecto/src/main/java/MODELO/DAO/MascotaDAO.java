package MODELO.DAO;

import MODELO.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Clase DAO para la entidad Mascota.
 * Permite desactivar una mascota marcando su estado como no viva.
 */
public class MascotaDAO {

    /**
     * Desactiva una mascota estableciendo estado_vital = false.
     *
     * @param idMascota identificador de la mascota a desactivar
     * @return true si la actualizacion afecto al menos una fila; false si no se encontro mascota
     * @throws SQLException si ocurre un error al ejecutar la consulta
     */
    public boolean desactivarMascota(int idMascota) throws SQLException {
        // SQL para actualizar el campo estado_vital de la mascota
        String sql = "UPDATE mascotas SET estado_vital = ? WHERE id = ?";

        // Abre conexion y prepara la sentencia; cierra recursos automaticamente
        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            // Asigna false al primer parametro para marcar mascota como no viva
            ps.setBoolean(1, false);
            // Asigna el id de la mascota al segundo parametro
            ps.setInt(2, idMascota);

            // Ejecuta la actualizacion y obtiene el numero de filas afectadas
            int filasAfectadas = ps.executeUpdate();
            // Retorna true si al menos una fila fue modificada
            return filasAfectadas > 0;
        }
    }
}

