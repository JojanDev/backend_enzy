package MODELO.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Clase DAO para la entidad MedicamentoTratamiento.
 * Permite desactivar medicamentos vinculados a tratamientos sin eliminarlos fisicamente.
 */
public class MedicamentoTratamientoDAO {

    // Conexion JDBC activa a la base de datos
    private final Connection connection;

    /**
     * Constructor que recibe una conexion JDBC activa.
     *
     * @param connection conexion a la base de datos
     */
    public MedicamentoTratamientoDAO(Connection connection) {
        this.connection = connection;
    }

    /**
     * Desactiva logicamente un medicamento de un tratamiento (soft delete).
     * Actualiza el campo 'activo' a false en la tabla 'medicamentos_tratamiento'.
     *
     * @param idMedicamentoTratamiento id del registro a desactivar
     * @return true si se desactivo con exito; false en caso contrario
     * @throws SQLException si ocurre un error al ejecutar la consulta
     */
    public boolean eliminarMedicamentoTratamiento(int idMedicamentoTratamiento) throws SQLException {
        // SQL para marcar el registro como inactivo
        String sql = "UPDATE medicamentos_tratamiento SET activo = false WHERE id = ?";

        // Prepara la sentencia y asigna el parametro del id
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idMedicamentoTratamiento);

            // Ejecuta la actualizacion y retorna true si afecto al menos una fila
            int filasAfectadas = stmt.executeUpdate();
            return filasAfectadas > 0;
        }
    }
}



