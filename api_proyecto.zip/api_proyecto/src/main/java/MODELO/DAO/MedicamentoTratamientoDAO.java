package MODELO.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Clase que maneja las operaciones de acceso a datos para la entidad MedicamentoTratamiento.
 * Permite realizar operaciones como desactivar medicamentos asociados a tratamientos.
 */
public class MedicamentoTratamientoDAO {

    private final Connection connection;

    /**
     * Constructor que recibe una conexion a la base de datos.
     *
     * @param connection Conexion activa a la base de datos.
     */
    public MedicamentoTratamientoDAO(Connection connection) {
        this.connection = connection;
    }

    /**
     * Realiza una eliminacion logica (SoftDelete) de un medicamento asociado a un tratamiento.
     * 
     * Este metodo actualiza el campo 'activo' a false en la tabla 'medicamentos_tratamiento',
     * desactivando el registro sin eliminarlo fisicamente.
     *
     * @param idMedicamentoTratamiento Identificador del registro en medicamentos_tratamiento.
     * @return true si el registro fue desactivado correctamente, false si no se pudo actualizar.
     * @throws SQLException Si ocurre un error al ejecutar la consulta.
     */
    public boolean eliminarMedicamentoTratamiento(int idMedicamentoTratamiento) throws SQLException {
        String sql = "UPDATE medicamentos_tratamiento SET activo = false WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idMedicamentoTratamiento);
            int filasAfectadas = stmt.executeUpdate();
            return filasAfectadas > 0;
        }
    }
}


