package MODELO.DAO;

import MODELO.ConexionBD;
import MODELO.InformacionClientesPersonal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase DAO para la entidad Cliente.
 * Proporciona metodos para recuperar informacion de clientes
 * que no estan asociados a ningun empleado.
 */
public class ClienteDAO {

    /**
     * Recupera una lista de clientes que no estan asociados a ningun empleado.
     *
     * @return lista de InformacionClientesPersonal con los clientes sin empleado asignado
     */
    public List<InformacionClientesPersonal> getClientesSinEmpleado() {
        // Lista que almacenara los resultados de la consulta
        List<InformacionClientesPersonal> lista = new ArrayList<>();

        // Consulta SQL para obtener clientes cuyo id_info no aparece en personal
        String sql =
            "SELECT i.id, i.id_tipo_documento, i.numero_documento, "
          + "i.nombre, i.telefono, i.correo, i.direccion "
          + "FROM informacion_clientes_personal i "
          + "JOIN clientes c ON c.id_info = i.id "
          + "LEFT JOIN personal p ON p.id_info = i.id "
          + "WHERE p.id IS NULL";

        // Ejecuta la consulta y cierra recursos automaticamente
        try (Connection con = ConexionBD.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            // Recorre cada fila del resultado
            while (rs.next()) {
                // Crea un nuevo DTO y asigna cada columna
                InformacionClientesPersonal info = new InformacionClientesPersonal();
                info.setId(rs.getInt("id"));
                info.setId_tipo_documento(rs.getInt("id_tipo_documento"));
                info.setNumero_documento(rs.getString("numero_documento"));
                info.setNombre(rs.getString("nombre"));
                info.setTelefono(rs.getString("telefono"));
                info.setCorreo(rs.getString("correo"));
                info.setDireccion(rs.getString("direccion"));

                // Agrega el DTO a la lista de resultados
                lista.add(info);
            }

        } catch (SQLException e) {
            // Imprime la traza de error si ocurre una excepcion SQL
            e.printStackTrace();
        }

        // Retorna la lista de clientes sin empleado (puede estar vacia)
        return lista;
    }
}
