package MODELO.DAO;

import MODELO.ConexionBD;
import java.lang.reflect.Field;
import java.sql.*;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase generica para operaciones CRUD usando reflexion y JDBC. Maneja
 * entidades mapeadas a columnas de BD y soporta conexion externa para control
 * de transacciones.
 */
public class CrudDAO {

    // Conexion externa opcional; si se pasa, se reusa en lugar de abrir otra
    private Connection externalConnection;

    /**
     * Constructor por defecto. Cada operacion abre y cierra su propia conexion.
     */
    public CrudDAO() {
        // externalConnection queda en null -> usa conexiones internas
    }

    /**
     * Constructor que recibe una conexion abierta. Permite controlar
     * commit/rollback desde fuera.
     */
    public CrudDAO(Connection connection) {
        this.externalConnection = connection;
    }

    /**
     * Devuelve la conexion activa: - Si externalConnection no es null, la
     * devuelve - En caso contrario, abre una nueva via ConexionBD.conectar()
     */
    private Connection getConnection() throws SQLException {
        if (externalConnection != null) {
            return externalConnection;
        }
        return ConexionBD.conectar();
    }

    /**
     * Recupera todos los registros de la tabla indicada y los mapea a
     * instancias de la clase especificada.
     *
     * @param <T> Tipo de la entidad
     * @param clazz Clase de la entidad (por ejemplo, Usuario.class)
     * @param tabla Nombre de la tabla en la BD
     * @return Lista de objetos con los datos leidos
     */
    public <T> List<T> getAll(Class<T> clazz, String tabla) {
        List<T> lista = new ArrayList<>();
        String sql = "SELECT * FROM " + tabla + " ORDER BY id DESC";

        Connection con = null;
        boolean closeAfter = (externalConnection == null);

        try {
            con = getConnection();                        // Abrir o reusar conexion
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            // Obtener todos los campos de la clase, incluso privados
            Field[] campos = clazz.getDeclaredFields();

            while (rs.next()) {
                // Crear nueva instancia de T
                T obj = clazz.getDeclaredConstructor().newInstance();

                for (Field campo : campos) {
                    campo.setAccessible(true);             // Permite acceder a privados

                    try {
                        Object valor = rs.getObject(campo.getName());

                        // Si es Timestamp y el campo es LocalDateTime
                        if (valor instanceof Timestamp
                                && campo.getType().equals(LocalDateTime.class)) {
                            campo.set(obj, ((Timestamp) valor).toLocalDateTime());

                            // Si es Date y el campo es LocalDate
                        } else if (valor instanceof Date
                                && campo.getType().equals(LocalDate.class)) {
                            campo.set(obj, ((Date) valor).toLocalDate());

                        } else {
                            campo.set(obj, valor);            // Asignar valor directo
                        }

                    } catch (SQLException e) {
                        // Columna no existe o error de tipo -> ignorar
                    }
                }

                lista.add(obj);  // Anadir objeto a la lista
            }

        } catch (Exception e) {
            e.printStackTrace(); // Mostrar errores
        } finally {
            if (closeAfter && con != null) {
                try {
                    con.close();  // Cerrar conexion interna
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return lista;
    }

    /**
     * Recupera registros filtrados por un campo especifico. Usa reflexion para
     * mapear cada fila a un objeto del tipo indicado.
     *
     * @param <T> Tipo de la entidad
     * @param clazz Clase de la entidad (p. ej. Usuario.class)
     * @param tabla Nombre de la tabla en la base de datos
     * @param campoBusqueda Nombre de la columna para el filtro
     * @param valorBusqueda Valor que se buscara en esa columna
     * @return Lista de objetos que cumplen el filtro
     */
    public <T> List<T> getAllByField(
            Class<T> clazz,
            String tabla,
            String campoBusqueda,
            Object valorBusqueda) {

        // Lista donde se guardaran los resultados
        List<T> lista = new ArrayList<>();

        // Consulta con placeholder para el valor de filtro
        String sql = "SELECT * FROM "
                + tabla
                + " WHERE "
                + campoBusqueda
                + " = ? ORDER BY id DESC";

        Connection con = null;
        // Si no hay conexion externa, este metodo debe cerrarla al final
        boolean closeAfter = (externalConnection == null);

        try {
            // Abre o reutiliza la conexion
            con = getConnection();
            // Prepara la consulta y asigna el valor del filtro
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setObject(1, valorBusqueda);
            // Ejecuta y obtiene los datos
            ResultSet rs = ps.executeQuery();

            // Obtiene todos los campos de la clase para asignarles valores
            Field[] campos = clazz.getDeclaredFields();

            // Recorre cada fila resultado
            while (rs.next()) {
                // Crea una nueva instancia de la entidad
                T obj = clazz.getDeclaredConstructor().newInstance();

                // Para cada campo, intenta sacar el valor de la columna
                for (Field campo : campos) {
                    campo.setAccessible(true);

                    try {
                        Object valor = rs.getObject(campo.getName());

                        // Si la columna es Timestamp y el campo es LocalDateTime
                        if (valor instanceof Timestamp
                                && campo.getType().equals(LocalDateTime.class)) {
                            campo.set(obj,
                                    ((Timestamp) valor).toLocalDateTime());

                            // Si la columna es Date y el campo es LocalDate
                        } else if (valor instanceof Date
                                && campo.getType().equals(LocalDate.class)) {
                            campo.set(obj,
                                    ((Date) valor).toLocalDate());

                            // Para otros tipos compatibles, asigna directamente
                        } else {
                            campo.set(obj, valor);
                        }

                    } catch (SQLException e) {
                        // Ignora si no existe la columna o tipo no coincide
                    }
                }

                // Añade el objeto mapeado a la lista
                lista.add(obj);
            }

        } catch (Exception e) {
            // Muestra error en consola si falla reflexion o SQL
            e.printStackTrace();

        } finally {
            // Cierra la conexion interna si se abrio aqui
            if (closeAfter && con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        // Devuelve todos los objetos encontrados
        return lista;
    }

    /**
     * Recupera un unico registro por su ID. Usa reflexion para mapear la fila a
     * un objeto de la clase indicada.
     *
     * @param <T> Tipo de la entidad
     * @param clazz Clase de la entidad (p. ej. Usuario.class)
     * @param tabla Nombre de la tabla en la BD
     * @param id Valor del campo id para buscar
     * @return Instancia encontrada o null si no existe
     */
    public <T> T getById(
            Class<T> clazz,
            String tabla,
            int id) {

        // Consulta con parametro para el id
        String sql = "SELECT * FROM " + tabla + " WHERE id = ?";
        T obj = null;

        Connection con = null;
        boolean closeAfter = (externalConnection == null);

        try {
            // Abre o reutiliza la conexion
            con = getConnection();
            // Prepara consulta e inserta el id
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            // Campos de la clase para asignar valores
            Field[] campos = clazz.getDeclaredFields();

            // Si hay resultado, mapea la fila a la instancia
            if (rs.next()) {
                obj = clazz.getDeclaredConstructor().newInstance();

                for (Field campo : campos) {
                    campo.setAccessible(true);

                    try {
                        Object valor = rs.getObject(campo.getName());

                        if (valor instanceof Timestamp
                                && campo.getType().equals(LocalDateTime.class)) {
                            campo.set(obj,
                                    ((Timestamp) valor).toLocalDateTime());
                        } else if (valor instanceof Date
                                && campo.getType().equals(LocalDate.class)) {
                            campo.set(obj,
                                    ((Date) valor).toLocalDate());
                        } else {
                            campo.set(obj, valor);
                        }

                    } catch (SQLException e) {
                        // Ignora si no existe la columna o tipo no coincide
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (closeAfter && con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        // Devuelve el objeto o null si no se encontro
        return obj;
    }

    /**
     * Inserta un nuevo registro en la base de datos a partir de un objeto.
     * Utiliza reflexion para construir dinamicamente la consulta SQL y asignar
     * los valores.
     *
     * @param <T> Tipo de la entidad
     * @param tabla Nombre de la tabla
     * @param objeto Objeto que se desea insertar
     * @return El mismo objeto con su ID generado o null si falla
     */
    public <T> T create(String tabla, T objeto) {
        // Construccion de listas para columnas, placeholders y valores
        StringBuilder columnas = new StringBuilder();
        StringBuilder valores = new StringBuilder();
        List<Object> parametros = new ArrayList<>();

        // Recoge todos los campos del objeto, incluidos privados
        Field[] campos = objeto.getClass().getDeclaredFields();

        for (Field campo : campos) {
            campo.setAccessible(true);
            // Ignora el campo "id" (se asume autogenerado)
            if (campo.getName().equalsIgnoreCase("id")) {
                continue;
            }
            try {
                Object valor = campo.get(objeto);
                // Solo incluye atributos no nulos
                if (valor != null) {
                    columnas.append(campo.getName()).append(", ");
                    valores.append("?, ");
                    parametros.add(valor);
                }
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }

        // Si no hay campos para insertar, devuelve null
        if (parametros.isEmpty()) {
            return null;
        }

        // Quita la coma y espacio finales
        columnas.setLength(columnas.length() - 2);
        valores.setLength(valores.length() - 2);

        // Construye la consulta INSERT dinámica
        String sql = MessageFormat.format(
                "INSERT INTO {0} ({1}) VALUES ({2})",
                tabla, columnas, valores
        );

        Connection con = null;
        boolean closeAfter = (externalConnection == null);

        try {
            // Abre o reutiliza la conexion
            con = getConnection();
            // Prepara la instruccion para devolver claves generadas
            PreparedStatement ps = con.prepareStatement(
                    sql, PreparedStatement.RETURN_GENERATED_KEYS
            );

            // Asigna cada parametro al placeholder correspondiente
            for (int i = 0; i < parametros.size(); i++) {
                Object param = parametros.get(i);
                if (param instanceof LocalDateTime) {
                    ps.setTimestamp(i + 1, Timestamp.valueOf((LocalDateTime) param));
                } else if (param instanceof LocalDate) {
                    ps.setDate(i + 1, Date.valueOf((LocalDate) param));
                } else {
                    ps.setObject(i + 1, param);
                }
            }

            int filasAfectadas = ps.executeUpdate();
            // Si se inserto al menos una fila, intenta leer el ID generado
            if (filasAfectadas > 0) {
                ResultSet keys = ps.getGeneratedKeys();
                if (keys.next()) {
                    int idGenerado = keys.getInt(1);
                    try {
                        // Asigna el ID generado al atributo "id" del objeto
                        Field idField = objeto.getClass().getDeclaredField("id");
                        idField.setAccessible(true);
                        idField.set(objeto, idGenerado);
                    } catch (NoSuchFieldException | IllegalAccessException e) {
                        e.printStackTrace();
                    }
                    return objeto;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cierra la conexion interna si se abrio aqui
            if (closeAfter && con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        // En caso de fallo, devuelve null
        return null;
    }

    /**
     * Actualiza un registro existente en la base de datos usando el objeto
     * proporcionado. Usa reflexion para armar dinamicamente la consulta UPDATE
     * con los atributos del objeto.
     *
     * @param <T> Tipo de la entidad
     * @param objeto Instancia con los valores nuevos (debe incluir el campo ID)
     * @param tabla Nombre de la tabla
     * @param campoId Nombre del campo identificador (por ejemplo, "id")
     * @return true si se actualizo al menos una fila; false en caso contrario
     * @throws SQLException si ocurre un error durante la operacion
     */
    public <T> boolean update(T objeto, String tabla, String campoId) throws SQLException {
        Connection conexion = null;
        PreparedStatement ps = null;

        try {
            // Abre o reutiliza la conexion
            conexion = getConnection();
            // Desactiva autoCommit para manejar la transaccion manualmente
            conexion.setAutoCommit(false);

            // Obtiene todos los campos de la clase para componer el SET
            Field[] campos = objeto.getClass().getDeclaredFields();
            StringBuilder sql = new StringBuilder("UPDATE " + tabla + " SET ");

            // Lista de valores para los placeholders y variable para el ID
            List<Object> valores = new ArrayList<>();
            Object valorId = null;

            // Recorre cada campo para armar la parte SET y capturar el ID
            for (Field campo : campos) {
                campo.setAccessible(true);
                try {
                    // Si es el campo ID, lo guardamos y no lo incluimos en SET
                    if (campo.getName().equalsIgnoreCase(campoId)) {
                        valorId = campo.get(objeto);
                        continue;
                    }
                    // Agrega "columna = ?" al SQL
                    sql.append(campo.getName()).append(" = ?, ");
                    Object valorCampo = campo.get(objeto);

                    // Convierte fechas si es necesario
                    if (valorCampo instanceof LocalDateTime) {
                        valores.add(Timestamp.valueOf((LocalDateTime) valorCampo));
                    } else if (valorCampo instanceof LocalDate) {
                        valores.add(Date.valueOf((LocalDate) valorCampo));
                    } else {
                        valores.add(valorCampo);
                    }

                } catch (IllegalAccessException e) {
                    throw new RuntimeException("No se pudo acceder al campo "
                            + campo.getName(), e);
                }
            }

            // Quita la coma y espacio finales de SET
            sql.setLength(sql.length() - 2);
            // Agrega la clausula WHERE para el ID
            sql.append(" WHERE ").append(campoId).append(" = ?");

            // Prepara la sentencia SQL
            ps = conexion.prepareStatement(sql.toString());

            // Asigna los valores a los placeholders
            int index = 1;
            for (Object valor : valores) {
                ps.setObject(index++, valor);
            }
            // Asigna el valor del ID al ultimo placeholder
            ps.setObject(index, valorId);

            // Ejecuta la actualizacion y confirma la transaccion
            int filasAfectadas = ps.executeUpdate();
            conexion.commit();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            // Si falla, revierte la transaccion
            if (conexion != null) {
                conexion.rollback();
            }
            throw new SQLException("Error al actualizar: " + e.getMessage(), e);

        } finally {
            // Cierra el PreparedStatement y la conexion si existen
            if (ps != null) {
                ps.close();
            }
            if (conexion != null) {
                conexion.close();
            }
        }
    }

    /**
     * Elimina un registro de la base de datos segun su ID.
     *
     * @param id Valor del campo ID para eliminar
     * @param tabla Nombre de la tabla
     * @param campoId Nombre del campo que representa el ID
     * @return true si se elimino al menos una fila; false en caso contrario
     * @throws SQLException si ocurre un error durante la operacion
     */
    public boolean delete(Object id, String tabla, String campoId) throws SQLException {
        Connection conexion = null;
        PreparedStatement ps = null;

        try {
            // Abre o reutiliza la conexion
            conexion = getConnection();
            // Desactiva autoCommit para manejar la transaccion manualmente
            conexion.setAutoCommit(false);

            // Construye la consulta DELETE
            String sql = "DELETE FROM " + tabla
                    + " WHERE " + campoId + " = ?";
            ps = conexion.prepareStatement(sql);
            // Asigna el valor del ID al placeholder
            ps.setObject(1, id);

            // Ejecuta la eliminacion y confirma
            int filasAfectadas = ps.executeUpdate();
            conexion.commit();

            return filasAfectadas > 0;

        } catch (SQLException e) {
            // Si falla, revierte la transaccion
            if (conexion != null) {
                conexion.rollback();
            }
            throw new SQLException("Error al eliminar: " + e.getMessage(), e);

        } finally {
            // Cierra el PreparedStatement y la conexion si existen
            if (ps != null) {
                ps.close();
            }
            if (conexion != null) {
                conexion.close();
            }
        }
    }
}
