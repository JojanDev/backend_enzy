package MODELO.DAO;

import MODELO.ConexionBD;
import java.lang.reflect.Field;
import java.sql.*;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase generica para operaciones CRUD utilizando reflexion y JDBC. Permite
 * manejar entidades cuyos atributos esten mapeados a columnas de base de datos.
 * Soporta el uso de conexiones externas para transacciones personalizadas.
 */
public class CrudDAO {

    /**
     * Conexion externa proporcionada desde el exterior. Si se establece, se
     * reutiliza en lugar de abrir una nueva conexion.
     */
    private Connection externalConnection;

    /**
     * Constructor por defecto. No usa conexion externa. Las operaciones abriran
     * y cerraran su propia conexion.
     */
    public CrudDAO() {
    }

    /**
     * Constructor que permite utilizar una conexion externa. Util cuando se
     * desea manejar manualmente las transacciones (commit/rollback) desde un
     * flujo externo al DAO, como en servicios REST con multiples operaciones.
     *
     * @param connection Conexion JDBC abierta y gestionada externamente.
     */
    public CrudDAO(Connection connection) {
        this.externalConnection = connection;
    }

    /**
     * Obtiene la conexion activa. Si se proporciono una conexion externa, se
     * reutiliza. Si no, se crea una nueva conexion interna.
     *
     * @return Conexion JDBC activa.
     * @throws SQLException Si ocurre un error al obtener la conexion.
     */
    private Connection getConnection() throws SQLException {
        return (externalConnection != null) ? externalConnection : ConexionBD.conectar();
    }

    /**
     * Recupera todos los registros de una tabla y los convierte en objetos del
     * tipo especificado. Utiliza reflexion para mapear columnas de la base de
     * datos a atributos de la clase.
     *
     * @param <T> Tipo de la entidad.
     * @param clazz Clase de la entidad.
     * @param tabla Nombre de la tabla.
     * @return Lista de objetos del tipo dado.
     */
    public <T> List<T> getAll(Class<T> clazz, String tabla) {
        List<T> lista = new ArrayList<>();
        String sql = "SELECT * FROM " + tabla + " ORDER BY id DESC";

        Connection con = null;
        boolean shouldClose = (externalConnection == null); // Si usamos conexion interna, debemos cerrarla

        try {
            con = getConnection(); // Obtiene la conexion activa
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            // Obtiene todos los atributos declarados en la clase (incluso privados)
            Field[] campos = clazz.getDeclaredFields();

            while (rs.next()) {
                // Crea una nueva instancia del tipo T usando su constructor sin argumentos
                T obj = clazz.getDeclaredConstructor().newInstance();

                // Itera sobre cada atributo de la clase
                for (Field campo : campos) {
                    campo.setAccessible(true); // Permite acceder a atributos privados

                    try {
                        // Obtiene el valor de la columna con el mismo nombre que el atributo
                        Object valor = rs.getObject(campo.getName());

                        // Si el atributo es LocalDateTime, convierte desde Timestamp
                        if (valor instanceof Timestamp && campo.getType().equals(LocalDateTime.class)) {
                            campo.set(obj, ((Timestamp) valor).toLocalDateTime());

                            // Si el atributo es LocalDate, convierte desde Date
                        } else if (valor instanceof Date && campo.getType().equals(LocalDate.class)) {
                            campo.set(obj, ((Date) valor).toLocalDate());

                            // Para otros tipos, asigna directamente
                        } else {
                            campo.set(obj, valor);
                        }

                    } catch (SQLException e) {
                        // Si la columna no existe en el ResultSet, se ignora
                    }
                }

                lista.add(obj); // Agrega el objeto mapeado a la lista
            }

        } catch (Exception e) {
            e.printStackTrace(); // Captura errores de reflexion o SQL
        } finally {
            try {
                if (shouldClose && con != null) {
                    con.close(); // Cierra la conexion si fue creada internamente
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return lista;
    }

    /**
     * Recupera registros filtrados por un campo especifico. Utiliza reflexion
     * para mapear los resultados a objetos del tipo especificado.
     *
     * @param <T> Tipo de la entidad.
     * @param clazz Clase de la entidad.
     * @param tabla Nombre de la tabla.
     * @param campoBusqueda Nombre del campo por el cual se filtrara.
     * @param valorBusqueda Valor del campo a buscar.
     * @return Lista de entidades encontradas.
     */
    public <T> List<T> getAllByField(Class<T> clazz, String tabla, String campoBusqueda, Object valorBusqueda) {
        List<T> lista = new ArrayList<>();
        String sql = "SELECT * FROM " + tabla + " WHERE " + campoBusqueda + " = ? ORDER BY id DESC";

        Connection con = null;
        boolean shouldClose = (externalConnection == null);

        try {
            con = getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setObject(1, valorBusqueda); // Establece el valor del filtro
            ResultSet rs = ps.executeQuery();

            Field[] campos = clazz.getDeclaredFields();

            while (rs.next()) {
                T obj = clazz.getDeclaredConstructor().newInstance();

                for (Field campo : campos) {
                    campo.setAccessible(true);

                    try {
                        Object valor = rs.getObject(campo.getName());

                        if (valor instanceof Timestamp && campo.getType().equals(LocalDateTime.class)) {
                            campo.set(obj, ((Timestamp) valor).toLocalDateTime());
                        } else if (valor instanceof Date && campo.getType().equals(LocalDate.class)) {
                            campo.set(obj, ((Date) valor).toLocalDate());
                        } else {
                            campo.set(obj, valor);
                        }

                    } catch (SQLException e) {
                        // Ignorar si la columna no existe
                    }
                }

                lista.add(obj);
            }

        } catch (Exception e) {
            e.printStackTrace(); // Captura errores de reflexion o SQL
        } finally {
            try {
                if (shouldClose && con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return lista;
    }

    /**
     * Recupera un registro por su ID desde la base de datos y lo convierte en
     * una instancia de la clase especificada. Utiliza reflexion para mapear los
     * valores de las columnas a los atributos del objeto.
     *
     * @param <T> Tipo de la entidad.
     * @param clazz Clase de la entidad.
     * @param tabla Nombre de la tabla.
     * @param id Identificador del registro.
     * @return Objeto recuperado o null si no se encuentra.
     */
    public <T> T getById(Class<T> clazz, String tabla, int id) {
        String sql = "SELECT * FROM " + tabla + " WHERE id = ?";
        T obj = null;

        Connection con = null;
        boolean shouldClose = (externalConnection == null); // Si usamos conexion interna, debemos cerrarla

        try {
            con = getConnection(); // Obtiene la conexion activa
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id); // Asigna el valor del ID al parametro de la consulta
            ResultSet rs = ps.executeQuery(); // Ejecuta la consulta

            Field[] campos = clazz.getDeclaredFields(); // Obtiene todos los atributos de la clase

            if (rs.next()) {
                obj = clazz.getDeclaredConstructor().newInstance(); // Crea una instancia vacía del objeto

                for (Field campo : campos) {
                    campo.setAccessible(true); // Permite modificar atributos privados

                    try {
                        Object valor = rs.getObject(campo.getName()); // Obtiene el valor de la columna con el mismo nombre que el atributo

                        // Si el tipo del atributo es LocalDateTime, convierte desde Timestamp
                        if (valor instanceof Timestamp && campo.getType().equals(LocalDateTime.class)) {
                            campo.set(obj, ((Timestamp) valor).toLocalDateTime());

                            // Si el tipo del atributo es LocalDate, convierte desde Date
                        } else if (valor instanceof Date && campo.getType().equals(LocalDate.class)) {
                            campo.set(obj, ((Date) valor).toLocalDate());

                            // Para otros tipos, asigna directamente
                        } else {
                            campo.set(obj, valor);
                        }

                    } catch (SQLException e) {
                        // Si la columna no existe en el resultado, se ignora
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace(); // Manejo de errores de reflexion o SQL
        } finally {
            try {
                if (shouldClose && con != null) {
                    con.close(); // Cierra la conexion si fue creada internamente
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return obj; // Retorna el objeto mapeado o null si no se encontró
    }

    /**
     * Inserta un nuevo registro en la base de datos a partir de un objeto.
     * Utiliza reflexion para construir dinamicamente la consulta SQL y asignar
     * los valores.
     *
     * @param <T> Tipo de la entidad.
     * @param tabla Nombre de la tabla.
     * @param objeto Objeto que se desea insertar.
     * @return El mismo objeto con su ID generado (si aplica), o null si falla.
     */
    public <T> T create(String tabla, T objeto) {
        StringBuilder columnas = new StringBuilder(); // Almacena los nombres de las columnas
        StringBuilder valores = new StringBuilder();  // Almacena los placeholders (?, ?, ?)
        List<Object> parametros = new ArrayList<>();  // Almacena los valores a insertar

        Field[] campos = objeto.getClass().getDeclaredFields(); // Obtiene los atributos del objeto

        for (Field campo : campos) {
            campo.setAccessible(true); // Permite acceder a atributos privados

            if (campo.getName().equalsIgnoreCase("id")) {
                continue; // Ignora el campo ID (se asume autogenerado)
            }

            try {
                Object valor = campo.get(objeto); // Obtiene el valor del atributo

                if (valor != null) {
                    columnas.append(campo.getName()).append(", "); // Agrega el nombre de la columna
                    valores.append("?, ");                         // Agrega el placeholder
                    parametros.add(valor);                         // Agrega el valor a la lista
                }

            } catch (IllegalAccessException e) {
                e.printStackTrace(); // Manejo de errores de acceso a atributos
            }
        }

        if (parametros.isEmpty()) {
            return null; // Si no hay datos para insertar, retorna null
        }

        // Elimina la coma final de las listas
        columnas.setLength(columnas.length() - 2);
        valores.setLength(valores.length() - 2);

        // Construye la consulta SQL final
        String sql = MessageFormat.format("INSERT INTO {0} ({1}) VALUES ({2})", tabla, columnas, valores);

        Connection con = null;
        boolean shouldClose = (externalConnection == null);

        try {
            con = getConnection();
            PreparedStatement ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);

            // Asigna los valores a los placeholders (?, ?, ?)
            for (int i = 0; i < parametros.size(); i++) {
                Object param = parametros.get(i);

                if (param instanceof LocalDateTime) {
                    ps.setTimestamp(i + 1, Timestamp.valueOf((LocalDateTime) param));
                } else if (param instanceof LocalDate) {
                    ps.setDate(i + 1, Date.valueOf((LocalDate) param));
                } else {
                    ps.setObject(i + 1, param);
                }
            }

            int filasAfectadas = ps.executeUpdate(); // Ejecuta la insercion

            if (filasAfectadas > 0) {
                ResultSet keys = ps.getGeneratedKeys(); // Obtiene el ID generado

                if (keys.next()) {
                    int idGenerado = keys.getInt(1);

                    // Asigna el ID generado al atributo "id" del objeto
                    try {
                        Field idField = objeto.getClass().getDeclaredField("id");
                        idField.setAccessible(true);
                        idField.set(objeto, idGenerado);
                    } catch (NoSuchFieldException | IllegalAccessException e) {
                        e.printStackTrace();
                    }

                    return objeto; // Retorna el objeto con su ID asignado
                }
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de errores SQL
        } finally {
            try {
                if (shouldClose && con != null) {
                    con.close(); // Cierra la conexion si fue creada internamente
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return null; // Si algo falla, retorna null
    }

    /**
     * Actualiza un registro existente en la base de datos utilizando los
     * valores del objeto proporcionado. Utiliza reflexion para construir
     * dinamicamente la consulta SQL basada en los atributos del objeto.
     *
     * @param <T> Tipo de la entidad.
     * @param objeto Objeto con los nuevos valores (incluye el ID).
     * @param tabla Nombre de la tabla.
     * @param campoId Nombre del campo identificador (por ejemplo, "id").
     * @return true si la actualizacion fue exitosa (al menos una fila
     * afectada), false si no.
     * @throws SQLException si ocurre un error durante la operacion.
     */
    public <T> boolean update(T objeto, String tabla, String campoId) throws SQLException {
        Connection conexion = null;
        PreparedStatement ps = null;

        try {
            conexion = getConnection(); // Usa conexion externa o crea una nueva
            conexion.setAutoCommit(false); // Desactiva autocommit para controlar la transaccion manualmente

            Field[] campos = objeto.getClass().getDeclaredFields(); // Obtiene todos los atributos de la clase
            StringBuilder sql = new StringBuilder("UPDATE " + tabla + " SET "); // Comienza a construir la consulta SQL

            List<Object> valores = new ArrayList<>(); // Lista de valores para los placeholders
            Object valorId = null; // Almacena el valor del campo ID

            // Recorre cada atributo del objeto
            for (Field campo : campos) {
                campo.setAccessible(true); // Permite acceder a atributos privados

                try {
                    if (campo.getName().equalsIgnoreCase(campoId)) {
                        // Si es el campo ID, lo guardamos para usarlo en la clausula WHERE
                        valorId = campo.get(objeto);
                        continue; // No se incluye en el SET
                    }

                    // Agrega la asignacion del campo en la consulta SQL
                    sql.append(campo.getName()).append(" = ?, ");
                    Object valorCampo = campo.get(objeto);

                    // Convierte fechas si es necesario
                    if (valorCampo instanceof LocalDateTime) {
                        valores.add(Timestamp.valueOf((LocalDateTime) valorCampo));
                    } else if (valorCampo instanceof LocalDate) {
                        valores.add(Date.valueOf((LocalDate) valorCampo));
                    } else {
                        valores.add(valorCampo);
                    }

                } catch (IllegalAccessException e) {
                    throw new RuntimeException("No se pudo acceder al campo " + campo.getName(), e);
                }
            }

            sql.setLength(sql.length() - 2); // Elimina la coma final
            sql.append(" WHERE ").append(campoId).append(" = ?"); // Agrega la clausula WHERE con el campo ID

            ps = conexion.prepareStatement(sql.toString()); // Prepara la consulta SQL

            // Asigna los valores a los placeholders
            int index = 1;
            for (Object valor : valores) {
                ps.setObject(index++, valor);
            }
            ps.setObject(index, valorId); // Asigna el valor del ID al final

            int filasAfectadas = ps.executeUpdate(); // Ejecuta la actualizacion
            conexion.commit(); // Confirma la transaccion

            return filasAfectadas > 0;

        } catch (SQLException e) {
            if (conexion != null) {
                conexion.rollback(); // Revierte la transaccion en caso de error
            }
            throw new SQLException("Error al actualizar: " + e.getMessage(), e);

        } finally {
            if (ps != null) {
                ps.close();
            }
            if (conexion != null) {
                conexion.close();
            }
        }
    }

    /**
     * Elimina un registro de la base de datos segun su identificador.
     *
     * @param tabla Nombre de la tabla.
     * @param id Identificador del registro a eliminar.
     * @param campoId Nombre del campo que representa el ID (por ejemplo, "id").
     * @return true si la eliminacion fue exitosa (al menos una fila afectada),
     * false si no.
     * @throws SQLException si ocurre un error durante la operacion.
     */
    public boolean delete(Object id, String tabla, String campoId) throws SQLException {
        Connection conexion = null;
        PreparedStatement ps = null;

        try {
            conexion = getConnection(); // Usa conexion externa o crea una nueva
            conexion.setAutoCommit(false); // Desactiva autocommit para controlar la transaccion

            // Construye la consulta SQL para eliminar el registro
            String sql = "DELETE FROM " + tabla + " WHERE " + campoId + " = ?";
            ps = conexion.prepareStatement(sql);
            ps.setObject(1, id); // Asigna el valor del ID al placeholder

            int filasAfectadas = ps.executeUpdate(); // Ejecuta la eliminacion
            conexion.commit(); // Confirma la transaccion

            return filasAfectadas > 0;

        } catch (SQLException e) {
            if (conexion != null) {
                conexion.rollback(); // Revierte la transaccion en caso de error
            }
            throw new SQLException("Error al eliminar: " + e.getMessage(), e);

        } finally {
            if (ps != null) {
                ps.close();
            }
            if (conexion != null) {
                conexion.close();
            }
        }
    }

}
