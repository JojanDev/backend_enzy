package MODELO.DAO;

import MODELO.ConexionBD;
import MODELO.DTO.DetalleVentaDTO;
import MODELO.DTO.VentaPerfilDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase DAO para gestionar operaciones relacionadas con la entidad Venta.
 * Contiene dos metodos:
 * - actualizarMonto: suma un monto adicional al pago actual y ajusta el estado
 *   de la venta a 'completada' si el total se alcanza.
 * - obtenerVentaPerfil: recupera datos de la venta, cliente, empleado y lista
 *   de detalles de productos o servicios vendidos.
 */
public class VentaDAO {

    /**
     * Actualiza el monto pagado de una venta.
     * Suma montoNuevo al pago existente y, si el total se cumple o excede,
     * marca la venta como 'completada'; de lo contrario la deja en 'pendiente'.
     *
     * @param idVenta    id de la venta a actualizar
     * @param montoNuevo monto adicional a sumar al pago actual
     * @return true si la actualizacion afecto al menos una fila; false en otro caso
     */
    public boolean actualizarMonto(int idVenta, double montoNuevo) {
        Connection conn = null;
        PreparedStatement psSelect = null;
        PreparedStatement psUpdate = null;
        ResultSet rs = null;

        try {
            // Abrir conexion a la base de datos
            conn = ConexionBD.conectar();

            // Preparar consulta para leer monto actual y total
            String selectSql
                    = "SELECT monto, total FROM ventas WHERE id = ?";
            psSelect = conn.prepareStatement(selectSql);
            psSelect.setInt(1, idVenta);
            rs = psSelect.executeQuery();

            // Si no hay registro, salir con false
            if (!rs.next()) {
                return false;
            }

            // Leer valores actuales desde el ResultSet
            double montoActual = rs.getDouble("monto");
            double total = rs.getDouble("total");

            // Calcular el nuevo monto acumulado
            double nuevoMonto = montoActual + montoNuevo;

            // Definir el nuevo estado: completada si llega al total
            String nuevoEstado
                    = (nuevoMonto >= total) ? "completada" : "pendiente";

            // Preparar actualizacion de monto y estado
            String updateSql
                    = "UPDATE ventas SET monto = ?, estado = ? WHERE id = ?";
            psUpdate = conn.prepareStatement(updateSql);
            psUpdate.setDouble(1, nuevoMonto);
            psUpdate.setString(2, nuevoEstado);
            psUpdate.setInt(3, idVenta);

            // Ejecutar la actualizacion y devolver si afecto filas
            return psUpdate.executeUpdate() > 0;

        } catch (SQLException e) {
            // Mostrar traza en caso de error SQL
            e.printStackTrace();
            return false;

        } finally {
            // Cerrar recursos en orden inverso al de apertura
            try {
                if (rs != null) {
                    rs.close();
                }
                if (psSelect != null) {
                    psSelect.close();
                }
                if (psUpdate != null) {
                    psUpdate.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * Obtiene el perfil completo de una venta, incluyendo:
     * - Datos del cliente (id, nombre, documento)
     * - Datos del empleado responsable (id, nombre)
     * - Totales y estado de la venta
     * - Lista de detalles con producto/servicio, precio, cantidad, subtotal y categoria
     *
     * @param idVenta id de la venta a consultar
     * @return un objeto VentaPerfilDTO con toda la informacion, o null si no existe
     * @throws SQLException si ocurre un error durante la consulta
     */
    public VentaPerfilDTO obtenerVentaPerfil(int idVenta) throws SQLException {
        VentaPerfilDTO ventaPerfil = null;

        // SQL para la cabecera de la venta
        String sqlCabecera
                = "SELECT "
                + "c.id AS id_cliente, "
                + "icp.nombre AS nombre_cliente, "
                + "icp.numero_documento AS documento_cliente, "
                + "p.id AS id_empleado, "
                + "icp_emp.nombre AS nombre_empleado, "
                + "v.id AS id_venta, "
                + "v.total, "
                + "v.fecha_creado, "
                + "v.monto, "
                + "v.estado "
                + "FROM ventas v "
                + "INNER JOIN clientes c ON v.id_cliente = c.id "
                + "INNER JOIN informacion_clientes_personal icp ON c.id_info = icp.id "
                + "INNER JOIN personal p ON v.id_personal = p.id "
                + "INNER JOIN informacion_clientes_personal icp_emp ON p.id_info = icp_emp.id "
                + "WHERE v.id = ?";

        // Ejecutar consulta de cabecera
        try (Connection conn = ConexionBD.conectar(); PreparedStatement stmt = conn.prepareStatement(sqlCabecera)) {
            stmt.setInt(1, idVenta);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    ventaPerfil = new VentaPerfilDTO();
                    ventaPerfil.setIdCliente(rs.getInt("id_cliente"));
                    ventaPerfil.setNombreCliente(rs.getString("nombre_cliente"));
                    ventaPerfil.setDocumentoCliente(rs.getString("documento_cliente"));
                    ventaPerfil.setIdEmpleado(rs.getInt("id_empleado"));
                    ventaPerfil.setNombreEmpleado(rs.getString("nombre_empleado"));
                    ventaPerfil.setIdVenta(rs.getInt("id_venta"));
                    ventaPerfil.setTotal(rs.getDouble("total"));
                    ventaPerfil.setMonto(rs.getDouble("monto"));
                    ventaPerfil.setEstado(rs.getString("estado"));

                    // Convertir fecha a texto
                    Timestamp ts = rs.getTimestamp("fecha_creado");
                    if (ts != null) {
                        ventaPerfil.setFechaCreado(
                                ts.toLocalDateTime().toString()
                        );
                    }
                }
            }
        }

        // Si no existe la venta, retornar null
        if (ventaPerfil == null) {
            return null;
        }

        // SQL para los detalles de la venta
        String sqlDetalles
                = "SELECT "
                + "dv.id AS id_detalle_venta, "
                + "COALESCE(prod.nombre, serv.nombre, mi.nombre) AS producto, "
                + "dv.precio, "
                + "dv.cantidad, "
                + "dv.subtotal, "
                + "dv.valor_adicional, "
                + "CASE "
                + "  WHEN serv.id IS NOT NULL THEN 'Servicio' "
                + "  WHEN med.id IS NOT NULL  THEN 'Medicamento' "
                + "  WHEN prod.id IS NOT NULL THEN tp.nombre "
                + "  ELSE 'Otro' "
                + "END AS categoria "
                + "FROM detalles_ventas dv "
                + "LEFT JOIN productos prod ON dv.id_producto = prod.id "
                + "LEFT JOIN tipos_productos tp ON prod.id_tipo = tp.id "
                + "LEFT JOIN servicios serv ON dv.id_servicio = serv.id "
                + "LEFT JOIN medicamentos med ON dv.id_medicamento = med.id "
                + "LEFT JOIN medicamentos_info mi ON med.id_medicamento_info = mi.id "
                + "WHERE dv.id_venta = ?";

        // Lista para almacenar los detalles
        List<DetalleVentaDTO> listaDetalles = new ArrayList<>();

        // Ejecutar consulta de detalles
        try (Connection conn = ConexionBD.conectar(); PreparedStatement stmt = conn.prepareStatement(sqlDetalles)) {
            stmt.setInt(1, idVenta);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    DetalleVentaDTO detalle = new DetalleVentaDTO();
                    detalle.setIdDetalleVenta(rs.getInt("id_detalle_venta"));
                    detalle.setProducto(rs.getString("producto"));
                    detalle.setPrecio(rs.getDouble("precio"));
                    detalle.setCantidad(rs.getInt("cantidad"));
                    detalle.setSubtotal(rs.getDouble("subtotal"));
                    detalle.setValorAdicional(rs.getDouble("valor_adicional"));
                    detalle.setCategoria(rs.getString("categoria"));
                    listaDetalles.add(detalle);
                }
            }
        }

        // Asignar detalles al DTO y devolver resultado
        ventaPerfil.setDetalles(listaDetalles);
        return ventaPerfil;
    }
}
