package MODELO;

/**
 * Modelo que representa un tipo de documento utilizado para clasificar
 * documentos de clientes y empleados.
 *
 * Campos:
 * - id: identificador unico del tipo de documento
 * - nombre: descripcion del tipo de documento
 */
public class TipoDocumento {

    /**
     * identificador unico del tipo de documento
     */
    private int id;

    /**
     * descripcion del tipo de documento (ej. "CC", "Pasaporte")
     */
    private String nombre;

    /**
     * Constructor sin argumentos para uso de frameworks y mapeo.
     */
    public TipoDocumento() {
    }

    /**
     * Obtiene el identificador unico del tipo de documento.
     *
     * @return id del tipo de documento
     */
    public int getId() {
        return id;
    }

    /**
     * Asigna el identificador unico del tipo de documento.
     *
     * @param id nuevo valor de id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene la descripcion del tipo de documento.
     *
     * @return nombre del tipo de documento
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Asigna la descripcion del tipo de documento.
     *
     * @param nombre nueva descripcion a establecer
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
