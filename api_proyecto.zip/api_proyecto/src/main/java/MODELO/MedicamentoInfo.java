/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

/**
 *
 * @author USUARIO
 */
public class MedicamentoInfo {
    private int id;
    private String nombre;
    private String uso_general;
    private String especie_destinada;
    private String via_administracion;
    private String presentacion;
    private String informacion_adicional;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUso_general() {
        return uso_general;
    }

    public void setUso_general(String uso_general) {
        this.uso_general = uso_general;
    }

    public String getEspecie_destinada() {
        return especie_destinada;
    }

    public void setEspecie_destinada(String especie_destinada) {
        this.especie_destinada = especie_destinada;
    }

    public String getVia_administracion() {
        return via_administracion;
    }

    public void setVia_administracion(String via_administracion) {
        this.via_administracion = via_administracion;
    }

    public String getPresentacion() {
        return presentacion;
    }

    public void setPresentacion(String presentacion) {
        this.presentacion = presentacion;
    }

    public String getInformacion_adicional() {
        return informacion_adicional;
    }

    public void setInformacion_adicional(String informacion_adicional) {
        this.informacion_adicional = informacion_adicional;
    }
    
    
}
