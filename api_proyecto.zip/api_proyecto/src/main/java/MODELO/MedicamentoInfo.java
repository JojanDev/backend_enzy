package MODELO;

/**
 * Representa la informacion basica de un medicamento en el sistema.
 *
 * Campos:
 *   id                   : identificador unico del medicamento
 *   nombre               : nombre comercial o generico
 *   uso_general          : indicaciones generales de uso
 *   via_administracion   : via sugerida para administracion
 *   presentacion         : forma de presentacion (tabletas, jarabe, etc.)
 *   informacion_adicional: datos complementarios o advertencias
 */
public class MedicamentoInfo {

    /** identificador unico del medicamento (clave primaria) */
    private int id;

    /** nombre comercial o generico del medicamento */
    private String nombre;

    /** indicaciones generales de uso del medicamento */
    private String uso_general;

    /** via por la cual se administra el medicamento (oral, topica, etc.) */
    private String via_administracion;

    /** forma de presentacion del medicamento */
    private String presentacion;

    /** informacion adicional o advertencias sobre el medicamento */
    private String informacion_adicional;

    /**
     * Obtiene el identificador unico del medicamento.
     *
     * @return identificador unico
     */
    public int getId() {
        // devuelve el valor del campo 'id'
        return id;
    }

    /**
     * Establece el identificador unico del medicamento.
     *
     * @param id identificador unico a asignar
     */
    public void setId(int id) {
        // asigna el valor recibido al campo 'id'
        this.id = id;
    }

    /**
     * Obtiene el nombre comercial o generico del medicamento.
     *
     * @return nombre del medicamento
     */
    public String getNombre() {
        // devuelve el valor del campo 'nombre'
        return nombre;
    }

    /**
     * Establece el nombre comercial o generico del medicamento.
     *
     * @param nombre nombre a asignar
     */
    public void setNombre(String nombre) {
        // asigna el valor recibido al campo 'nombre'
        this.nombre = nombre;
    }

    /**
     * Obtiene las indicaciones generales de uso.
     *
     * @return uso general del medicamento
     */
    public String getUso_general() {
        // devuelve el valor del campo 'uso_general'
        return uso_general;
    }

    /**
     * Establece las indicaciones generales de uso.
     *
     * @param uso_general indicaciones generales a asignar
     */
    public void setUso_general(String uso_general) {
        // asigna el valor recibido al campo 'uso_general'
        this.uso_general = uso_general;
    }

    /**
     * Obtiene la via de administracion sugerida.
     *
     * @return via de administracion
     */
    public String getVia_administracion() {
        // devuelve el valor del campo 'via_administracion'
        return via_administracion;
    }

    /**
     * Establece la via de administracion del medicamento.
     *
     * @param via_administracion via a asignar
     */
    public void setVia_administracion(String via_administracion) {
        // asigna el valor recibido al campo 'via_administracion'
        this.via_administracion = via_administracion;
    }

    /**
     * Obtiene la forma de presentacion del medicamento.
     *
     * @return presentacion del medicamento
     */
    public String getPresentacion() {
        // devuelve el valor del campo 'presentacion'
        return presentacion;
    }

    /**
     * Establece la forma de presentacion del medicamento.
     *
     * @param presentacion presentacion a asignar
     */
    public void setPresentacion(String presentacion) {
        // asigna el valor recibido al campo 'presentacion'
        this.presentacion = presentacion;
    }

    /**
     * Obtiene informacion adicional o advertencias.
     *
     * @return informacion adicional del medicamento
     */
    public String getInformacion_adicional() {
        // devuelve el valor del campo 'informacion_adicional'
        return informacion_adicional;
    }

    /**
     * Establece informacion adicional o advertencias.
     *
     * @param informacion_adicional informacion a asignar
     */
    public void setInformacion_adicional(String informacion_adicional) {
        // asigna el valor recibido al campo 'informacion_adicional'
        this.informacion_adicional = informacion_adicional;
    }
}
