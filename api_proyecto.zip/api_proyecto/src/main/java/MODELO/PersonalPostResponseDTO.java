/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

public class PersonalPostResponseDTO {
    private int id;
    private int idInfo;
    private String usuario;
    private String nombre;
    private String correo;

    public PersonalPostResponseDTO() {}

    public PersonalPostResponseDTO(int id, int idInfo, String usuario, String nombre, String correo) {
        this.id = id;
        this.idInfo = idInfo;
        this.usuario = usuario;
        this.nombre = nombre;
        this.correo = correo;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdInfo() { return idInfo; }
    public void setIdInfo(int idInfo) { this.idInfo = idInfo; }

    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }
}

