package MODELO;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Modelo que representa una venta realizada en el sistema.
 *
 * Campos:
 * - id: identificador único de la venta
 * - id_cliente: clave foránea al cliente que efectuó la compra
 * - id_personal: clave foránea al empleado responsable de la venta
 * - fecha_creado: fecha y hora en que se registró la venta
 * - total: importe total que debe pagarse
 * - monto: importe efectivamente pagado
 * - estado: estado de la venta (por ejemplo, completada o pendiente)
 */
public class Venta {

    /**
     * identificador único de la venta
     */
    private int id;

    /**
     * identificador del cliente que realiza la compra
     */
    private int id_cliente;

    /**
     * identificador del empleado que procesa la venta
     */
    private int id_personal;

    /**
     * fecha y hora en que se registró la venta
     */
    private LocalDateTime fecha_creado;

    /**
     * importe total que debe pagarse
     */
    private BigDecimal total;

    /**
     * importe efectivamente pagado
     */
    private BigDecimal monto;

    /**
     * estado de la venta (completada, pendiente, etc.)
     */
    private String estado;

    /**
     * Obtiene el identificador único de la venta.
     *
     * @return id de la venta
     */
    public int getId() {
        return id;
    }

    /**
     * Asigna el identificador único de la venta.
     *
     * @param id nuevo identificador de la venta
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene el identificador del cliente asociado.
     *
     * @return id_cliente de la venta
     */
    public int getId_cliente() {
        return id_cliente;
    }

    /**
     * Asigna el identificador del cliente asociado.
     *
     * @param id_cliente nuevo identificador de cliente
     */
    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    /**
     * Obtiene el identificador del personal que procesó la venta.
     *
     * @return id_personal de la venta
     */
    public int getId_personal() {
        return id_personal;
    }

    /**
     * Asigna el identificador del personal que procesó la venta.
     *
     * @param id_personal nuevo identificador de personal
     */
    public void setId_personal(int id_personal) {
        this.id_personal = id_personal;
    }

    /**
     * Obtiene la fecha y hora en que se registró la venta.
     *
     * @return fecha_creado de la venta
     */
    public LocalDateTime getFecha_creado() {
        return fecha_creado;
    }

    /**
     * Asigna la fecha y hora en que se registró la venta.
     *
     * @param fecha_creado nueva fecha y hora de creación
     */
    public void setFecha_creado(LocalDateTime fecha_creado) {
        this.fecha_creado = fecha_creado;
    }

    /**
     * Obtiene el importe total que debe pagarse.
     *
     * @return total de la venta
     */
    public BigDecimal getTotal() {
        return total;
    }

    /**
     * Asigna el importe total que debe pagarse.
     *
     * @param total nuevo valor total de la venta
     */
    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    /**
     * Obtiene el importe efectivamente pagado.
     *
     * @return monto pagado en la venta
     */
    public BigDecimal getMonto() {
        return monto;
    }

    /**
     * Asigna el importe efectivamente pagado.
     *
     * @param monto nuevo monto pagado
     */
    public void setMonto(BigDecimal monto) {
        this.monto = monto;
    }

    /**
     * Obtiene el estado de la venta.
     *
     * @return estado de la venta
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Asigna el estado de la venta.
     *
     * @param estado nuevo estado (completada, pendiente, etc.)
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }
}
