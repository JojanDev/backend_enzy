package MODELO;
// Paquete donde está ubicada esta clase utilitaria para conexión a la base de datos.

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
// Importación de clases necesarias para manejar conexiones a bases de datos con JDBC.

/**
 * Clase utilitaria que permite conectar a la base de datos MySQL.
 */
public class ConexionBD {
    
    

    // URL de conexión a la base de datos.
    // Contiene: el tipo de protocolo (jdbc:mysql), el host (localhost), 
    // el puerto (3306) y el nombre de la base de datos (veterinaria_pipos).
    private static final String URL = "jdbc:mysql://localhost:3306/veterinaria_pipos";

    // Nombre de usuario de la base de datos MySQL (por defecto 'root').
    private static final String USUARIO = "root";

    // Contraseña del usuario para acceder a la base de datos.  
    private static final String CLAVE = "root"; // Puedes cambiarla por seguridad.
    
    
//     // Nombre de usuario de la base de datos MySQL (por defecto 'root').
//    private static final String USUARIO = "johan_delgado";
//
//    // Contraseña del usuario para acceder a la base de datos.  
//    private static final String CLAVE = "123456"; // Puedes cambiarla por seguridad.
    
    /**
     * Método estático para establecer y retornar una conexión a la base de datos.
     * @return Objeto Connection que representa la conexión activa.
     * @throws SQLException si ocurre un error al intentar conectarse.
     */
    public static Connection conectar() throws SQLException {
        // Retorna la conexión utilizando los datos definidos anteriormente.

        Connection con = DriverManager.getConnection(URL, USUARIO, CLAVE);
        
        System.out.println("============================================");
        System.out.println("-> Conexion establecida correctamente.");
        System.out.println("============================================");
        
        return con;
    }
}
