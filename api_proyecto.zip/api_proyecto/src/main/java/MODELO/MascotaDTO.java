/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

/**
 *
 * @author Propietario
 */
public class MascotaDTO {
    private int id;
    private ClienteInfoDTO dueno;
    private String nombre;
    private RazaDTO raza;
    private int edad;
    private String sexo;
    private String estado_vital;

    // Getter y Setter para id
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // Getter y Setter para id_cliente
    public ClienteInfoDTO getDueno() {
        return dueno;
    }

    public void setDueno(ClienteInfoDTO dueno) {
        this.dueno = dueno;
    }

    // Getter y Setter para nombre
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Getter y Setter para id_raza
    public RazaDTO getRaza() {
        return raza;
    }

    public void setRaza(RazaDTO raza) {
        this.raza = raza;
    }

    // Getter y Setter para edad
    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    // Getter y Setter para sexo
    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    // Getter y Setter para estado_vital
    public String getEstado_vital() {
        return estado_vital;
    }

    public void setEstado_vital(String estado_vital) {
        this.estado_vital = estado_vital;
    }
}
