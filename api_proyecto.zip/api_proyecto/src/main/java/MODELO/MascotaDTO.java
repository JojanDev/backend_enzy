/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

/**
 *
 * @author Propietario
 */
public class MascotaDTO {
    private int id; //ID de la mascota
    private Cliente dueño; //Informacion del dueño
    private String nombre; //Nombre de la mascota
    private Raza raza;
}
