/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

import java.lang.reflect.Field;
import java.sql.*;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase genérica para operaciones CRUD utilizando reflexión y JDBC.
 * Permite manejar entidades genéricas que tengan sus atributos mapeados
 * a columnas de base de datos. Soporta manejo de conexiones externas para
 * transacciones personalizadas.
 */
public class CrudDAO {
    /** Conexión externa proporcionada desde el exterior, útil para manejar transacciones manuales */
    private Connection externalConnection;

    /**
     * Constructor por defecto. No usa conexión externa.
     * Las operaciones abrirán y cerrarán su propia conexión.
     */
    public CrudDAO() {
    }

    /**
     * Constructor que permite utilizar una conexión externa.
     * Útil cuando se desea manejar manualmente las transacciones (commit/rollback)
     * desde un flujo externo al DAO, como en servicios REST con múltiples operaciones
     * dentro de una misma transacción.
     *
     * @param connection Conexión JDBC abierta y gestionada externamente.
     */
    public CrudDAO(Connection connection) {
        this.externalConnection = connection;
    }

    /**
     * Obtiene la conexión activa. Usa una conexión externa si fue proporcionada,
     * de lo contrario crea una nueva conexión interna.
     *
     * @return Conexión JDBC activa
     * @throws SQLException si ocurre un error al obtener la conexión
     */
    private Connection getConnection() throws SQLException {
        return (externalConnection != null) ? externalConnection : ConexionBD.conectar();
    }

    /**
     * Recupera todos los registros de una tabla mapeados al tipo especificado.
     *
     * @param <T> Tipo de la entidad
     * @param clazz Clase de la entidad
     * @param tabla Nombre de la tabla
     * @return Lista de objetos del tipo dado
     */
    public <T> List<T> getAll(Class<T> clazz, String tabla) {
        List<T> lista = new ArrayList<>();
        String sql = "SELECT * FROM " + tabla + " ORDER BY id DESC";

        Connection con = null;
        boolean shouldClose = (externalConnection == null);

        try {
            con = getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            Field[] campos = clazz.getDeclaredFields();

            while (rs.next()) {
                T obj = clazz.getDeclaredConstructor().newInstance();

                for (Field campo : campos) {
                    campo.setAccessible(true);
                    try {
                        Object valor = rs.getObject(campo.getName());
                        if (valor instanceof Timestamp && campo.getType().equals(LocalDateTime.class)) {
                            campo.set(obj, ((Timestamp) valor).toLocalDateTime());
                        } else if (valor instanceof Date && campo.getType().equals(LocalDate.class)) {
                            campo.set(obj, ((Date) valor).toLocalDate());
                        }
                        else {
                            campo.set(obj, valor);
                        }
                    } catch (SQLException e) {
                        // Columna no existe, ignorar
                    }
                }
                lista.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (shouldClose && con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }
    
    /**
     * Recupera una lista de registros filtrados por un campo específico.
     *
     * @param <T> Tipo de la entidad
     * @param clazz Clase de la entidad
     * @param tableName Nombre de la tabla
     * @param fieldName Nombre del campo por el cual se filtrará
     * @param fieldValue Valor del campo a buscar
     * @return Lista de entidades encontradas
     */
    public <T> List<T> getAllByField(Class<T> clazz, String tabla, String campoBusqueda, Object valorBusqueda) {
        List<T> lista = new ArrayList<>();
        String sql = "SELECT * FROM " + tabla + " WHERE " + campoBusqueda + " = ? ORDER BY id DESC";

        Connection con = null;
        boolean shouldClose = (externalConnection == null);

        try {
            con = getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setObject(1, valorBusqueda);
            ResultSet rs = ps.executeQuery();

            Field[] campos = clazz.getDeclaredFields();

            while (rs.next()) {
                T obj = clazz.getDeclaredConstructor().newInstance();

                for (Field campo : campos) {
                    campo.setAccessible(true);
                    try {
                        Object valor = rs.getObject(campo.getName());
                        if (valor instanceof Timestamp && campo.getType().equals(LocalDateTime.class)) {
                            campo.set(obj, ((Timestamp) valor).toLocalDateTime());
                        } else if (valor instanceof Date && campo.getType().equals(LocalDate.class)) {
                            campo.set(obj, ((Date) valor).toLocalDate());
                        }
                        else {
                            campo.set(obj, valor);
                        }
                    } catch (SQLException e) {
                        // Columna no existe, ignorar
                    }
                }

                lista.add(obj);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (shouldClose && con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return lista;
    }


    /**
     * Recupera un registro por su ID.
     *
     * @param <T> Tipo de la entidad
     * @param clazz Clase de la entidad
     * @param tableName Nombre de la tabla
     * @param id Identificador del registro
     * @return Objeto recuperado o null si no se encuentra
     */
    public <T> T getById(Class<T> clazz, String tabla, int id) {
        String sql = "SELECT * FROM " + tabla + " WHERE id = ?";
        T obj = null;

        Connection con = null;
        boolean shouldClose = (externalConnection == null);

        try {
            con = getConnection();  
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            Field[] campos = clazz.getDeclaredFields();

            if (rs.next()) {
                obj = clazz.getDeclaredConstructor().newInstance();

                for (Field campo : campos) {
                    campo.setAccessible(true);
                    try {
                        Object valor = rs.getObject(campo.getName());
                        if (valor instanceof Timestamp && campo.getType().equals(LocalDateTime.class)) {
                            campo.set(obj, ((Timestamp) valor).toLocalDateTime());
                        } else if (valor instanceof Date && campo.getType().equals(LocalDate.class)) {
                            campo.set(obj, ((Date) valor).toLocalDate());
                        }
                        else {
                            campo.set(obj, valor);
                        }
                    } catch (SQLException e) {
                        // Columna no existe, ignorar   
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (shouldClose && con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return obj;
    }

    /**
     * Crea un nuevo registro en la base de datos a partir de un objeto de entidad.
     *
     * @param <T> Tipo de la entidad
     * @param clazz Clase de la entidad
     * @param tableName Nombre de la tabla en la base de datos
     * @param entity Objeto de la entidad a insertar
     * @return El objeto insertado con su ID generado (si aplica), o null si falla
     */
    public <T> T create(String tabla, T objeto)  {
        StringBuilder columnas = new StringBuilder();
        StringBuilder valores = new StringBuilder();
        List<Object> parametros = new ArrayList<>();

        Field[] campos = objeto.getClass().getDeclaredFields();

        for (Field campo : campos) {
            campo.setAccessible(true);
            if (campo.getName().equalsIgnoreCase("id")) continue;

            try {
                Object valor = campo.get(objeto);
                if (valor != null) {
                    columnas.append(campo.getName()).append(", ");
                    valores.append("?, ");
                    parametros.add(valor);
                }
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }

        if (parametros.isEmpty()) {
            return null;
        }

        columnas.setLength(columnas.length() - 2);
        valores.setLength(valores.length() - 2);

        String sql = MessageFormat.format("INSERT INTO {0} ({1}) VALUES ({2})", tabla, columnas, valores);

        Connection con = null;
        boolean shouldClose = (externalConnection == null);

        try {
            con = getConnection();
            PreparedStatement ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);

            for (int i = 0; i < parametros.size(); i++) {
                Object param = parametros.get(i);

                if (param instanceof LocalDateTime) {
                    ps.setTimestamp(i + 1, Timestamp.valueOf((LocalDateTime) param));
                } else if (param instanceof LocalDate) {
                    ps.setDate(i + 1, Date.valueOf((LocalDate) param));
                } else {
                    ps.setObject(i + 1, param);
                }
            }


            int filasAfectadas = ps.executeUpdate();

            if (filasAfectadas > 0) {
                ResultSet keys = ps.getGeneratedKeys();
                if (keys.next()) {
                    int idGenerado = keys.getInt(1);

                    try {
                        Field idField = objeto.getClass().getDeclaredField("id");
                        idField.setAccessible(true);
                        idField.set(objeto, idGenerado);
                    } catch (NoSuchFieldException | IllegalAccessException e) {
                        e.printStackTrace();
                    }

                    return objeto;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (shouldClose && con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return null;
    }
    
    /**
    * Actualiza un registro existente en la base de datos.
    *
    * @param <T> Tipo de la entidad
    * @param objeto Objeto con los nuevos valores (incluye el ID)
    * @param tabla Nombre de la tabla
    * @param campoId Nombre del campo identificador (como "id")
    * @return true si la actualización fue exitosa (al menos una fila afectada), false si no
    * @throws SQLException si ocurre un error durante la operación
    */
   public <T> boolean update(T objeto, String tabla, String campoId) throws SQLException {
       Connection conexion = null;
       PreparedStatement ps = null;

       try {
           conexion = getConnection();
           conexion.setAutoCommit(false);

           Field[] campos = objeto.getClass().getDeclaredFields();
           StringBuilder sql = new StringBuilder("UPDATE " + tabla + " SET ");

           List<Object> valores = new ArrayList<>();
           Object valorId = null;

           for (Field campo : campos) {
               campo.setAccessible(true);
               try {
                   if (campo.getName().equalsIgnoreCase(campoId)) {
                       valorId = campo.get(objeto);
                       continue;
                   }

                   sql.append(campo.getName()).append(" = ?, ");
                   Object valorCampo = campo.get(objeto);

                   if (valorCampo instanceof LocalDateTime) {
                       valores.add(Timestamp.valueOf((LocalDateTime) valorCampo));
                   } else if (valorCampo instanceof LocalDate) {
                       valores.add(Date.valueOf((LocalDate) valorCampo));
                   } else {
                       valores.add(valorCampo);
                   }
               } catch (IllegalAccessException e) {
                   throw new RuntimeException("No se pudo acceder al campo " + campo.getName(), e);
               }
           }

           sql.setLength(sql.length() - 2); // eliminar la última coma
           sql.append(" WHERE ").append(campoId).append(" = ?");

           ps = conexion.prepareStatement(sql.toString());

           int index = 1;
           for (Object valor : valores) {
               ps.setObject(index++, valor);
           }
           ps.setObject(index, valorId);

           int filasAfectadas = ps.executeUpdate();
           conexion.commit();

           return filasAfectadas > 0;
       } catch (SQLException e) {
           if (conexion != null) {
               conexion.rollback();
           }
           throw new SQLException("Error al actualizar: " + e.getMessage(), e);
       } finally {
           if (ps != null) ps.close();
           if (conexion != null) conexion.close();
       }
   }


    
    /**
    * Elimina un registro por su ID.
    *
    * @param tabla Nombre de la tabla
    * @param id Identificador del registro a eliminar
    * @param campoId Nombre del campo del identificador
    * @return true si la eliminación fue exitosa (al menos una fila afectada), false si no
    * @throws SQLException si ocurre un error durante la operación
    */
   public boolean delete(Object id, String tabla, String campoId) throws SQLException {
       Connection conexion = null;
       PreparedStatement ps = null;

       try {
           conexion = getConnection();
           conexion.setAutoCommit(false);

           String sql = "DELETE FROM " + tabla + " WHERE " + campoId + " = ?";
           ps = conexion.prepareStatement(sql);
           ps.setObject(1, id);

           int filasAfectadas = ps.executeUpdate();
           conexion.commit();

           return filasAfectadas > 0;
       } catch (SQLException e) {
           if (conexion != null) {
               conexion.rollback();
           }
           throw new SQLException("Error al eliminar: " + e.getMessage(), e);
       } finally {
           if (ps != null) ps.close();
           if (conexion != null) conexion.close();
       }
   }

}
