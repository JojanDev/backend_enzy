/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

import java.lang.reflect.Field;
import java.sql.*;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase gen�rica para operaciones CRUD utilizando reflexi�n y JDBC. Permite
 * manejar entidades gen�ricas que tengan sus atributos mapeados a columnas de
 * base de datos. Soporta manejo de conexiones externas para transacciones
 * personalizadas.
 */
public class CrudDAO {

    /**
     * Conexi�n externa proporcionada desde el exterior, �til para manejar
     * transacciones manuales
     */
    private Connection externalConnection;

    /**
     * Constructor por defecto. No usa conexi�n externa. Las operaciones abrir�n
     * y cerrar�n su propia conexi�n.
     */
    public CrudDAO() {
    }

    /**
     * Constructor que permite utilizar una conexi�n externa. �til cuando se
     * desea manejar manualmente las transacciones (commit/rollback) desde un
     * flujo externo al DAO, como en servicios REST con m�ltiples operaciones
     * dentro de una misma transacci�n.
     *
     * @param connection Conexi�n JDBC abierta y gestionada externamente.
     */
    public CrudDAO(Connection connection) {
        this.externalConnection = connection;
    }

    /**
     * Obtiene la conexi�n activa. Usa una conexi�n externa si fue
     * proporcionada, de lo contrario crea una nueva conexi�n interna.
     *
     * @return Conexi�n JDBC activa
     * @throws SQLException si ocurre un error al obtener la conexi�n
     */
    private Connection getConnection() throws SQLException {
        // Retorna la conexi�n externa si est� disponible, de lo contrario, crea una nueva conexi�n
        return (externalConnection != null) ? externalConnection : ConexionBD.conectar();
    }

    /**
     * Recupera todos los registros de una tabla mapeados al tipo especificado.
     *
     * @param <T> Tipo de la entidad
     * @param clazz Clase de la entidad
     * @param tabla Nombre de la tabla
     * @return Lista de objetos del tipo dado
     */
    public <T> List<T> getAll(Class<T> clazz, String tabla) {
        List<T> lista = new ArrayList<>(); // Lista para almacenar los objetos recuperados
        String sql = "SELECT * FROM " + tabla + " ORDER BY id DESC"; // Consulta SQL

        Connection con = null; // Conexi�n a la base de datos
        boolean shouldClose = (externalConnection == null); // Determina si se debe cerrar la conexi�n

        try {
            con = getConnection(); // Obtiene la conexi�n activa
            PreparedStatement ps = con.prepareStatement(sql); // Prepara la consulta
            ResultSet rs = ps.executeQuery(); // Ejecuta la consulta y obtiene los resultados

            Field[] campos = clazz.getDeclaredFields(); // Obtiene los campos de la clase

            // Itera sobre los resultados
            while (rs.next()) {
                T obj = clazz.getDeclaredConstructor().newInstance(); // Crea una nueva instancia de la clase

                // Itera sobre los campos de la clase
                for (Field campo : campos) {
                    campo.setAccessible(true); // Permite el acceso a campos privados
                    try {
                        Object valor = rs.getObject(campo.getName()); // Obtiene el valor del resultado
                        // Maneja conversiones de tipos de fecha
                        if (valor instanceof Timestamp && campo.getType().equals(LocalDateTime.class)) {
                            campo.set(obj, ((Timestamp) valor).toLocalDateTime());
                        } else if (valor instanceof Date && campo.getType().equals(LocalDate.class)) {
                            campo.set(obj, ((Date) valor).toLocalDate());
                        } else {
                            campo.set(obj, valor); // Asigna el valor al campo
                        }
                    } catch (SQLException e) {
                        // Columna no existe, ignorar
                    }
                }
                lista.add(obj); // Agrega el objeto a la lista
            }
        } catch (Exception e) {
            e.printStackTrace(); // Manejo de excepciones
        } finally {
            try {
                if (shouldClose && con != null) {
                    con.close(); // Cierra la conexi�n si es necesario
                }
            } catch (SQLException e) {
                e.printStackTrace(); // Manejo de excepciones
            }
        }
        return lista; // Retorna la lista de objetos
    }

    /**
     * Recupera una lista de registros filtrados por un campo espec�fico.
     *
     * @param <T> Tipo de la entidad
     * @param clazz Clase de la entidad
     * @param tableName Nombre de la tabla
     * @param fieldName Nombre del campo por el cual se filtrar�
     * @param fieldValue Valor del campo a buscar
     * @return Lista de entidades encontradas
     */
    public <T> List<T> getAllByField(Class<T> clazz, String tabla, String campoBusqueda, Object valorBusqueda) {
        List<T> lista = new ArrayList<>(); // Lista para almacenar los objetos recuperados
        String sql = "SELECT * FROM " + tabla + " WHERE " + campoBusqueda + " = ? ORDER BY id DESC"; // Consulta SQL

        Connection con = null; // Conexi�n a la base de datos
        boolean shouldClose = (externalConnection == null); // Determina si se debe cerrar la conexi�n

        try {
            con = getConnection(); // Obtiene la conexi�n activa
            PreparedStatement ps = con.prepareStatement(sql); // Prepara la consulta
            ps.setObject(1, valorBusqueda); // Establece el valor del par�metro
            ResultSet rs = ps.executeQuery(); // Ejecuta la consulta y obtiene los resultados

            Field[] campos = clazz.getDeclaredFields(); // Obtiene los campos de la clase

            // Itera sobre los resultados
            while (rs.next()) {
                T obj = clazz.getDeclaredConstructor().newInstance(); // Crea una nueva instancia de la clase

                // Itera sobre los campos de la clase
                for (Field campo : campos) {
                    campo.setAccessible(true); // Permite el acceso a campos privados
                    try {
                        Object valor = rs.getObject(campo.getName()); // Obtiene el valor del resultado
                        // Maneja conversiones de tipos de fecha
                        if (valor instanceof Timestamp && campo.getType().equals(LocalDateTime.class)) {
                            campo.set(obj, ((Timestamp) valor).toLocalDateTime());
                        } else if (valor instanceof Date && campo.getType().equals(LocalDate.class)) {
                            campo.set(obj, ((Date) valor).toLocalDate());
                        } else {
                            campo.set(obj, valor); // Asigna el valor al campo
                        }
                    } catch (SQLException e) {
                        // Columna no existe, ignorar
                    }
                }

                lista.add(obj); // Agrega el objeto a la lista
            }

        } catch (Exception e) {
            e.printStackTrace(); // Manejo de excepciones
        } finally {
            try {
                if (shouldClose && con != null) {
                    con.close(); // Cierra la conexi�n si es necesario
                }
            } catch (SQLException e) {
                e.printStackTrace(); // Manejo de excepciones
            }
        }

        return lista; // Retorna la lista de objetos
    }

    /**
     * Recupera un registro por su ID.
     *
     * @param <T> Tipo de la entidad
     * @param clazz Clase de la entidad
     * @param tableName Nombre de la tabla
     * @param id Identificador del registro
     * @return Objeto recuperado o null si no se encuentra
     */
    public <T> T getById(Class<T> clazz, String tabla, int id) {
        String sql = "SELECT * FROM " + tabla + " WHERE id = ?"; // Consulta SQL
        T obj = null; // Objeto a retornar

        Connection con = null; // Conexi�n a la base de datos
        boolean shouldClose = (externalConnection == null); // Determina si se debe cerrar la conexi�n

        try {
            con = getConnection(); // Obtiene la conexi�n activa  
            PreparedStatement ps = con.prepareStatement(sql); // Prepara la consulta
            ps.setInt(1, id); // Establece el valor del par�metro
            ResultSet rs = ps.executeQuery(); // Ejecuta la consulta y obtiene los resultados

            Field[] campos = clazz.getDeclaredFields(); // Obtiene los campos de la clase

            if (rs.next()) { // Si hay resultados
                obj = clazz.getDeclaredConstructor().newInstance(); // Crea una nueva instancia de la clase

                // Itera sobre los campos de la clase
                for (Field campo : campos) {
                    campo.setAccessible(true); // Permite el acceso a campos privados
                    try {
                        Object valor = rs.getObject(campo.getName()); // Obtiene el valor del resultado
                        // Maneja conversiones de tipos de fecha
                        if (valor instanceof Timestamp && campo.getType().equals(LocalDateTime.class)) {
                            campo.set(obj, ((Timestamp) valor).toLocalDateTime());
                        } else if (valor instanceof Date && campo.getType().equals(LocalDate.class)) {
                            campo.set(obj, ((Date) valor).toLocalDate());
                        } else {
                            campo.set(obj, valor); // Asigna el valor al campo
                        }
                    } catch (SQLException e) {
                        // Columna no existe, ignorar   
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace(); // Manejo de excepciones
        } finally {
            try {
                if (shouldClose && con != null) {
                    con.close(); // Cierra la conexi�n si es necesario
                }
            } catch (SQLException e) {
                e.printStackTrace(); // Manejo de excepciones
            }
        }
        return obj; // Retorna el objeto recuperado
    }

    /**
     * Crea un nuevo registro en la base de datos a partir de un objeto de
     * entidad.
     *
     * @param <T> Tipo de la entidad
     * @param clazz Clase de la entidad
     * @param tableName Nombre de la tabla en la base de datos
     * @param entity Objeto de la entidad a insertar
     * @return El objeto insertado con su ID generado (si aplica), o null si
     * falla
     */
    public <T> T create(String tabla, T objeto) {
        StringBuilder columnas = new StringBuilder(); // StringBuilder para las columnas
        StringBuilder valores = new StringBuilder(); // StringBuilder para los valores
        List<Object> parametros = new ArrayList<>(); // Lista para los par�metros

        Field[] campos = objeto.getClass().getDeclaredFields(); // Obtiene los campos de la clase

        // Itera sobre los campos de la entidad
        for (Field campo : campos) {
            campo.setAccessible(true); // Permite el acceso a campos privados
            if (campo.getName().equalsIgnoreCase("id")) {
                continue; // Ignora el campo ID
            }
            try {
                Object valor = campo.get(objeto); // Obtiene el valor del campo
                if (valor != null) { // Si el valor no es nulo
                    columnas.append(campo.getName()).append(", "); // Agrega el nombre de la columna
                    valores.append("?, "); // Agrega un marcador de posici�n para el valor
                    parametros.add(valor); // Agrega el valor a la lista de par�metros
                }
            } catch (IllegalAccessException e) {
                e.printStackTrace(); // Manejo de excepciones
            }
        }

        if (parametros.isEmpty()) { // Si no hay par�metros, retorna null
            return null;
        }

        // Elimina la �ltima coma de las columnas y valores
        columnas.setLength(columnas.length() - 2);
        valores.setLength(valores.length() - 2);

        // Crea la consulta SQL
        String sql = MessageFormat.format("INSERT INTO {0} ({1}) VALUES ({2})", tabla, columnas, valores);

        Connection con = null; // Conexi�n a la base de datos
        boolean shouldClose = (externalConnection == null); // Determina si se debe cerrar la conexi�n

        try {
            con = getConnection(); // Obtiene la conexi�n activa
            PreparedStatement ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS); // Prepara la consulta

            // Establece los valores de los par�metros
            for (int i = 0; i < parametros.size(); i++) {
                Object param = parametros.get(i);

                // Maneja conversiones de tipos de fecha
                if (param instanceof LocalDateTime) {
                    ps.setTimestamp(i + 1, Timestamp.valueOf((LocalDateTime) param));
                } else if (param instanceof LocalDate) {
                    ps.setDate(i + 1, Date.valueOf((LocalDate) param));
                } else {
                    ps.setObject(i + 1, param); // Establece el valor del par�metro
                }
            }

            int filasAfectadas = ps.executeUpdate(); // Ejecuta la consulta

            if (filasAfectadas > 0) { // Si se afectaron filas
                ResultSet keys = ps.getGeneratedKeys(); // Obtiene las claves generadas
                if (keys.next()) { // Si hay claves generadas
                    int idGenerado = keys.getInt(1); // Obtiene el ID generado

                    // Asigna el ID generado al objeto
                    try {
                        Field idField = objeto.getClass().getDeclaredField("id");
                        idField.setAccessible(true);
                        idField.set(objeto, idGenerado);
                    } catch (NoSuchFieldException | IllegalAccessException e) {
                        e.printStackTrace(); // Manejo de excepciones
                    }

                    return objeto; // Retorna el objeto insertado
                }
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de excepciones
        } finally {
            try {
                if (shouldClose && con != null) {
                    con.close(); // Cierra la conexi�n si es necesario
                }
            } catch (SQLException e) {
                e.printStackTrace(); // Manejo de excepciones
            }
        }

        return null; // Retorna null si falla la inserci�n
    }

    /**
     * Actualiza un registro existente en la base de datos.
     *
     * @param <T> Tipo de la entidad
     * @param objeto Objeto con los nuevos valores (incluye el ID)
     * @param tabla Nombre de la tabla
     * @param campoId Nombre del campo identificador (como "id")
     * @return true si la actualizaci�n fue exitosa (al menos una fila
     * afectada), false si no
     * @throws SQLException si ocurre un error durante la operaci�n
     */
    public <T> boolean update(T objeto, String tabla, String campoId) throws SQLException {
        Connection conexion = null; // Conexi�n a la base de datos
        PreparedStatement ps = null; // PreparedStatement para la consulta

        try {
            conexion = getConnection(); // Obtiene la conexi�n activa
            conexion.setAutoCommit(false); // Desactiva el autocommit para manejar transacciones

            Field[] campos = objeto.getClass().getDeclaredFields(); // Obtiene los campos de la clase
            StringBuilder sql = new StringBuilder("UPDATE " + tabla + " SET "); // Consulta SQL

            List<Object> valores = new ArrayList<>(); // Lista para los valores
            Object valorId = null; // Valor del ID

            // Itera sobre los campos de la entidad
            for (Field campo : campos) {
                campo.setAccessible(true); // Permite el acceso a campos privados
                try {
                    if (campo.getName().equalsIgnoreCase(campoId)) { // Si es el campo ID
                        valorId = campo.get(objeto); // Obtiene el valor del ID
                        continue; // Contin�a con el siguiente campo
                    }

                    sql.append(campo.getName()).append(" = ?, "); // Agrega la asignaci�n del campo
                    Object valorCampo = campo.get(objeto); // Obtiene el valor del campo

                    // Maneja conversiones de tipos de fecha
                    if (valorCampo instanceof LocalDateTime) {
                        valores.add(Timestamp.valueOf((LocalDateTime) valorCampo));
                    } else if (valorCampo instanceof LocalDate) {
                        valores.add(Date.valueOf((LocalDate) valorCampo));
                    } else {
                        valores.add(valorCampo); // Agrega el valor a la lista
                    }
                } catch (IllegalAccessException e) {
                    throw new RuntimeException("No se pudo acceder al campo " + campo.getName(), e);
                }
            }

            sql.setLength(sql.length() - 2); // Elimina la �ltima coma
            sql.append(" WHERE ").append(campoId).append(" = ?"); // Agrega la cl�usula WHERE

            ps = conexion.prepareStatement(sql.toString()); // Prepara la consulta

            int index = 1; // �ndice para los par�metros
            for (Object valor : valores) {
                ps.setObject(index++, valor); // Establece los valores de los par�metros
            }
            ps.setObject(index, valorId); // Establece el valor del ID

            int filasAfectadas = ps.executeUpdate(); // Ejecuta la consulta
            conexion.commit(); // Realiza el commit de la transacci�n

            return filasAfectadas > 0; // Retorna true si se afectaron filas
        } catch (SQLException e) {
            if (conexion != null) {
                conexion.rollback(); // Realiza rollback en caso de error
            }
            throw new SQLException("Error al actualizar: " + e.getMessage(), e);
        } finally {
            if (ps != null) {
                ps.close(); // Cierra el PreparedStatement
            }
            if (conexion != null) {
                conexion.close(); // Cierra la conexi�n
            }
        }
    }

    /**
     * Elimina un registro por su ID.
     *
     * @param tabla Nombre de la tabla
     * @param id Identificador del registro a eliminar
     * @param campoId Nombre del campo del identificador
     * @return true si la eliminaci�n fue exitosa (al menos una fila afectada),
     * false si no
     * @throws SQLException si ocurre un error durante la operaci�n
     */
    public boolean delete(Object id, String tabla, String campoId) throws SQLException {
        Connection conexion = null; // Conexi�n a la base de datos
        PreparedStatement ps = null; // PreparedStatement para la consulta

        try {
            conexion = getConnection(); // Obtiene la conexi�n activa
            conexion.setAutoCommit(false); // Desactiva el autocommit para manejar transacciones

            // Crea la consulta SQL para eliminar el registro
            String sql = "DELETE FROM " + tabla + " WHERE " + campoId + " = ?";
            ps = conexion.prepareStatement(sql); // Prepara la consulta
            ps.setObject(1, id); // Establece el valor del par�metro

            int filasAfectadas = ps.executeUpdate(); // Ejecuta la consulta y obtiene el n�mero de filas afectadas
            conexion.commit(); // Realiza el commit de la transacci�n

            return filasAfectadas > 0; // Retorna true si se afectaron filas, false si no
        } catch (SQLException e) {
            if (conexion != null) {
                conexion.rollback(); // Realiza rollback en caso de error
            }
            throw new SQLException("Error al eliminar: " + e.getMessage(), e); // Lanza una excepci�n con el mensaje de error
        } finally {
            if (ps != null) {
                ps.close(); // Cierra el PreparedStatement
            }
            if (conexion != null) {
                conexion.close(); // Cierra la conexi�n
            }
        }
    }
}
