/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODELO;

import java.lang.reflect.Field;
import java.sql.*;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CrudDAO {
    private Connection externalConnection;

    // Constructor por defecto: conexión interna
    public CrudDAO() {}

    // Constructor con conexión externa (para transacciones)
    public CrudDAO(Connection connection) {
        this.externalConnection = connection;
    }

    // Devuelve la conexión actual: externa o nueva si es interna
    private Connection getConnection() throws SQLException {
        return (externalConnection != null) ? externalConnection : ConexionBD.conectar();
    }

    // getAll con soporte para transacción
    public <T> List<T> getAll(Class<T> clazz, String tabla) {
        List<T> lista = new ArrayList<>();
        String sql = "SELECT * FROM " + tabla + " ORDER BY id DESC";

        Connection con = null;
        boolean shouldClose = (externalConnection == null);

        try {
            con = getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            Field[] campos = clazz.getDeclaredFields();

            while (rs.next()) {
                T obj = clazz.getDeclaredConstructor().newInstance();

                for (Field campo : campos) {
                    campo.setAccessible(true);
                    try {
                        Object valor = rs.getObject(campo.getName());
                        if (valor instanceof Timestamp && campo.getType().equals(LocalDateTime.class)) {
                            campo.set(obj, ((Timestamp) valor).toLocalDateTime());
                        } else {
                            campo.set(obj, valor);
}
                    } catch (SQLException e) {
                        // Columna no existe, ignorar
                    }
                }
                lista.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (shouldClose && con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }
    
    // getByField con soporte para transacción
    public <T> List<T> getAllByField(Class<T> clazz, String tabla, String campoBusqueda, Object valorBusqueda) {
        List<T> lista = new ArrayList<>();
        String sql = "SELECT * FROM " + tabla + " WHERE " + campoBusqueda + " = ? ORDER BY id DESC";

        Connection con = null;
        boolean shouldClose = (externalConnection == null);

        try {
            con = getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setObject(1, valorBusqueda);
            ResultSet rs = ps.executeQuery();

            Field[] campos = clazz.getDeclaredFields();

            while (rs.next()) {
                T obj = clazz.getDeclaredConstructor().newInstance();

                for (Field campo : campos) {
                    campo.setAccessible(true);
                    try {
                        Object valor = rs.getObject(campo.getName());
                        if (valor instanceof Timestamp && campo.getType().equals(LocalDateTime.class)) {
                            campo.set(obj, ((Timestamp) valor).toLocalDateTime());
                        } else {
                            campo.set(obj, valor);
                        }
                    } catch (SQLException e) {
                        // Columna no existe, ignorar
                    }
                }

                lista.add(obj);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (shouldClose && con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return lista;
    }


    // getById con soporte para transacción
    public <T> T getById(Class<T> clazz, String tabla, int id) {
        String sql = "SELECT * FROM " + tabla + " WHERE id = ?";
        T obj = null;

        Connection con = null;
        boolean shouldClose = (externalConnection == null);

        try {
            con = getConnection();  
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            Field[] campos = clazz.getDeclaredFields();

            if (rs.next()) {
                obj = clazz.getDeclaredConstructor().newInstance();

                for (Field campo : campos) {
                    campo.setAccessible(true);
                    try {
                        Object valor = rs.getObject(campo.getName());
                        if (valor instanceof Timestamp && campo.getType().equals(LocalDateTime.class)) {
                            campo.set(obj, ((Timestamp) valor).toLocalDateTime());
                        } else {
                            campo.set(obj, valor);
                        }
                    } catch (SQLException e) {
                        // Columna no existe, ignorar
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (shouldClose && con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return obj;
    }

    // create con soporte para transacción
    public <T> T create(Class<T> clazz, String tabla, Object objeto) {
        StringBuilder columnas = new StringBuilder();
        StringBuilder valores = new StringBuilder();
        List<Object> parametros = new ArrayList<>();

        Field[] campos = objeto.getClass().getDeclaredFields();

        for (Field campo : campos) {
            campo.setAccessible(true);
            if (campo.getName().equalsIgnoreCase("id")) continue;

            try {
                Object valor = campo.get(objeto);
                if (valor != null) {
                    columnas.append(campo.getName()).append(", ");
                    valores.append("?, ");
                    parametros.add(valor);
                }
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }

        if (parametros.isEmpty()) {
            return null;
        }

        columnas.setLength(columnas.length() - 2);
        valores.setLength(valores.length() - 2);

        String sql = MessageFormat.format("INSERT INTO {0} ({1}) VALUES ({2})", tabla, columnas, valores);

        Connection con = null;
        boolean shouldClose = (externalConnection == null);

        try {
            con = getConnection();
            PreparedStatement ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);

            for (int i = 0; i < parametros.size(); i++) {
                ps.setObject(i + 1, parametros.get(i));
            }

            int filasAfectadas = ps.executeUpdate();

            if (filasAfectadas > 0) {
                ResultSet keys = ps.getGeneratedKeys();
                if (keys.next()) {
                    int idGenerado = keys.getInt(1);

                    try {
                        Field idField = objeto.getClass().getDeclaredField("id");
                        idField.setAccessible(true);
                        idField.set(objeto, idGenerado);
                    } catch (NoSuchFieldException | IllegalAccessException e) {
                        e.printStackTrace();
                    }

                    return clazz.cast(objeto);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (shouldClose && con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return null;
    }
}
