/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.Cliente;
import MODELO.ClienteInfoDTO;
import MODELO.CrudDAO;
import MODELO.Especie;
import MODELO.InformacionClientesPersonal;
import MODELO.Mascota;
import MODELO.MascotaDTO;
import MODELO.Raza;
import MODELO.RazaDTO;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Propietario
 */
@Path("mascotas")
public class MascotaController {
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllMascotas() {
        try {
            final CrudDAO objDao = new CrudDAO();
            final List<Mascota> mascotas = objDao.getAll(Mascota.class, "mascotas");
            
            // Validamos si existen clientes
            if (mascotas.isEmpty())
                return new ResponseProvider(false, 404, "No hay mascotas registradas", null, null).toResponse();
            
            List<MascotaDTO> listaMascotasDTO = new ArrayList<>();
            
            for (Mascota m : mascotas) {
                MascotaDTO mascotaDTO = new MascotaDTO();
                mascotaDTO.setId(m.getId());
                mascotaDTO.setEdad(m.getEdad());
                mascotaDTO.setEstado_vital(m.getEstado_vital());
                mascotaDTO.setNombre(m.getNombre());
                mascotaDTO.setSexo(m.getSexo());
                
                List<Cliente> cliente = objDao.getById(Cliente.class, "clientes", m.getId_cliente());
            
                List<InformacionClientesPersonal> infoCliente = objDao.getById(InformacionClientesPersonal.class, "informacion_clientes_personal", cliente.get(0).getId_info());
                
                ClienteInfoDTO clienteDTO = new ClienteInfoDTO();
                
                clienteDTO.setId(cliente.get(0).getId());
                clienteDTO.setInfo(infoCliente.get(0));
                mascotaDTO.setDueno(clienteDTO);
                
                List<Raza> razaMascota = objDao.getById(Raza.class, "razas", m.getId_raza());
                List<Especie> especieRaza = objDao.getById(Especie.class, "especies", razaMascota.get(0).getId_especie());
                
                RazaDTO razaDTO = new RazaDTO();
                razaDTO.setId(razaMascota.get(0).getId());
                razaDTO.setNombre(razaMascota.get(0).getNombre());
                razaDTO.setEspecie(especieRaza.get(0));
                mascotaDTO.setRaza(razaDTO);
                
                
                listaMascotasDTO.add(mascotaDTO);
            }
            
            return new ResponseProvider(true, 200, "Mascotas obtenidas correctamente", listaMascotasDTO, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener las mascotas", e, null).toResponse(); 
        }
    }
}
