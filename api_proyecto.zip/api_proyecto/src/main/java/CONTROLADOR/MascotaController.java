package CONTROLADOR;

import MODELO.DAO.AntecedenteDAO;
import MODELO.Cliente;
import MODELO.DTO.ClienteResponseDTO;
import MODELO.DAO.CrudDAO;
import MODELO.Especie;
import MODELO.Mascota;
import MODELO.DAO.MascotaDAO;
import MODELO.DTO.MascotaResponseDTO;
import MODELO.MascotaUtils;
import MODELO.Raza;
import MODELO.DTO.RazaResponseDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import MODELO.DTO.ClienteDtoBuilder;

/**
 * Controlador REST para gestionar operaciones relacionadas con mascotas.
 * Permite consultar todas las mascotas, obtener mascotas por ID o por cliente.
 */
@Path("mascotas")
public class MascotaController {

    /**
     * Obtiene todas las mascotas registradas en la base de datos. Cada mascota
     * se transforma en un DTO enriquecido con información de raza, especie y
     * propietario.
     *
     * @return Respuesta con la lista de mascotas o mensaje de error si no hay
     * registros.
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllMascotas() {
        try {
            final CrudDAO objDao = new CrudDAO();
            final List<Mascota> mascotas = objDao.getAll(Mascota.class, "mascotas");

            if (mascotas.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay mascotas registradas", null, null).toResponse();
            }

            List<MascotaResponseDTO> listaMascotasDTO = new ArrayList<>();

            // Recorre cada mascota y construye su DTO correspondiente
            for (Mascota m : mascotas) {
                MascotaResponseDTO mascotaDTO = new MascotaResponseDTO();
                mascotaDTO.setId(m.getId());
                mascotaDTO.setNombre(m.getNombre());
                mascotaDTO.setEdad_semanas(m.getEdad_semanas());
                mascotaDTO.setSexo(m.getSexo());
                mascotaDTO.setEstado_vital(m.isEstado_vital());

                // Obtiene la fecha del último antecedente registrado
                mascotaDTO.setUltimo_registro(AntecedenteDAO.getUltimaFechaAntecedenteByIdMascota(m.getId()));

                // Obtiene la raza y especie asociada
                Raza razaMascota = objDao.getById(Raza.class, "razas", m.getId_raza());
                Especie especieRaza = objDao.getById(Especie.class, "especies", razaMascota.getId_especie());

                RazaResponseDTO razaDTO = new RazaResponseDTO();
                razaDTO.setId(razaMascota.getId());
                razaDTO.setNombre(razaMascota.getNombre());
                razaDTO.setEspecie(especieRaza);
                mascotaDTO.setRaza(razaDTO);

                // Obtiene y asigna información del propietario
                Cliente cliente = objDao.getById(Cliente.class, "clientes", m.getId_cliente());
                ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
                mascotaDTO.setCliente(clienteDTO);

                // Formatea la edad en semanas a una representación legible
                String edadFormateada = MascotaUtils.formatearEdad(m.getEdad_semanas());
                mascotaDTO.setEdadFormateada(edadFormateada);

                listaMascotasDTO.add(mascotaDTO);
            }

            return new ResponseProvider(true, 200, "Mascotas obtenidas correctamente", listaMascotasDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener las mascotas", e, null).toResponse();
        }
    }

    /**
     * Obtiene una mascota por su ID. Incluye información de raza, especie y
     * propietario en el DTO de respuesta.
     *
     * @param idMascota ID de la mascota a consultar.
     * @return Respuesta con la mascota encontrada o mensaje de error si no
     * existe.
     */
    @GET
    @Path("/{idMascota}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMascotaById(@PathParam("idMascota") int idMascota) {
        try {
            final CrudDAO objDao = new CrudDAO();
            Mascota mascota = objDao.getById(Mascota.class, "mascotas", idMascota);

            if (mascota == null) {
                return new ResponseProvider(false, 404, "No hay mascotas registradas", null, null).toResponse();
            }

            MascotaResponseDTO mascotaDTO = new MascotaResponseDTO();
            mascotaDTO.setId(mascota.getId());
            mascotaDTO.setNombre(mascota.getNombre());
            mascotaDTO.setEdad_semanas(mascota.getEdad_semanas());
            mascotaDTO.setSexo(mascota.getSexo());
            mascotaDTO.setEstado_vital(mascota.isEstado_vital());

            Raza razaMascota = objDao.getById(Raza.class, "razas", mascota.getId_raza());
            Especie especieRaza = objDao.getById(Especie.class, "especies", razaMascota.getId_especie());

            RazaResponseDTO razaDTO = new RazaResponseDTO();
            razaDTO.setId(razaMascota.getId());
            razaDTO.setNombre(razaMascota.getNombre());
            razaDTO.setEspecie(especieRaza);
            mascotaDTO.setRaza(razaDTO);

            Cliente cliente = objDao.getById(Cliente.class, "clientes", mascota.getId_cliente());
            ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
            mascotaDTO.setCliente(clienteDTO);

            String edadFormateada = MascotaUtils.formatearEdad(mascota.getEdad_semanas());
            mascotaDTO.setEdadFormateada(edadFormateada);

            return new ResponseProvider(true, 200, "Mascota obtenida correctamente", mascotaDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener las mascotas", e, null).toResponse();
        }
    }

    /**
     * Obtiene todas las mascotas asociadas a un cliente específico. Cada
     * mascota se transforma en un DTO enriquecido con información adicional.
     *
     * @param idCliente ID del cliente.
     * @return Respuesta con la lista de mascotas del cliente o mensaje de error
     * si no hay registros.
     */
    @GET
    @Path("/cliente/{idCliente}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMascotasByClienteId(@PathParam("idCliente") int idCliente) {
        try {
            CrudDAO objDao = new CrudDAO();

            List<Mascota> mascotas = objDao.getAllByField(Mascota.class, "mascotas", "id_cliente", idCliente);

            if (mascotas.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay mascotas registradas para este cliente", null, null).toResponse();
            }

            List<MascotaResponseDTO> listaMascotasDTO = new ArrayList<>();

            // Recorre cada mascota y construye su DTO correspondiente
            for (Mascota m : mascotas) {
                MascotaResponseDTO mascotaDTO = new MascotaResponseDTO();
                mascotaDTO.setId(m.getId());
                mascotaDTO.setNombre(m.getNombre());
                mascotaDTO.setEdad_semanas(m.getEdad_semanas());
                mascotaDTO.setSexo(m.getSexo());
                mascotaDTO.setEstado_vital(m.isEstado_vital());

                Raza razaMascota = objDao.getById(Raza.class, "razas", m.getId_raza());
                Especie especieRaza = objDao.getById(Especie.class, "especies", razaMascota.getId_especie());

                RazaResponseDTO razaDTO = new RazaResponseDTO();
                razaDTO.setId(razaMascota.getId());
                razaDTO.setNombre(razaMascota.getNombre());
                razaDTO.setEspecie(especieRaza);
                mascotaDTO.setRaza(razaDTO);

                Cliente cliente = objDao.getById(Cliente.class, "clientes", m.getId_cliente());
                ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
                mascotaDTO.setCliente(clienteDTO);

                String edadFormateada = MascotaUtils.formatearEdad(m.getEdad_semanas());
                mascotaDTO.setEdadFormateada(edadFormateada);

                listaMascotasDTO.add(mascotaDTO);
            }

            return new ResponseProvider(true, 200, "Mascotas del cliente obtenidas correctamente", listaMascotasDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener las mascotas del cliente", e, null).toResponse();
        }
    }

    /**
     * Crea una nueva mascota en la base de datos. La mascota se registra como
     * activa por defecto y se retorna con información enriquecida.
     *
     * @param nuevaMascota Objeto recibido desde el cliente.
     * @return Respuesta con la mascota creada o mensaje de error.
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMascota(Mascota nuevaMascota) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Se marca como viva por defecto
            nuevaMascota.setEstado_vital(true);

            // Inserta la mascota en la base de datos
            Mascota mascotaCreada = objDao.create("mascotas", nuevaMascota);

            if (mascotaCreada == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar la mascota", null, null).toResponse();
            }

            // Construye el DTO de respuesta con información adicional
            MascotaResponseDTO mascotaDTO = new MascotaResponseDTO();
            mascotaDTO.setId(mascotaCreada.getId());
            mascotaDTO.setNombre(mascotaCreada.getNombre());
            mascotaDTO.setEdad_semanas(mascotaCreada.getEdad_semanas());
            mascotaDTO.setSexo(mascotaCreada.getSexo());
            mascotaDTO.setEstado_vital(mascotaCreada.isEstado_vital());

            // Raza y especie
            Raza razaMascota = objDao.getById(Raza.class, "razas", mascotaCreada.getId_raza());
            Especie especieRaza = objDao.getById(Especie.class, "especies", razaMascota.getId_especie());

            RazaResponseDTO razaDTO = new RazaResponseDTO();
            razaDTO.setId(razaMascota.getId());
            razaDTO.setNombre(razaMascota.getNombre());
            razaDTO.setEspecie(especieRaza);
            mascotaDTO.setRaza(razaDTO);

            // Cliente
            Cliente cliente = objDao.getById(Cliente.class, "clientes", mascotaCreada.getId_cliente());
            ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
            mascotaDTO.setCliente(clienteDTO);

            // Edad formateada
            String edadFormateada = MascotaUtils.formatearEdad(mascotaCreada.getEdad_semanas());
            mascotaDTO.setEdadFormateada(edadFormateada);

            return new ResponseProvider(true, 201, "Mascota registrada exitosamente", mascotaDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar la mascota", e, null).toResponse();
        }
    }

    /**
     * Actualiza los datos de una mascota existente. Retorna la mascota
     * actualizada con información enriquecida.
     *
     * @param mascotaActualizada Objeto con los nuevos valores.
     * @return Respuesta con la mascota actualizada o mensaje de error.
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateMascota(Mascota mascotaActualizada) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Verifica si la mascota existe
            Mascota mascotaExistente = objDao.getById(Mascota.class, "mascotas", mascotaActualizada.getId());
            if (mascotaExistente == null) {
                return new ResponseProvider(false, 404, "No se encontró la mascota a actualizar", null, null).toResponse();
            }

            // Actualiza la mascota en la base de datos
            boolean exito = objDao.update(mascotaActualizada, "mascotas", "id");
            if (!exito) {
                return new ResponseProvider(false, 500, "No se pudo actualizar la mascota", null, null).toResponse();
            }

            // Construye el DTO de respuesta
            MascotaResponseDTO mascotaDTO = new MascotaResponseDTO();
            mascotaDTO.setId(mascotaActualizada.getId());
            mascotaDTO.setNombre(mascotaActualizada.getNombre());
            mascotaDTO.setEdad_semanas(mascotaActualizada.getEdad_semanas());
            mascotaDTO.setSexo(mascotaActualizada.getSexo());
            mascotaDTO.setEstado_vital(mascotaActualizada.isEstado_vital());

            // Raza y especie
            Raza razaMascota = objDao.getById(Raza.class, "razas", mascotaActualizada.getId_raza());
            Especie especieRaza = objDao.getById(Especie.class, "especies", razaMascota.getId_especie());

            RazaResponseDTO razaDTO = new RazaResponseDTO();
            razaDTO.setId(razaMascota.getId());
            razaDTO.setNombre(razaMascota.getNombre());
            razaDTO.setEspecie(especieRaza);
            mascotaDTO.setRaza(razaDTO);

            // Cliente
            Cliente cliente = objDao.getById(Cliente.class, "clientes", mascotaActualizada.getId_cliente());
            ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
            mascotaDTO.setCliente(clienteDTO);

            // Edad formateada
            String edadFormateada = MascotaUtils.formatearEdad(mascotaActualizada.getEdad_semanas());
            mascotaDTO.setEdadFormateada(edadFormateada);

            return new ResponseProvider(true, 200, "Mascota actualizada exitosamente", mascotaDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar la mascota", e, null).toResponse();
        }
    }

    /**
     * Desactiva una mascota marcándola como no viva (estado_vital = false).
     *
     * @param idMascota ID de la mascota a desactivar.
     * @return Respuesta indicando si la desactivación fue exitosa.
     */
    @PUT
    @Path("/desactivar/{idMascota}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response desactivarMascota(@PathParam("idMascota") int idMascota) {
        try {
            MascotaDAO mascotaDao = new MascotaDAO();

            // Intenta desactivar la mascota
            boolean exito = mascotaDao.desactivarMascota(idMascota);

            if (!exito) {
                return new ResponseProvider(false, 404, "No se encontró la mascota a desactivar", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Mascota desactivada correctamente", null, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al desactivar la mascota", e, null).toResponse();
        }
    }

}
