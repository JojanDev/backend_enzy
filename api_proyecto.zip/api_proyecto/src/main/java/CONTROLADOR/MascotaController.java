package CONTROLADOR;

import MODELO.Cliente;
import MODELO.ClienteGetResponseDTO;
import MODELO.CrudDAO;
import MODELO.Especie;
import MODELO.InformacionClientesPersonal;
import MODELO.Mascota;
import MODELO.MascotaDAO;
import MODELO.MascotaGetResponseDTO;
import MODELO.MascotaSinDuenoGetResponseDTO;
import MODELO.MascotaUtils;
import MODELO.Raza;
import MODELO.RazaGetResponseDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import modelo.ClienteDtoBuilder;

/**
 *
 * @author Propietario
 */
@Path("mascotas")
public class MascotaController {
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllMascotas() {
        try {
            final CrudDAO objDao = new CrudDAO();
            final List<Mascota> mascotas = objDao.getAll(Mascota.class, "mascotas");
            
            // Validamos si existen clientes
            if (mascotas.isEmpty())
                return new ResponseProvider(false, 404, "No hay mascotas registradas", null, null).toResponse();
            
            List<MascotaGetResponseDTO> listaMascotasDTO = new ArrayList<>();
            
            for (Mascota m : mascotas) {
                MascotaGetResponseDTO mascotaDTO = new MascotaGetResponseDTO();
                mascotaDTO.setId(m.getId());
                mascotaDTO.setEdadSemanas(m.getEdad_semanas());
                mascotaDTO.setEstado_vital(m.getEstado_vital());
                mascotaDTO.setNombre(m.getNombre());
                mascotaDTO.setSexo(m.getSexo());
                
                Cliente cliente = objDao.getById(Cliente.class, "clientes", m.getId_cliente());
                
                ClienteGetResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
                
                mascotaDTO.setDueno(clienteDTO);
                
                Raza razaMascota = objDao.getById(Raza.class, "razas", m.getId_raza());
                Especie especieRaza = objDao.getById(Especie.class, "especies", razaMascota.getId_especie());
                
                RazaGetResponseDTO razaDTO = new RazaGetResponseDTO();
                razaDTO.setId(razaMascota.getId());
                razaDTO.setNombre(razaMascota.getNombre()); 
                razaDTO.setEspecie(especieRaza);
                mascotaDTO.setRaza(razaDTO);
                
                String edadFormateada = MascotaUtils.formatearEdad(m.getEdad_semanas());
                mascotaDTO.setEdadFormateada(edadFormateada);
                
                listaMascotasDTO.add(mascotaDTO);
            }
            
            return new ResponseProvider(true, 200, "Mascotas obtenidas correctamente", listaMascotasDTO, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener las mascotas", e, null).toResponse(); 
        }
    }
    
    @GET
    @Path("/cliente/{idCliente}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMascotasByClienteId(@PathParam("idCliente") int idCliente) {
        try {
            MascotaDAO mascotaDao = new MascotaDAO();
            CrudDAO objDao = new CrudDAO();

            List<Mascota> mascotas = mascotaDao.getByClienteId(idCliente);
            if (mascotas.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay mascotas registradas para este cliente", null, null).toResponse();
            }

            List<MascotaSinDuenoGetResponseDTO> listaMascotasDTO = new ArrayList<>();

            for (Mascota m : mascotas) {
                MascotaSinDuenoGetResponseDTO mascotaDTO = new MascotaSinDuenoGetResponseDTO();
                mascotaDTO.setId(m.getId());
                mascotaDTO.setEdadSemanas(m.getEdad_semanas());
                mascotaDTO.setEstado_vital(m.getEstado_vital());
                mascotaDTO.setNombre(m.getNombre());
                mascotaDTO.setSexo(m.getSexo());

                // Obtener raza y especie
                Raza razaMascota = objDao.getById(Raza.class, "razas", m.getId_raza());
                Especie especieRaza = objDao.getById(Especie.class, "especies", razaMascota.getId_especie());

                RazaGetResponseDTO razaDTO = new RazaGetResponseDTO();
                razaDTO.setId(razaMascota.getId());
                razaDTO.setNombre(razaMascota.getNombre());
                razaDTO.setEspecie(especieRaza);

                mascotaDTO.setRaza(razaDTO);
                
                String edadFormateada = MascotaUtils.formatearEdad(m.getEdad_semanas());
                mascotaDTO.setEdadFormateada(edadFormateada);
                
                listaMascotasDTO.add(mascotaDTO);
            }

            return new ResponseProvider(true, 200, "Mascotas del cliente obtenidas correctamente", listaMascotasDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener las mascotas del cliente", e, null).toResponse();
        }
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMascota(Mascota nuevaMascota) {
        try {
            CrudDAO objDao = new CrudDAO();
            Mascota mascotaCreada = objDao.create(Mascota.class, "mascotas", nuevaMascota);

            if (mascotaCreada == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar la mascota", null, null).toResponse();
            }

            // Construir DTO de respuesta sin dueño
            MascotaSinDuenoGetResponseDTO dto = new MascotaSinDuenoGetResponseDTO();
            dto.setId(mascotaCreada.getId());
            dto.setNombre(mascotaCreada.getNombre());
            dto.setSexo(mascotaCreada.getSexo());
            dto.setEdadSemanas(mascotaCreada.getEdad_semanas());
            dto.setEdadFormateada(MascotaUtils.formatearEdad(mascotaCreada.getEdad_semanas()));

            // Obtener raza y especie
            Raza raza = objDao.getById(Raza.class, "razas", mascotaCreada.getId_raza());
            Especie especie = objDao.getById(Especie.class, "especies", raza.getId_especie());

            RazaGetResponseDTO razaDTO = new RazaGetResponseDTO();
            razaDTO.setId(raza.getId());
            razaDTO.setNombre(raza.getNombre());
            razaDTO.setEspecie(especie);

            dto.setRaza(razaDTO);

            return new ResponseProvider(true, 201, "Mascota registrada exitosamente", dto, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar la mascota", e, null).toResponse();
        }
    }



}
