package CONTROLADOR;

import MODELO.DAO.AntecedenteDAO;
import MODELO.Cliente;
import MODELO.DTO.ClienteResponseDTO;
import MODELO.DAO.CrudDAO;
import MODELO.Especie;
import MODELO.Mascota;
import MODELO.DAO.MascotaDAO;
import MODELO.DTO.MascotaResponseDTO;
import MODELO.MascotaUtils;
import MODELO.Raza;
import MODELO.DTO.RazaResponseDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import MODELO.DTO.ClienteDtoBuilder;

/**
 * Controlador REST para gestionar operaciones relacionadas con mascotas.
 * Proporciona endpoints para:
 * - obtener todas las mascotas registradas con información enriquecida
 * - obtener una mascota por su ID
 * - obtener mascotas asociadas a un cliente específico
 * - crear nuevas mascotas
 * - actualizar datos de mascotas existentes
 * - desactivar mascotas (soft delete mediante estado_vital = false)
 */
@Path("mascotas")
public class MascotaController {

    /**
     * Obtiene todas las mascotas registradas en la base de datos. Cada mascota
     * se transforma en un DTO enriquecido con información de raza, especie y
     * propietario.
     *
     * @return Response con lista de MascotaResponseDTO o mensaje de error si no
     * hay registros
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllMascotas() {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera todas las mascotas de la tabla 'mascotas'
            List<Mascota> mascotas = objDao.getAll(Mascota.class, "mascotas");

            // si no hay mascotas registradas, retorna 404
            if (mascotas.isEmpty()) {
                return new ResponseProvider(
                        false,
                        404,
                        "No hay mascotas registradas",
                        null,
                        null
                ).toResponse();
            }

            // lista para almacenar los DTO de cada mascota
            List<MascotaResponseDTO> listaMascotasDTO = new ArrayList<>();

            // recorre cada entidad Mascota y construye su DTO
            for (Mascota m : mascotas) {
                MascotaResponseDTO mascotaDTO = new MascotaResponseDTO();
                mascotaDTO.setId(m.getId());
                mascotaDTO.setNombre(m.getNombre());
                mascotaDTO.setEdad_semanas(m.getEdad_semanas());
                mascotaDTO.setSexo(m.getSexo());
                mascotaDTO.setEstado_vital(m.isEstado_vital());

                // obtiene la fecha del último antecedente registrado
                mascotaDTO.setUltimo_registro(
                        AntecedenteDAO.getUltimaFechaAntecedenteByIdMascota(m.getId())
                );

                // obtiene la raza y su especie asociada
                Raza razaMascota = objDao.getById(Raza.class, "razas", m.getId_raza());
                Especie especieRaza = objDao.getById(
                        Especie.class, "especies", razaMascota.getId_especie()
                );

                // construye el DTO de Raza con la especie incluida
                RazaResponseDTO razaDTO = new RazaResponseDTO();
                razaDTO.setId(razaMascota.getId());
                razaDTO.setNombre(razaMascota.getNombre());
                razaDTO.setEspecie(especieRaza);
                mascotaDTO.setRaza(razaDTO);

                // obtiene y asigna información del propietario (cliente)
                Cliente cliente = objDao.getById(Cliente.class, "clientes", m.getId_cliente());
                ClienteResponseDTO clienteDTO
                        = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
                mascotaDTO.setCliente(clienteDTO);

                // formatea la edad en semanas a una representación legible
                String edadFormateada = MascotaUtils.formatearEdad(m.getEdad_semanas());
                mascotaDTO.setEdadFormateada(edadFormateada);

                // agrega el DTO a la lista de respuesta
                listaMascotasDTO.add(mascotaDTO);
            }

            // retorna 200 con la lista completa de DTOs
            return new ResponseProvider(
                    true,
                    200,
                    "Mascotas obtenidas correctamente",
                    listaMascotasDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de excepción inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener las mascotas",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Obtiene una mascota por su ID. Incluye información de raza, especie y
     * propietario en el DTO de respuesta.
     *
     * @param idMascota ID de la mascota a consultar
     * @return Response con MascotaResponseDTO o mensaje de error si no existe
     */
    @GET
    @Path("/{idMascota}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMascotaById(@PathParam("idMascota") int idMascota) {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera la entidad Mascota por su ID
            Mascota mascota = objDao.getById(Mascota.class, "mascotas", idMascota);

            // si no se encuentra la mascota, retorna 404
            if (mascota == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "No hay mascotas registradas",
                        null,
                        null
                ).toResponse();
            }

            // construye el DTO de la mascota
            MascotaResponseDTO mascotaDTO = new MascotaResponseDTO();
            mascotaDTO.setId(mascota.getId());
            mascotaDTO.setNombre(mascota.getNombre());
            mascotaDTO.setEdad_semanas(mascota.getEdad_semanas());
            mascotaDTO.setSexo(mascota.getSexo());
            mascotaDTO.setEstado_vital(mascota.isEstado_vital());

            // obtiene raza y especie asociada
            Raza razaMascota = objDao.getById(Raza.class, "razas", mascota.getId_raza());
            Especie especieRaza = objDao.getById(
                    Especie.class, "especies", razaMascota.getId_especie()
            );
            RazaResponseDTO razaDTO = new RazaResponseDTO();
            razaDTO.setId(razaMascota.getId());
            razaDTO.setNombre(razaMascota.getNombre());
            razaDTO.setEspecie(especieRaza);
            mascotaDTO.setRaza(razaDTO);

            // obtiene y asigna información del propietario
            Cliente cliente = objDao.getById(Cliente.class, "clientes", mascota.getId_cliente());
            ClienteResponseDTO clienteDTO
                    = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
            mascotaDTO.setCliente(clienteDTO);

            // formatea la edad en semanas a una representación legible
            String edadFormateada = MascotaUtils.formatearEdad(mascota.getEdad_semanas());
            mascotaDTO.setEdadFormateada(edadFormateada);

            // retorna 200 con el DTO construido
            return new ResponseProvider(
                    true,
                    200,
                    "Mascota obtenida correctamente",
                    mascotaDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de excepción inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener las mascotas",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Obtiene todas las mascotas asociadas a un cliente específico. Cada
     * mascota se transforma en un DTO enriquecido con información de raza,
     * especie y propietario.
     *
     * @param idCliente ID del cliente
     * @return Response con lista de MascotaResponseDTO o error si no hay
     * registros
     */
    @GET
    @Path("/cliente/{idCliente}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMascotasByClienteId(
            @PathParam("idCliente") int idCliente) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera todas las mascotas que pertenecen al cliente dado
            List<Mascota> mascotas = objDao.getAllByField(
                    Mascota.class,
                    "mascotas",
                    "id_cliente",
                    idCliente
            );

            // si no hay mascotas para este cliente, retorna 404
            if (mascotas.isEmpty()) {
                return new ResponseProvider(
                        false,
                        404,
                        "No hay mascotas registradas para este cliente",
                        null,
                        null
                ).toResponse();
            }

            // lista para almacenar los DTO de cada mascota
            List<MascotaResponseDTO> listaMascotasDTO = new ArrayList<>();

            // recorre cada entidad Mascota y construye su DTO
            for (Mascota m : mascotas) {
                MascotaResponseDTO mascotaDTO = new MascotaResponseDTO();
                mascotaDTO.setId(m.getId());
                mascotaDTO.setNombre(m.getNombre());
                mascotaDTO.setEdad_semanas(m.getEdad_semanas());
                mascotaDTO.setSexo(m.getSexo());
                mascotaDTO.setEstado_vital(m.isEstado_vital());

                // obtiene raza y especie asociada
                Raza razaMascota = objDao.getById(
                        Raza.class,
                        "razas",
                        m.getId_raza()
                );
                Especie especieRaza = objDao.getById(
                        Especie.class,
                        "especies",
                        razaMascota.getId_especie()
                );
                RazaResponseDTO razaDTO = new RazaResponseDTO();
                razaDTO.setId(razaMascota.getId());
                razaDTO.setNombre(razaMascota.getNombre());
                razaDTO.setEspecie(especieRaza);
                mascotaDTO.setRaza(razaDTO);

                // obtiene información del propietario y construye su DTO
                Cliente cliente = objDao.getById(
                        Cliente.class,
                        "clientes",
                        m.getId_cliente()
                );
                ClienteResponseDTO clienteDTO
                        = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
                mascotaDTO.setCliente(clienteDTO);

                // formatea la edad en semanas para respuesta legible
                String edadFormateada
                        = MascotaUtils.formatearEdad(m.getEdad_semanas());
                mascotaDTO.setEdadFormateada(edadFormateada);

                // agrega el DTO a la lista de respuesta
                listaMascotasDTO.add(mascotaDTO);
            }

            // retorna 200 con la lista de mascotas del cliente
            return new ResponseProvider(
                    true,
                    200,
                    "Mascotas del cliente obtenidas correctamente",
                    listaMascotasDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de excepción inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener las mascotas del cliente",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Crea una nueva mascota en la base de datos. La mascota se registra como
     * viva por defecto y se retorna en un DTO enriquecido con datos de raza,
     * especie y propietario.
     *
     * @param nuevaMascota objeto Mascota recibido desde el cliente
     * @return Response con MascotaResponseDTO o mensaje de error
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMascota(Mascota nuevaMascota) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // marca la mascota como viva (estado vital = true) por defecto
            nuevaMascota.setEstado_vital(true);

            // inserta la nueva mascota y obtiene la entidad creada
            Mascota mascotaCreada = objDao.create("mascotas", nuevaMascota);

            // si la inserción falla, retorna 400
            if (mascotaCreada == null) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo registrar la mascota",
                        null,
                        null
                ).toResponse();
            }

            // construye el DTO de la mascota con datos básicos
            MascotaResponseDTO mascotaDTO = new MascotaResponseDTO();
            mascotaDTO.setId(mascotaCreada.getId());
            mascotaDTO.setNombre(mascotaCreada.getNombre());
            mascotaDTO.setEdad_semanas(mascotaCreada.getEdad_semanas());
            mascotaDTO.setSexo(mascotaCreada.getSexo());
            mascotaDTO.setEstado_vital(mascotaCreada.isEstado_vital());

            // recupera y asigna raza y especie
            Raza razaMascota = objDao.getById(
                    Raza.class,
                    "razas",
                    mascotaCreada.getId_raza()
            );
            Especie especieRaza = objDao.getById(
                    Especie.class,
                    "especies",
                    razaMascota.getId_especie()
            );
            RazaResponseDTO razaDTO = new RazaResponseDTO();
            razaDTO.setId(razaMascota.getId());
            razaDTO.setNombre(razaMascota.getNombre());
            razaDTO.setEspecie(especieRaza);
            mascotaDTO.setRaza(razaDTO);

            // recupera y asigna datos del propietario
            Cliente cliente = objDao.getById(
                    Cliente.class,
                    "clientes",
                    mascotaCreada.getId_cliente()
            );
            ClienteResponseDTO clienteDTO
                    = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
            mascotaDTO.setCliente(clienteDTO);

            // formatea y asigna la edad en semanas
            String edadFormateada
                    = MascotaUtils.formatearEdad(mascotaCreada.getEdad_semanas());
            mascotaDTO.setEdadFormateada(edadFormateada);

            // retorna 201 con el DTO de la mascota creada
            return new ResponseProvider(
                    true,
                    201,
                    "Mascota registrada exitosamente",
                    mascotaDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de excepción inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al registrar la mascota",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Actualiza los datos de una mascota existente. Retorna la mascota
     * actualizada con informacion enriquecida.
     *
     * @param mascotaActualizada Objeto Mascota con los nuevos valores
     * @return Response con MascotaResponseDTO o mensaje de error
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateMascota(Mascota mascotaActualizada) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // verifica existencia de la mascota por ID
            Mascota mascotaExistente = objDao.getById(
                    Mascota.class,
                    "mascotas",
                    mascotaActualizada.getId()
            );
            if (mascotaExistente == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "No se encontro la mascota a actualizar",
                        null,
                        null
                ).toResponse();
            }

            // realiza la actualizacion en la tabla 'mascotas'
            boolean exito = objDao.update(
                    mascotaActualizada,
                    "mascotas",
                    "id"
            );
            if (!exito) {
                return new ResponseProvider(
                        false,
                        500,
                        "No se pudo actualizar la mascota",
                        null,
                        null
                ).toResponse();
            }

            // construye el DTO de respuesta con datos actualizados
            MascotaResponseDTO mascotaDTO = new MascotaResponseDTO();
            mascotaDTO.setId(mascotaActualizada.getId());
            mascotaDTO.setNombre(mascotaActualizada.getNombre());
            mascotaDTO.setEdad_semanas(mascotaActualizada.getEdad_semanas());
            mascotaDTO.setSexo(mascotaActualizada.getSexo());
            mascotaDTO.setEstado_vital(mascotaActualizada.isEstado_vital());

            // obtiene raza y especie asociadas
            Raza razaMascota = objDao.getById(
                    Raza.class,
                    "razas",
                    mascotaActualizada.getId_raza()
            );
            Especie especieRaza = objDao.getById(
                    Especie.class,
                    "especies",
                    razaMascota.getId_especie()
            );
            RazaResponseDTO razaDTO = new RazaResponseDTO();
            razaDTO.setId(razaMascota.getId());
            razaDTO.setNombre(razaMascota.getNombre());
            razaDTO.setEspecie(especieRaza);
            mascotaDTO.setRaza(razaDTO);

            // obtiene y asigna informacion del propietario
            Cliente cliente = objDao.getById(
                    Cliente.class,
                    "clientes",
                    mascotaActualizada.getId_cliente()
            );
            ClienteResponseDTO clienteDTO
                    = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
            mascotaDTO.setCliente(clienteDTO);

            // formatea la edad en semanas a representacion legible
            String edadFormateada
                    = MascotaUtils.formatearEdad(mascotaActualizada.getEdad_semanas());
            mascotaDTO.setEdadFormateada(edadFormateada);

            // retorna 200 con el DTO de la mascota actualizada
            return new ResponseProvider(
                    true,
                    200,
                    "Mascota actualizada exitosamente",
                    mascotaDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepciones inesperadas
            return new ResponseProvider(
                    false,
                    500,
                    "Error al actualizar la mascota",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Desactiva una mascota marcandola como no viva (estado_vital = false).
     *
     * @param idMascota ID de la mascota a desactivar
     * @return Response indicando si la desactivacion fue exitosa o no
     */
    @PUT
    @Path("/desactivar/{idMascota}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response desactivarMascota(@PathParam("idMascota") int idMascota) {
        try {
            // instancia MascotaDAO para operaciones especializadas
            MascotaDAO mascotaDao = new MascotaDAO();

            // intenta desactivar la mascota
            boolean exito = mascotaDao.desactivarMascota(idMascota);
            if (!exito) {
                return new ResponseProvider(
                        false,
                        404,
                        "No se encontro la mascota a desactivar",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 si la desactivacion fue satisfactoria
            return new ResponseProvider(
                    true,
                    200,
                    "Mascota desactivada correctamente",
                    null,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepciones inesperadas
            return new ResponseProvider(
                    false,
                    500,
                    "Error al desactivar la mascota",
                    e,
                    null
            ).toResponse();
        }
    }

}
