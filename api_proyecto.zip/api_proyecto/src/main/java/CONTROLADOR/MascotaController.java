package CONTROLADOR;

import MODELO.AntecedenteDAO;
import MODELO.Cliente;
import MODELO.ClienteResponseDTO;
import MODELO.CrudDAO;
import MODELO.Especie;
import MODELO.Mascota;
import MODELO.MascotaResponseDTO;
import MODELO.MascotaUtils;
import MODELO.Raza;
import MODELO.RazaResponseDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import modelo.ClienteDtoBuilder;

/**
 *
 * @author Propietario
 */
@Path("mascotas")
public class MascotaController {
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllMascotas() {
        try {
            final CrudDAO objDao = new CrudDAO();
            final List<Mascota> mascotas = objDao.getAll(Mascota.class, "mascotas");
            
            // Validamos si existen mascotas
            if (mascotas.isEmpty())
                return new ResponseProvider(false, 404, "No hay mascotas registradas", null, null).toResponse();
            
            List<MascotaResponseDTO> listaMascotasDTO = new ArrayList<>();
            
            for (Mascota m : mascotas) {
                MascotaResponseDTO mascotaDTO = new MascotaResponseDTO();
                mascotaDTO.setId(m.getId());
                mascotaDTO.setNombre(m.getNombre());
                mascotaDTO.setEdad_semanas(m.getEdad_semanas());
                mascotaDTO.setSexo(m.getSexo());                
                mascotaDTO.setEstado_vital(m.getEstado_vital());      
                mascotaDTO.setUltimo_registro(AntecedenteDAO.getUltimaFechaAntecedenteByIdMascota(m.getId()));
                
                Raza razaMascota = objDao.getById(Raza.class, "razas", m.getId_raza());
                Especie especieRaza = objDao.getById(Especie.class, "especies", razaMascota.getId_especie());
                
                RazaResponseDTO razaDTO = new RazaResponseDTO();
                razaDTO.setId(razaMascota.getId());
                razaDTO.setNombre(razaMascota.getNombre()); 
                razaDTO.setEspecie(especieRaza);
                
                mascotaDTO.setRaza(razaDTO);
                
                //Obtenemos y asignamos informacion del propietario
                Cliente cliente = objDao.getById(Cliente.class, "clientes", m.getId_cliente());
                
                ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
                
                //Se obtiene y se asigna el nombre del propietario de la mascota
                mascotaDTO.setCliente(clienteDTO);
                //Se obtiene y se le asigna el telefono del propietario
                String edadFormateada = MascotaUtils.formatearEdad(m.getEdad_semanas());
                mascotaDTO.setEdadFormateada(edadFormateada);
                
                listaMascotasDTO.add(mascotaDTO);
            }
            
            return new ResponseProvider(true, 200, "Mascotas obtenidas correctamente", listaMascotasDTO, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener las mascotas", e, null).toResponse(); 
        }
    }
    
    @GET
    @Path("/{idMascota}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMascotaById(@PathParam("idMascota") int idMascota) {
        try {
            final CrudDAO objDao = new CrudDAO();
            Mascota mascota = objDao.getById(Mascota.class, "mascotas", idMascota);
            
            // Validamos si existen mascotas
            if (mascota == null)
                return new ResponseProvider(false, 404, "No hay mascotas registradas", null, null).toResponse();
            

            MascotaResponseDTO mascotaDTO = new MascotaResponseDTO();
            mascotaDTO.setId(mascota.getId());
            mascotaDTO.setNombre(mascota.getNombre());
            mascotaDTO.setEdad_semanas(mascota.getEdad_semanas());
            mascotaDTO.setSexo(mascota.getSexo());                
            mascotaDTO.setEstado_vital(mascota.getEstado_vital());                                

            Raza razaMascota = objDao.getById(Raza.class, "razas", mascota.getId_raza());
            Especie especieRaza = objDao.getById(Especie.class, "especies", razaMascota.getId_especie());

            RazaResponseDTO razaDTO = new RazaResponseDTO();
            razaDTO.setId(razaMascota.getId());
            razaDTO.setNombre(razaMascota.getNombre()); 
            razaDTO.setEspecie(especieRaza);

            mascotaDTO.setRaza(razaDTO);

            //Obtenemos y asignamos informacion del propietario
            Cliente cliente = objDao.getById(Cliente.class, "clientes", mascota.getId_cliente());

            ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);

            //Se obtiene y se asigna el nombre del propietario de la mascota
            mascotaDTO.setCliente(clienteDTO);
            //Se obtiene y se le asigna el telefono del propietario
            String edadFormateada = MascotaUtils.formatearEdad(mascota.getEdad_semanas());
            mascotaDTO.setEdadFormateada(edadFormateada);
            
            
            return new ResponseProvider(true, 200, "Mascota obtenida correctamente", mascotaDTO, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener las mascotas", e, null).toResponse(); 
        }
    }
    
    @GET
    @Path("/cliente/{idCliente}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMascotasByClienteId(@PathParam("idCliente") int idCliente) {
        try {
//            MascotaDAO mascotaDao = new MascotaDAO();
            CrudDAO objDao = new CrudDAO();

            List<Mascota> mascotas = objDao.getAllByField(Mascota.class, "mascotas", "id_cliente", idCliente);
            if (mascotas.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay mascotas registradas para este cliente", null, null).toResponse();
            }

            
            //ESTO SE PODRIA HACER UN DTO BUILDER
            List<MascotaResponseDTO> listaMascotasDTO = new ArrayList<>();
            
            for (Mascota m : mascotas) {
                MascotaResponseDTO mascotaDTO = new MascotaResponseDTO();
                mascotaDTO.setId(m.getId());
                mascotaDTO.setNombre(m.getNombre());
                mascotaDTO.setEdad_semanas(m.getEdad_semanas());
                mascotaDTO.setSexo(m.getSexo());                
                mascotaDTO.setEstado_vital(m.getEstado_vital());                                
                
                Raza razaMascota = objDao.getById(Raza.class, "razas", m.getId_raza());
                Especie especieRaza = objDao.getById(Especie.class, "especies", razaMascota.getId_especie());
                
                RazaResponseDTO razaDTO = new RazaResponseDTO();
                razaDTO.setId(razaMascota.getId());
                razaDTO.setNombre(razaMascota.getNombre()); 
                razaDTO.setEspecie(especieRaza);
                
                mascotaDTO.setRaza(razaDTO);
                
                //Obtenemos y asignamos informacion del propietario
                Cliente cliente = objDao.getById(Cliente.class, "clientes", m.getId_cliente());
                
                ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
                
                //Se obtiene y se asigna el nombre del propietario de la mascota
                mascotaDTO.setCliente(clienteDTO);
                //Se obtiene y se le asigna el telefono del propietario
                String edadFormateada = MascotaUtils.formatearEdad(m.getEdad_semanas());
                mascotaDTO.setEdadFormateada(edadFormateada);
                
                listaMascotasDTO.add(mascotaDTO);
            }
            //FIN DEL DTO BUILDER
            
            return new ResponseProvider(true, 200, "Mascotas del cliente obtenidas correctamente", listaMascotasDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener las mascotas del cliente", e, null).toResponse();
        }
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMascota(Mascota nuevaMascota) {
        try {
            CrudDAO objDao = new CrudDAO();
            Mascota mascotaCreada = objDao.create("mascotas", nuevaMascota);

            if (mascotaCreada == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar la mascota", null, null).toResponse();
            }
            
            MascotaResponseDTO mascotaDTO = new MascotaResponseDTO();
            mascotaDTO.setId(mascotaCreada.getId());
            mascotaDTO.setNombre(mascotaCreada.getNombre());
            mascotaDTO.setEdad_semanas(mascotaCreada.getEdad_semanas());
            mascotaDTO.setSexo(mascotaCreada.getSexo());                
            mascotaDTO.setEstado_vital(mascotaCreada.getEstado_vital());                                

            Raza razaMascota = objDao.getById(Raza.class, "razas", mascotaCreada.getId_raza());
            Especie especieRaza = objDao.getById(Especie.class, "especies", razaMascota.getId_especie());

            RazaResponseDTO razaDTO = new RazaResponseDTO();
            razaDTO.setId(razaMascota.getId());
            razaDTO.setNombre(razaMascota.getNombre()); 
            razaDTO.setEspecie(especieRaza);

            mascotaDTO.setRaza(razaDTO);

            //Obtenemos y asignamos informacion del propietario
            Cliente cliente = objDao.getById(Cliente.class, "clientes", mascotaCreada.getId_cliente());

            ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);

            //Se obtiene y se asigna el nombre del propietario de la mascota
            mascotaDTO.setCliente(clienteDTO);
            //Se obtiene y se le asigna el telefono del propietario
            String edadFormateada = MascotaUtils.formatearEdad(mascotaCreada.getEdad_semanas());
            mascotaDTO.setEdadFormateada(edadFormateada);
            
            return new ResponseProvider(true, 201, "Mascota registrada exitosamente", mascotaDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar la mascota", e, null).toResponse();
        }
    }
}
