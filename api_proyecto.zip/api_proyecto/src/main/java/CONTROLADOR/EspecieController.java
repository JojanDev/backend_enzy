package CONTROLADOR;

import MODELO.DAO.CrudDAO;
import MODELO.Especie;
import MODELO.DTO.EspecieConRazasGetResponseDTO;
import MODELO.Raza;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

/**
 * Controlador REST para gestionar operaciones relacionadas con especies.
 * Permite consultar, crear, actualizar y eliminar especies, así como obtener
 * sus razas asociadas.
 */
@Path("especies")
public class EspecieController {

    /**
     * Obtiene todas las especies registradas junto con sus razas asociadas.
     *
     * @return Respuesta con lista de especies y sus razas, o mensaje de error
     * si no hay registros.
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getEspeciesConRazas() {
        try {
            CrudDAO dao = new CrudDAO();
            List<Especie> especies = dao.getAll(Especie.class, "especies");

            if (especies.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay especies registradas", null, null).toResponse();
            }

            List<EspecieConRazasGetResponseDTO> especiesConRazas = new ArrayList<>();

            // Recorre cada especie y consulta sus razas asociadas
            for (Especie e : especies) {
                List<Raza> razas = dao.getAllByField(Raza.class, "razas", "id_especie", e.getId());
                especiesConRazas.add(new EspecieConRazasGetResponseDTO(e.getId(), e.getNombre(), razas));
            }

            return new ResponseProvider(true, 200, "Especies con razas obtenidas correctamente", especiesConRazas, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener especies con razas", null, List.of(e.getMessage())).toResponse();
        }
    }

    /**
     * Obtiene una especie por su ID.
     *
     * @param idEspecie ID de la especie a consultar.
     * @return Respuesta con la especie encontrada o mensaje de error si no
     * existe.
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getEspecieById(@PathParam("id") int idEspecie) {
        try {
            CrudDAO objDao = new CrudDAO();
            Especie especie = objDao.getById(Especie.class, "especies", idEspecie);

            if (especie == null) {
                return new ResponseProvider(false, 404, "Especie no encontrada", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Especie obtenida correctamente", especie, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener la especie", e, null).toResponse();
        }
    }

    /**
     * Crea una nueva especie en la base de datos.
     *
     * @param nuevaEspecie Objeto recibido desde el cliente.
     * @return Respuesta con la especie creada o mensaje de error.
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createEspecie(Especie nuevaEspecie) {
        try {
            CrudDAO objDao = new CrudDAO();
            Especie especieCreada = objDao.create("especies", nuevaEspecie);

            if (especieCreada == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar la especie", null, null).toResponse();
            }

            return new ResponseProvider(true, 201, "Especie registrada exitosamente", especieCreada, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar la especie", e, null).toResponse();
        }
    }

    /**
     * Actualiza los datos de una especie existente.
     *
     * @param id ID de la especie a actualizar.
     * @param especieActualizada Objeto con los nuevos valores.
     * @return Respuesta indicando si la actualización fue exitosa.
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateEspecie(@PathParam("id") int id, Especie especieActualizada) {
        try {
            CrudDAO objDao = new CrudDAO();

            especieActualizada.setId(id);

            if (especieActualizada.getId() == 0) {
                return new ResponseProvider(false, 400, "El ID de la especie es obligatorio para actualizar", null, null).toResponse();
            }

            Especie especieExistente = objDao.getById(Especie.class, "especies", especieActualizada.getId());

            if (especieExistente == null) {
                return new ResponseProvider(false, 404, "La especie con ese ID no existe", null, null).toResponse();
            }

            boolean actualizada = objDao.update(especieActualizada, "especies", "id");

            if (!actualizada) {
                return new ResponseProvider(false, 400, "No se pudo actualizar la especie", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Especie actualizada exitosamente", especieActualizada, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar la especie", e, null).toResponse();
        }
    }

    /**
     * Elimina una especie si no tiene razas asociadas.
     *
     * @param id ID de la especie a eliminar.
     * @return Respuesta indicando si la eliminación fue exitosa.
     */
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteEspecie(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO();

            Especie especieExistente = objDao.getById(Especie.class, "especies", id);
            if (especieExistente == null) {
                return new ResponseProvider(false, 404, "La especie no existe", null, null).toResponse();
            }

            // Verifica si hay razas asociadas a la especie
            List<Raza> especiesAsociadas = objDao.getAllByField(Raza.class, "razas", "id_especie", especieExistente.getId());

            if (!especiesAsociadas.isEmpty()) {
                return new ResponseProvider(false, 400, "La especie tiene razas asociadas", null, null).toResponse();
            }

            boolean eliminado = objDao.delete(id, "especies", "id");

            if (!eliminado) {
                return new ResponseProvider(false, 400, "No se pudo eliminar la especie", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Especie eliminada exitosamente", null, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al eliminar la especie", e, null).toResponse();
        }
    }
}
