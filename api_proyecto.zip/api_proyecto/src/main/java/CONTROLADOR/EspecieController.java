/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.CrudDAO;
import MODELO.Especie;
import MODELO.EspecieConRazasGetResponseDTO;
import MODELO.Raza;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
@Path("especies")
public class EspecieController {
  
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getEspeciesConRazas() {
        try {
            CrudDAO dao = new CrudDAO();    
            List<Especie> especies = dao.getAll(Especie.class, "especies");

            if (especies.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay especies registradas", null, null).toResponse();
            }

            List<EspecieConRazasGetResponseDTO> especiesConRazas = new ArrayList<>();

            for (Especie e : especies) {
                List<Raza> razas = dao.getAllByField(Raza.class, "razas", "id_especie", e.getId());
                especiesConRazas.add(new EspecieConRazasGetResponseDTO(e.getId(), e.getNombre(), razas));
            }

            return new ResponseProvider(true, 200, "Especies con razas obtenidas correctamente", especiesConRazas, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener especies con razas", null, List.of(e.getMessage())).toResponse();
        }
    }
    
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getEspecieById(@PathParam("id") int idEspecie) {
        try {
            CrudDAO objDao = new CrudDAO();
            Especie especie = objDao.getById(Especie.class, "especies", idEspecie);
                
            if (especie == null) {
                return new ResponseProvider(false, 404, "Especie no encontrada", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Especie obtenido correctamente", especie, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener la especie", e, null).toResponse(); 
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createEspecie(Especie nuevaEspecie) {
        try {
            CrudDAO objDao = new CrudDAO();
            Especie especieCreada = objDao.create("especies", nuevaEspecie);

            if (especieCreada == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar la especie", null, null).toResponse();
            }
            
            return new ResponseProvider(true, 201, "Especie registrada exitosamente", especieCreada, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar la especie", e, null).toResponse();
        }
    }
    
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateEspecie(@PathParam("id") int id, Especie especieActualizada ) {
        try {
            CrudDAO objDao = new CrudDAO();

            especieActualizada.setId(id);
            // Validar si el ID está presente
            if (especieActualizada.getId() == 0) {
                return new ResponseProvider(false, 400, "El ID de la especie es obligatorio para actualizar", null, null).toResponse();
            }

            // Verificar si la especie existe antes de actualizar
            Especie especieExistente = objDao.getById(Especie.class, "especies", especieActualizada.getId());

            if (especieExistente == null) {
                return new ResponseProvider(false, 404, "La especie con ese ID no existe", null, null).toResponse();
            }

            boolean actualizada = objDao.update(especieActualizada, "especies", "id");

            if (!actualizada) {
                return new ResponseProvider(false, 400, "No se pudo actualizar la especie", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Especie actualizada exitosamente", especieActualizada, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar la especie", e, null).toResponse();
        }
    }
    
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteTipoProducto(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Verificar si el tipo de producto existe
            Especie especieExistente = objDao.getById(Especie.class, "especies", id);
            if (especieExistente == null) {
                return new ResponseProvider(false, 404, "La especie no existe", null, null).toResponse();
            }

            // Verificar si hay productos asociados a ese tipo
            List<Raza> especiesAsociadas = objDao.getAllByField(Raza.class, "razas", "id_especie", especieExistente.getId());

            if (!especiesAsociadas.isEmpty()) {
                return new ResponseProvider(false, 400, "La especie tiene razas asociadas", null, null).toResponse();
            }

            // Eliminar tipo de producto
            boolean eliminado = objDao.delete(id, "especies", "id");

            if (!eliminado) {
                return new ResponseProvider(false, 400, "No se pudo eliminar la especie", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Especie eliminada exitosamente", null, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al eliminar la especie", e, null).toResponse();
        }
    }

}
