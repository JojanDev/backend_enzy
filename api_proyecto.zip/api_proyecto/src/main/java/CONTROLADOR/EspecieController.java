package CONTROLADOR;

import MODELO.DAO.CrudDAO;
import MODELO.Especie;
import MODELO.DTO.EspecieResponseDTO;
import MODELO.Raza;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

/**
 * Controlador REST para gestionar operaciones relacionadas con especies.
 * Proporciona endpoints para:
 * - listar todas las especies con sus razas asociadas
 * - obtener una especie por su ID
 * - crear una nueva especie
 * - actualizar una especie existente
 * - eliminar una especie sin razas asociadas
 */
@Path("especies")
public class EspecieController {

    /**
     * Obtiene todas las especies registradas junto con sus razas asociadas.
     *
     * @return Response con lista de EspecieConRazasGetResponseDTO o error si no
     * hay registros
     */
    @GET
    public Response getEspeciesConRazas() {
        try {
            // Crea instancia de CrudDAO para operaciones CRUD
            CrudDAO dao = new CrudDAO();

            // Recupera todas las especies de la tabla 'especies'
            List<Especie> especies = dao.getAll(Especie.class, "especies");

            // Si no hay especies, retorna 404
            if (especies.isEmpty()) {
                return new ResponseProvider(
                        false,
                        404,
                        "No hay especies registradas",
                        null,
                        null
                ).toResponse();
            }

            // Lista para almacenar DTOs de especies con sus razas
            List<EspecieResponseDTO> especiesConRazas = new ArrayList<>();

            // Por cada especie, obtiene las razas asociadas y construye el DTO
            for (Especie e : especies) {
                // Consulta razas de esta especie
                List<Raza> razas = dao.getAllByField(
                        Raza.class,
                        "razas",
                        "id_especie",
                        e.getId()
                );
                // Agrega DTO con id, nombre y lista de razas
                especiesConRazas.add(new EspecieResponseDTO(
                                e.getId(),
                                e.getNombre(),
                                razas
                        )
                );
            }

            // Retorna 200 con la lista de DTOs construida
            return new ResponseProvider(
                    true,
                    200,
                    "Especies con razas obtenidas correctamente",
                    especiesConRazas,
                    null
            ).toResponse();

        } catch (Exception e) {
            // Retorna 500 en caso de excepcion inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener especies con razas",
                    null,
                    List.of(e.getMessage())
            ).toResponse();
        }
    }

    /**
     * Obtiene una especie por su ID.
     *
     * @param idEspecie ID de la especie a consultar
     * @return Response con la entidad Especie o error si no existe
     */
    @GET
    @Path("/{id}")
    public Response getEspecieById(@PathParam("id") int idEspecie) {
        try {
            // Crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // Recupera la especie por su ID
            Especie especie = objDao.getById(
                    Especie.class,
                    "especies",
                    idEspecie
            );

            // Si no existe, retorna 404
            if (especie == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "Especie no encontrada",
                        null,
                        null
                ).toResponse();
            }

            // Retorna 200 con la especie encontrada
            return new ResponseProvider(
                    true,
                    200,
                    "Especie obtenida correctamente",
                    especie,
                    null
            ).toResponse();

        } catch (Exception e) {
            // Retorna 500 en caso de error durante la consulta
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener la especie",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Crea una nueva especie en la base de datos.
     *
     * @param nuevaEspecie objeto Especie recibido desde el cliente
     * @return Response con la entidad creada o error si la insercion falla
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createEspecie(Especie nuevaEspecie) {
        try {
            // Crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // Inserta la nueva especie y obtiene la entidad insertada
            Especie especieCreada = objDao.create("especies", nuevaEspecie);

            // Si falla la insercion, retorna 400
            if (especieCreada == null) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo registrar la especie",
                        null,
                        null
                ).toResponse();
            }

            // Retorna 201 con la especie creada
            return new ResponseProvider(
                    true,
                    201,
                    "Especie registrada exitosamente",
                    especieCreada,
                    null
            ).toResponse();

        } catch (Exception e) {
            // Retorna 500 en caso de excepcion inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al registrar la especie",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Actualiza los datos de una especie existente.
     *
     * @param id ID de la especie a actualizar
     * @param especieActualizada objeto Especie con los nuevos valores
     * @return Response indicando si la actualizacion fue exitosa o no
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updateEspecie(
            @PathParam("id") int id,
            Especie especieActualizada) {
        try {
            // Crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // Asigna el ID recibido al objeto que se actualizara
            especieActualizada.setId(id);

            // Validacion: el ID debe ser mayor que cero
            if (especieActualizada.getId() == 0) {
                return new ResponseProvider(
                        false,
                        400,
                        "El ID de la especie es obligatorio para actualizar",
                        null,
                        null
                ).toResponse();
            }

            // Verifica que la especie exista en la base de datos
            Especie especieExistente = objDao.getById(
                    Especie.class,
                    "especies",
                    id
            );
            // Si no existe, retorna 404
            if (especieExistente == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "La especie con ese ID no existe",
                        null,
                        null
                ).toResponse();
            }

            // Ejecuta la actualizacion en la tabla 'especies'
            boolean actualizada = objDao.update(
                    especieActualizada,
                    "especies",
                    "id"
            );
            // Si no se actualizo, retorna 400
            if (!actualizada) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo actualizar la especie",
                        null,
                        null
                ).toResponse();
            }

            // Retorna 200 con la entidad actualizada
            return new ResponseProvider(
                    true,
                    200,
                    "Especie actualizada exitosamente",
                    especieActualizada,
                    null
            ).toResponse();

        } catch (Exception e) {
            // Retorna 500 en caso de error durante la actualizacion
            return new ResponseProvider(
                    false,
                    500,
                    "Error al actualizar la especie",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Elimina una especie si no tiene razas asociadas.
     *
     * @param id ID de la especie a eliminar
     * @return Response indicando si la eliminacion fue exitosa o detallando el
     * error
     */
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteEspecie(@PathParam("id") int id) {
        try {
            // Instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // Verifica si la especie existe en la base de datos
            Especie especieExistente = objDao.getById(
                    Especie.class,
                    "especies",
                    id
            );
            if (especieExistente == null) {
                // Retorna 404 si no se encontro la especie
                return new ResponseProvider(
                        false,
                        404,
                        "La especie no existe",
                        null,
                        null
                ).toResponse();
            }

            // Recupera la lista de razas asociadas a esta especie
            List<Raza> especiesAsociadas = objDao.getAllByField(
                    Raza.class,
                    "razas",
                    "id_especie",
                    especieExistente.getId()
            );
            if (!especiesAsociadas.isEmpty()) {
                // Retorna 400 si hay razas vinculadas a la especie
                return new ResponseProvider(
                        false,
                        400,
                        "La especie tiene razas asociadas",
                        null,
                        null
                ).toResponse();
            }

            // Elimina la especie de la tabla 'especies'
            boolean eliminado = objDao.delete(
                    id,
                    "especies",
                    "id"
            );
            if (!eliminado) {
                // Retorna 400 si la eliminacion fallo
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo eliminar la especie",
                        null,
                        null
                ).toResponse();
            }

            // Retorna 200 cuando la eliminacion fue exitosa
            return new ResponseProvider(
                    true,
                    200,
                    "Especie eliminada exitosamente",
                    null,
                    null
            ).toResponse();

        } catch (Exception e) {
            // Retorna 500 en caso de excepcion inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al eliminar la especie",
                    e,
                    null
            ).toResponse();
        }
    }

}
