/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.CrudDAO;
import MODELO.Especie;
import MODELO.EspecieConRazasGetResponseDTO;
import MODELO.Raza;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
@Path("especies")
public class EspecieController {
  
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getEspeciesConRazas() {
        try {
            CrudDAO dao = new CrudDAO();    
            List<Especie> especies = dao.getAll(Especie.class, "especies");

            if (especies.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay especies registradas", null, null).toResponse();
            }

            List<EspecieConRazasGetResponseDTO> especiesConRazas = new ArrayList<>();

            for (Especie e : especies) {
                List<Raza> razas = dao.getAllByField(Raza.class, "razas", "id_especie", e.getId());
                especiesConRazas.add(new EspecieConRazasGetResponseDTO(e.getId(), e.getNombre(), razas));
            }

            return new ResponseProvider(true, 200, "Especies con razas obtenidas correctamente", especiesConRazas, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener especies con razas", null, List.of(e.getMessage())).toResponse();
        }
    }

}
