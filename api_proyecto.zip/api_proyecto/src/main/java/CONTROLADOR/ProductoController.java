package CONTROLADOR;

import MODELO.DAO.CrudDAO;
import MODELO.Producto;
import MODELO.DTO.ProductoResponseDTO;
import MODELO.TipoProducto;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

/**
 * Controlador REST para la gestión de productos. Proporciona operaciones CRUD
 * (crear, leer, actualizar) sobre productos, y devuelve respuestas
 * estandarizadas en formato JSON mediante ResponseProvider.
 *
 * Los productos pueden incluir información del tipo de producto al que
 * pertenecen.
 */
@Path("productos")
public class ProductoController {

    /**
     * Obtiene todos los productos registrados. Cada producto se transforma a un
     * DTO que incluye su tipo de producto.
     *
     * @return Response con la lista de productos o un mensaje de error si no
     * hay registros
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllProductos() {
        try {
            CrudDAO objDao = new CrudDAO();

            List<Producto> productos = objDao.getAll(Producto.class, "productos");

            if (productos.isEmpty()) {
                // No hay productos registrados
                return new ResponseProvider(false, 404, "No hay productos registrados", null, null).toResponse();
            }

            List<ProductoResponseDTO> productosDTO = new ArrayList<>();

            for (Producto p : productos) {
                ProductoResponseDTO productoDTO = new ProductoResponseDTO();

                // Mapear campos básicos del producto
                productoDTO.setId(p.getId());
                productoDTO.setNombre(p.getNombre());
                productoDTO.setPrecio(p.getPrecio());
                productoDTO.setDescripcion(p.getDescripcion());
                productoDTO.setFecha_caducidad(p.getFecha_caducidad());
                productoDTO.setStock(p.getStock());

                // Obtener información del tipo de producto
                TipoProducto tipoProducto = objDao.getById(TipoProducto.class, "tipos_productos", p.getId_tipo());

                if (tipoProducto != null) {
                    productoDTO.setTipoProducto(tipoProducto);
                }

                productosDTO.add(productoDTO);
            }

            return new ResponseProvider(true, 200, "Productos obtenidos correctamente", productosDTO, null).toResponse();
        } catch (Exception e) {
            // Manejo de errores internos
            return new ResponseProvider(false, 500, "Error al obtener los productos", e, null).toResponse();
        }
    }

    /**
     * Obtiene un producto específico por su ID. Devuelve un DTO que incluye su
     * tipo de producto.
     *
     * @param idProducto ID del producto a consultar
     * @return Response con el producto o mensaje de error si no existe
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getProductoById(@PathParam("id") int idProducto) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Obtener el producto por ID
            Producto producto = objDao.getById(Producto.class, "productos", idProducto);

            if (producto == null) {
                // Producto no encontrado
                return new ResponseProvider(false, 404, "No se encontró el producto con el ID especificado", null, null).toResponse();
            }

            // Mapear a DTO
            ProductoResponseDTO productoDTO = new ProductoResponseDTO();
            productoDTO.setId(producto.getId());
            productoDTO.setNombre(producto.getNombre());
            productoDTO.setPrecio(producto.getPrecio());
            productoDTO.setDescripcion(producto.getDescripcion());
            productoDTO.setFecha_caducidad(producto.getFecha_caducidad());
            productoDTO.setStock(producto.getStock());

            // Obtener tipo de producto
            TipoProducto tipoProducto = objDao.getById(TipoProducto.class, "tipos_productos", producto.getId_tipo());
            if (tipoProducto != null) {
                productoDTO.setTipoProducto(tipoProducto);
            }

            return new ResponseProvider(true, 200, "Producto obtenido correctamente", productoDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener el producto", e, null).toResponse();
        }
    }

    /**
     * Crea un nuevo producto en la base de datos. Devuelve un DTO que incluye
     * su tipo de producto.
     *
     * @param nuevoProducto Objeto con la información del producto a registrar
     * @return Response con el producto registrado o mensaje de error
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createProducto(Producto nuevoProducto) {
        try {
            CrudDAO objDao = new CrudDAO();
            Producto productoCreado = objDao.create("productos", nuevoProducto);

            if (productoCreado == null) {
                // No se pudo registrar el producto
                return new ResponseProvider(false, 400, "No se pudo registrar el producto", null, null).toResponse();
            }

            // Mapear a DTO
            ProductoResponseDTO productoDTO = new ProductoResponseDTO();
            productoDTO.setId(productoCreado.getId());
            productoDTO.setNombre(productoCreado.getNombre());
            productoDTO.setPrecio(productoCreado.getPrecio());
            productoDTO.setDescripcion(productoCreado.getDescripcion());
            productoDTO.setFecha_caducidad(productoCreado.getFecha_caducidad());
            productoDTO.setStock(productoCreado.getStock());

            TipoProducto tipoProducto = objDao.getById(TipoProducto.class, "tipos_productos", productoCreado.getId_tipo());
            if (tipoProducto != null) {
                productoDTO.setTipoProducto(tipoProducto);
            }

            return new ResponseProvider(true, 201, "Producto registrado exitosamente", productoDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar el producto", e, null).toResponse();
        }
    }

    /**
     * Actualiza un producto existente por su ID.
     *
     * @param idProducto ID del producto a actualizar
     * @param productoActualizado Objeto con los nuevos valores del producto
     * @return Response con el producto actualizado o mensaje de error
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateProducto(@PathParam("id") int idProducto, Producto productoActualizado) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Verificar existencia del producto
            Producto productoExistente = objDao.getById(Producto.class, "productos", idProducto);
            if (productoExistente == null) {
                return new ResponseProvider(false, 404, "No se encontró el producto con el ID especificado", null, null).toResponse();
            }

            // Asegurar que el ID del producto actualizado coincida con el ID del path
            productoActualizado.setId(idProducto);

            // Actualizar en la base de datos
            boolean actualizado = objDao.update(productoActualizado, "productos", "id");

            if (!actualizado) {
                return new ResponseProvider(false, 400, "No se pudo actualizar el producto", null, null).toResponse();
            }

            // Mapear a DTO para la respuesta
            ProductoResponseDTO productoDTO = new ProductoResponseDTO();
            productoDTO.setId(productoActualizado.getId());
            productoDTO.setNombre(productoActualizado.getNombre());
            productoDTO.setPrecio(productoActualizado.getPrecio());
            productoDTO.setDescripcion(productoActualizado.getDescripcion());
            productoDTO.setFecha_caducidad(productoActualizado.getFecha_caducidad());
            productoDTO.setStock(productoActualizado.getStock());

            TipoProducto tipoProducto = objDao.getById(TipoProducto.class, "tipos_productos", productoActualizado.getId_tipo());
            if (tipoProducto != null) {
                productoDTO.setTipoProducto(tipoProducto);
            }

            return new ResponseProvider(true, 200, "Producto actualizado exitosamente", productoDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar el producto", e, null).toResponse();
        }
    }

}
