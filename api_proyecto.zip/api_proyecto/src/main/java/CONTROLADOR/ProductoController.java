/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.CrudDAO;
import MODELO.Producto;
import MODELO.ProductoResponseDTO;
import MODELO.TipoProducto;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
@Path("productos")
public class ProductoController {
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllProductos() {
        try {
            CrudDAO objDao = new CrudDAO();
            
            List<Producto> productos = objDao.getAll(Producto.class, "productos");
                
            if (productos.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay productos registrados", null, null).toResponse();
            }
            
             List<ProductoResponseDTO> productosDTO = new ArrayList<>();

           for (Producto p : productos) {
               ProductoResponseDTO productoDTO = new ProductoResponseDTO();

               productoDTO.setId(p.getId());
               productoDTO.setNombre(p.getNombre());
               productoDTO.setPrecio(p.getPrecio());
               productoDTO.setDescripcion(p.getDescripcion());
               productoDTO.setFecha_caducidad(p.getFecha_caducidad());
               productoDTO.setStock(p.getStock());
               

               TipoProducto tipoProducto = objDao.getById(TipoProducto.class, "tipos_productos", p.getId_tipo());
               
               if (tipoProducto == null) {
                   productosDTO.add(productoDTO);
                   continue;
               }

                productoDTO.setTipoProducto(tipoProducto);

                productosDTO.add(productoDTO);
           }

            return new ResponseProvider(true, 200, "Productos obtenidos correctamente", productosDTO, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los productos", e, null).toResponse(); 
        }
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createProducto(Producto nuevoProducto) {
        try {
            CrudDAO objDao = new CrudDAO();
            Producto productoCreado = objDao.create(Producto.class, "productos", nuevoProducto);

            if (productoCreado == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar el producto", null, null).toResponse();
            }
            
            ProductoResponseDTO productoDTO = new ProductoResponseDTO();

            productoDTO.setId(productoCreado.getId());
            productoDTO.setNombre(productoCreado.getNombre());
            productoDTO.setPrecio(productoCreado.getPrecio());
            productoDTO.setDescripcion(productoCreado.getDescripcion());
            productoDTO.setFecha_caducidad(productoCreado.getFecha_caducidad());
            productoDTO.setStock(productoCreado.getStock());


            TipoProducto tipoProducto = objDao.getById(TipoProducto.class, "tipos_productos", productoCreado.getId_tipo());

            if (tipoProducto != null)
                productoDTO.setTipoProducto(tipoProducto);
            

            return new ResponseProvider(true, 201, "Producto registrado exitosamente", productoDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar el producto", e, null).toResponse();
        }
    }
}
