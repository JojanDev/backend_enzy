package CONTROLADOR;

import MODELO.DAO.CrudDAO;
import MODELO.Producto;
import MODELO.DTO.ProductoResponseDTO;
import MODELO.TipoProducto;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

/**
 * Controlador REST para la gestión de productos.
 * Proporciona endpoints para:
 * - listar todos los productos registrados con su tipo de producto
 * - obtener un producto específico por su ID
 * - crear un nuevo producto en la base de datos
 * - actualizar un producto existente por su ID
 *
 * Utiliza ResponseProvider para devolver respuestas JSON estandarizadas.
 */
@Path("productos")
public class ProductoController {

    /**
     * Obtiene todos los productos registrados. Cada producto se transforma a un
     * DTO que incluye su tipo de producto.
     *
     * @return Response con la lista de ProductoResponseDTO o mensaje de error
     * si no hay registros
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllProductos() {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera todos los productos de la tabla 'productos'
            List<Producto> productos = objDao.getAll(Producto.class, "productos");

            // si no hay productos registrados, retorna 404
            if (productos.isEmpty()) {
                return new ResponseProvider(
                        false,
                        404,
                        "No hay productos registrados",
                        null,
                        null
                ).toResponse();
            }

            // lista para almacenar los DTO de respuesta
            List<ProductoResponseDTO> productosDTO = new ArrayList<>();

            // recorre cada entidad Producto para mapearla a DTO
            for (Producto p : productos) {
                ProductoResponseDTO productoDTO = new ProductoResponseDTO();

                // asigna campos básicos del producto al DTO
                productoDTO.setId(p.getId());
                productoDTO.setNombre(p.getNombre());
                productoDTO.setPrecio(p.getPrecio());
                productoDTO.setDescripcion(p.getDescripcion());
                productoDTO.setFecha_caducidad(p.getFecha_caducidad());
                productoDTO.setStock(p.getStock());

                // obtiene el tipo de producto asociado por su ID
                TipoProducto tipoProducto = objDao.getById(
                        TipoProducto.class,
                        "tipos_productos",
                        p.getId_tipo()
                );
                // si existe, asigna al DTO
                if (tipoProducto != null) {
                    productoDTO.setTipoProducto(tipoProducto);
                }

                // agrega el DTO a la lista de respuesta
                productosDTO.add(productoDTO);
            }

            // retorna 200 con la lista completa de productos
            return new ResponseProvider(
                    true,
                    200,
                    "Productos obtenidos correctamente",
                    productosDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de error inesperado
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener los productos",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Obtiene un producto específico por su ID. Devuelve un DTO que incluye su
     * tipo de producto.
     *
     * @param idProducto ID del producto a consultar
     * @return Response con ProductoResponseDTO o mensaje de error si no existe
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getProductoById(@PathParam("id") int idProducto) {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera la entidad Producto por su ID
            Producto producto = objDao.getById(
                    Producto.class,
                    "productos",
                    idProducto
            );

            // si no se encuentra, retorna 404
            if (producto == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "No se encontró el producto con el ID especificado",
                        null,
                        null
                ).toResponse();
            }

            // construye el DTO de respuesta con los campos del producto
            ProductoResponseDTO productoDTO = new ProductoResponseDTO();
            productoDTO.setId(producto.getId());
            productoDTO.setNombre(producto.getNombre());
            productoDTO.setPrecio(producto.getPrecio());
            productoDTO.setDescripcion(producto.getDescripcion());
            productoDTO.setFecha_caducidad(producto.getFecha_caducidad());
            productoDTO.setStock(producto.getStock());

            // obtiene y asigna el tipo de producto asociado
            TipoProducto tipoProducto = objDao.getById(
                    TipoProducto.class,
                    "tipos_productos",
                    producto.getId_tipo()
            );
            if (tipoProducto != null) {
                productoDTO.setTipoProducto(tipoProducto);
            }

            // retorna 200 con el DTO del producto encontrado
            return new ResponseProvider(
                    true,
                    200,
                    "Producto obtenido correctamente",
                    productoDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de error inesperado
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener el producto",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Crea un nuevo producto en la base de datos. Devuelve un DTO que incluye
     * su tipo de producto.
     *
     * @param nuevoProducto Objeto Producto con datos a registrar
     * @return Response con ProductoResponseDTO o mensaje de error si la
     * inserción falla
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createProducto(Producto nuevoProducto) {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // inserta el nuevo producto en la tabla 'productos'
            Producto productoCreado = objDao.create("productos", nuevoProducto);

            // si la inserción falla, retorna 400
            if (productoCreado == null) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo registrar el producto",
                        null,
                        null
                ).toResponse();
            }

            // construye el DTO de respuesta con los datos del producto creado
            ProductoResponseDTO productoDTO = new ProductoResponseDTO();
            productoDTO.setId(productoCreado.getId());
            productoDTO.setNombre(productoCreado.getNombre());
            productoDTO.setPrecio(productoCreado.getPrecio());
            productoDTO.setDescripcion(productoCreado.getDescripcion());
            productoDTO.setFecha_caducidad(productoCreado.getFecha_caducidad());
            productoDTO.setStock(productoCreado.getStock());

            // obtiene y asigna el tipo de producto asociado
            TipoProducto tipoProducto = objDao.getById(
                    TipoProducto.class,
                    "tipos_productos",
                    productoCreado.getId_tipo()
            );
            if (tipoProducto != null) {
                productoDTO.setTipoProducto(tipoProducto);
            }

            // retorna 201 con el DTO del producto registrado
            return new ResponseProvider(
                    true,
                    201,
                    "Producto registrado exitosamente",
                    productoDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de error inesperado
            return new ResponseProvider(
                    false,
                    500,
                    "Error al registrar el producto",
                    e,
                    null
            ).toResponse();
        }
    }

        /**
     * Actualiza un producto existente por su ID.
     *
     * @param idProducto           ID del producto a actualizar
     * @param productoActualizado  Objeto Producto con los nuevos valores
     * @return Response con el producto actualizado o mensaje de error
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateProducto(
            @PathParam("id") int idProducto,
            Producto productoActualizado) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera el producto existente por su ID
            Producto productoExistente = objDao.getById(
                Producto.class,
                "productos",
                idProducto
            );
            // si no existe, retorna 404
            if (productoExistente == null) {
                return new ResponseProvider(
                    false,
                    404,
                    "No se encontró el producto con el ID especificado",
                    null,
                    null
                ).toResponse();
            }

            // asigna el ID del path al objeto que se va a actualizar
            productoActualizado.setId(idProducto);

            // ejecuta la actualización en la tabla 'productos'
            boolean actualizado = objDao.update(
                productoActualizado,
                "productos",
                "id"
            );
            // si la actualización falla, retorna 400
            if (!actualizado) {
                return new ResponseProvider(
                    false,
                    400,
                    "No se pudo actualizar el producto",
                    null,
                    null
                ).toResponse();
            }

            // construye el DTO de respuesta con los datos actualizados
            ProductoResponseDTO productoDTO = new ProductoResponseDTO();
            productoDTO.setId(productoActualizado.getId());
            productoDTO.setNombre(productoActualizado.getNombre());
            productoDTO.setPrecio(productoActualizado.getPrecio());
            productoDTO.setDescripcion(productoActualizado.getDescripcion());
            productoDTO.setFecha_caducidad(productoActualizado.getFecha_caducidad());
            productoDTO.setStock(productoActualizado.getStock());

            // obtiene el tipo de producto asociado para enriquecer el DTO
            TipoProducto tipoProducto = objDao.getById(
                TipoProducto.class,
                "tipos_productos",
                productoActualizado.getId_tipo()
            );
            if (tipoProducto != null) {
                productoDTO.setTipoProducto(tipoProducto);
            }

            // retorna 200 con el DTO del producto actualizado
            return new ResponseProvider(
                true,
                200,
                "Producto actualizado exitosamente",
                productoDTO,
                null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de excepción inesperada
            return new ResponseProvider(
                false,
                500,
                "Error al actualizar el producto",
                e,
                null
            ).toResponse();
        }
    }


}
