package CONTROLADOR;

import MODELO.Antecedente;
import MODELO.DTO.AntecedenteConTratamientosDTO;
import MODELO.DAO.AntecedenteDAO;
import MODELO.DTO.AntecedenteResponseDTO;
import MODELO.DAO.CrudDAO;
import MODELO.Tratamiento;
import MODELO.DTO.TratamientoDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Controlador REST para gestionar antecedentes de mascotas. Permite consultar,
 * crear y obtener antecedentes junto con sus tratamientos.
 */
@Path("antecedentes")
public class AntecedenteController {

    /**
     * Obtiene todos los antecedentes activos de una mascota, junto con sus
     * tratamientos activos.
     *
     * @param idMascota ID de la mascota.
     * @return Respuesta con lista de antecedentes y tratamientos activos.
     */
    @GET
    @Path("/mascota/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllAntecedentesByIdMascota(@PathParam("id") int idMascota) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Consulta todos los antecedentes de la mascota
            List<Antecedente> antecedentesMascota = objDao.getAllByField(
                    Antecedente.class, "antecedentes", "id_mascota", idMascota
            );

            // Filtra solo los antecedentes activos
            antecedentesMascota = antecedentesMascota.stream() // Se convierte la lista 'antecedentesMascota' en un Stream para poder procesarla con operaciones funcionales.
                    .filter(a -> Boolean.TRUE.equals(a.isActivo())) // Se filtran únicamente aquellos elementos cuyo campo 'activo' sea TRUE (se usa Boolean.TRUE.equals(...) para evitar NullPointerException si 'isActivo()' devuelve null).
                    .collect(Collectors.toList());                               // Se recolectan los resultados filtrados y se vuelven a guardar como una nueva lista.

            if (antecedentesMascota.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay antecedentes activos en la mascota", null, null).toResponse();
            }

            List<AntecedenteConTratamientosDTO> antecedentesConTratamientos = new ArrayList<>();

            // Recorre cada antecedente activo
            for (Antecedente a : antecedentesMascota) {
                AntecedenteConTratamientosDTO dto = new AntecedenteConTratamientosDTO();
                dto.setId(a.getId());
                dto.setTitulo(a.getTitulo());
                dto.setDiagnostico(a.getDiagnostico());
                dto.setFecha_creado(a.getFecha_creado());

                // Consulta tratamientos asociados al antecedente
                List<Tratamiento> tratamientos = objDao.getAllByField(
                        Tratamiento.class, "antecedentes_tratamientos", "id_antecedente", a.getId()
                );

                // Filtra tratamientos activos
                tratamientos = tratamientos.stream()
                        // Convierte la lista 'tratamientos' en un Stream para poder aplicar operaciones funcionales
                        .filter(t -> Boolean.TRUE.equals(t.isActivo()))
                        // Aplica un filtro al Stream: solo se mantienen los objetos 't' cuyo método 'isActivo()' devuelve TRUE
                        // Se usa 'Boolean.TRUE.equals(...)' en vez de 't.isActivo() == true' para evitar posibles NullPointerException
                        .collect(Collectors.toList());
                // Recoge los elementos filtrados y los convierte de nuevo en una lista, reemplazando la lista original

                // Si hay tratamientos activos, los mapea a DTO
                if (!tratamientos.isEmpty()) {
                    List<TratamientoDTO> tratamientosDTO = new ArrayList<>();
                    for (Tratamiento t : tratamientos) {
                        TratamientoDTO tDto = new TratamientoDTO();
                        tDto.setId(t.getId());
                        tDto.setTitulo(t.getTitulo());
                        tDto.setDescripcion(t.getDescripcion());
                        tDto.setFecha_creado(t.getFecha_creado());
                        tratamientosDTO.add(tDto);
                    }
                    dto.setTratamientos(tratamientosDTO);
                }

                antecedentesConTratamientos.add(dto);
            }

            return new ResponseProvider(true, 200, "Antecedentes con tratamientos activos obtenidos correctamente", antecedentesConTratamientos, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los antecedentes con sus tratamientos", e, null).toResponse();
        }
    }

    /**
     * Obtiene un antecedente por su ID, si está activo.
     *
     * @param idAntecedente ID del antecedente.
     * @return Respuesta con el antecedente encontrado.
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAntecedenteById(@PathParam("id") int idAntecedente) {
        try {
            CrudDAO objDao = new CrudDAO();

            Antecedente antecedente = objDao.getById(Antecedente.class, "antecedentes", idAntecedente);

            if (antecedente == null || !antecedente.isActivo()) {
                return new ResponseProvider(false, 404, "Antecedente no encontrado o inactivo", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Antecedente obtenido correctamente", antecedente, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener el antecedente", e, null).toResponse();
        }
    }

    /**
     * Crea un nuevo antecedente en la base de datos.
     *
     * @param nuevoAntecedente Objeto recibido desde el cliente.
     * @return Respuesta con el antecedente creado.
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createAntecedente(Antecedente nuevoAntecedente) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Se marca como activo por defecto
            nuevoAntecedente.setActivo(true);

            // Inserta el antecedente en la base de datos
            Antecedente creado = objDao.create("antecedentes", nuevoAntecedente);

            if (creado == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar el antecedente", null, null).toResponse();
            }

            // Consulta el antecedente recién creado para obtener campos como fecha
            Antecedente antecedenteBD = objDao.getById(Antecedente.class, "antecedentes", creado.getId());

            if (antecedenteBD == null) {
                return new ResponseProvider(false, 404, "Antecedente no encontrado", null, null).toResponse();
            }

            // Construye el DTO de respuesta
            AntecedenteResponseDTO dto = new AntecedenteResponseDTO();
            dto.setId(antecedenteBD.getId());
            dto.setTitulo(antecedenteBD.getTitulo());
            dto.setDiagnostico(antecedenteBD.getDiagnostico());
            dto.setFecha_creado(antecedenteBD.getFecha_creado());

            return new ResponseProvider(true, 201, "Antecedente registrado exitosamente", dto, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar el antecedente", e, null).toResponse();
        }
    }

    /**
     * Actualiza los campos de un antecedente existente. Solo se modifican los
     * campos enviados en la solicitud (título y diagnóstico).
     *
     * @param idAntecedente ID del antecedente a actualizar.
     * @param antecedenteRequest Objeto con los nuevos valores.
     * @return Respuesta con el antecedente actualizado o mensaje de error.
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateAntecedente(@PathParam("id") int idAntecedente, Antecedente antecedenteRequest) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Verifica si el antecedente existe y está activo
            Antecedente antecedenteBD = objDao.getById(Antecedente.class, "antecedentes", idAntecedente);

            if (antecedenteBD == null || !antecedenteBD.isActivo()) {
                return new ResponseProvider(false, 404, "Antecedente no encontrado o inactivo", null, null).toResponse();
            }

            // Actualiza solo los campos que fueron enviados en la solicitud
            if (antecedenteRequest.getTitulo() != null) {
                antecedenteBD.setTitulo(antecedenteRequest.getTitulo());
            }

            if (antecedenteRequest.getDiagnostico() != null) {
                antecedenteBD.setDiagnostico(antecedenteRequest.getDiagnostico());
            }

            // Guarda los cambios en la base de datos
            boolean actualizado = objDao.update(antecedenteBD, "antecedentes", "id");

            if (!actualizado) {
                return new ResponseProvider(false, 400, "No se pudo actualizar el antecedente", null, null).toResponse();
            }

            // Construye el DTO de respuesta con los datos actualizados
            AntecedenteResponseDTO antecedenteDTO = new AntecedenteResponseDTO();
            antecedenteDTO.setId(antecedenteBD.getId());
            antecedenteDTO.setFecha_creado(antecedenteBD.getFecha_creado());
            antecedenteDTO.setTitulo(antecedenteBD.getTitulo());
            antecedenteDTO.setDiagnostico(antecedenteBD.getDiagnostico());

            return new ResponseProvider(true, 200, "Antecedente actualizado exitosamente", antecedenteDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar el antecedente", e, null).toResponse();
        }
    }

    /**
     * Elimina logicamente un antecedente (SoftDelete), siempre que no tenga
     * tratamientos activos asociados.
     *
     * @param idAntecedente ID del antecedente a eliminar.
     * @return Respuesta indicando si la eliminación fue exitosa o no.
     */
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteAntecedente(@PathParam("id") int idAntecedente) {
        try {
            AntecedenteDAO antecedenteDAO = new AntecedenteDAO();

            // Intenta realizar el SoftDelete del antecedente
            boolean eliminado = antecedenteDAO.softDeleteAntecedente(idAntecedente);

            if (!eliminado) {
                return new ResponseProvider(false, 400,
                        "No se pudo eliminar el antecedente, puede tener tratamientos asociados o no existe",
                        null, null).toResponse();
            }

            return new ResponseProvider(true, 200,
                    "Antecedente eliminado correctamente",
                    null, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500,
                    "Error al eliminar el antecedente", e, null).toResponse();
        }
    }

}
