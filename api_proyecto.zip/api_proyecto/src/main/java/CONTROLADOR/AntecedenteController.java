package CONTROLADOR;

import MODELO.Antecedente;
import MODELO.DTO.AntecedenteConTratamientosDTO;
import MODELO.DAO.AntecedenteDAO;
import MODELO.DTO.AntecedenteResponseDTO;
import MODELO.DAO.CrudDAO;
import MODELO.Tratamiento;
import MODELO.DTO.TratamientoDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Controlador REST para gestionar antecedentes de mascotas.
 * Proporciona endpoints para:
 * - listar antecedentes activos de una mascota con sus tratamientos
 * - obtener un antecedente por su ID si esta activo
 * - crear un nuevo antecedente
 * - actualizar campos de un antecedente existente
 * - eliminar logicamente un antecedente
 */
@Path("antecedentes")
public class AntecedenteController {

    /**
     * Obtiene todos los antecedentes activos de una mascota, junto con sus
     * tratamientos activos.
     *
     * @param idMascota ID de la mascota
     * @return Response con lista de AntecedenteConTratamientosDTO o error
     */
    @GET
    @Path("/mascota/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllAntecedentesByIdMascota(
            @PathParam("id") int idMascota) {
        try {
            // Crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // Recupera todos los antecedentes de la mascota
            List<Antecedente> antecedentesMascota = objDao.getAllByField(
                    Antecedente.class,
                    "antecedentes",
                    "id_mascota",
                    idMascota
            );

            // Filtra solo aquellos antecedentes con activo = true
            antecedentesMascota = antecedentesMascota.stream()
                    .filter(a -> Boolean.TRUE.equals(a.isActivo()))
                    .collect(Collectors.toList());

            // Si no quedan antecedentes activos, retorna 404
            if (antecedentesMascota.isEmpty()) {
                return new ResponseProvider(
                        false,
                        404,
                        "No hay antecedentes activos en la mascota",
                        null,
                        null
                ).toResponse();
            }

            // Lista para almacenar DTOs de antecedentes con sus tratamientos
            List<AntecedenteConTratamientosDTO> antecedentesConTratamientos
                    = new ArrayList<>();

            // Por cada antecedente activo, crea un DTO y le agrega tratamientos activos
            for (Antecedente a : antecedentesMascota) {
                // Mapea datos basicos del antecedente a DTO
                AntecedenteConTratamientosDTO dto
                        = new AntecedenteConTratamientosDTO();
                dto.setId(a.getId());
                dto.setTitulo(a.getTitulo());
                dto.setDiagnostico(a.getDiagnostico());
                dto.setFecha_creado(a.getFecha_creado());

                // Recupera todos los tratamientos vinculados a este antecedente
                List<Tratamiento> tratamientos = objDao.getAllByField(
                        Tratamiento.class,
                        "antecedentes_tratamientos",
                        "id_antecedente",
                        a.getId()
                );

                // Filtra solo tratamientos con activo = true
                tratamientos = tratamientos.stream()
                        .filter(t -> Boolean.TRUE.equals(t.isActivo()))
                        .collect(Collectors.toList());

                // Si hay tratamientos activos, mapea cada uno a su DTO
                if (!tratamientos.isEmpty()) {
                    List<TratamientoDTO> tratamientosDTO = new ArrayList<>();
                    for (Tratamiento t : tratamientos) {
                        TratamientoDTO tDto = new TratamientoDTO();
                        tDto.setId(t.getId());
                        tDto.setTitulo(t.getTitulo());
                        tDto.setDescripcion(t.getDescripcion());
                        tDto.setFecha_creado(t.getFecha_creado());
                        tratamientosDTO.add(tDto);
                    }
                    dto.setTratamientos(tratamientosDTO); // Asigna lista de tratamientos DTO
                }

                // Agrega el DTO completo a la lista de respuesta
                antecedentesConTratamientos.add(dto);
            }

            // Retorna 200 con la lista de antecedentes y tratamientos
            return new ResponseProvider(
                    true,
                    200,
                    "Antecedentes con tratamientos activos obtenidos correctamente",
                    antecedentesConTratamientos,
                    null
            ).toResponse();

        } catch (Exception e) {
            // Retorna 500 en caso de excepcion inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener los antecedentes con sus tratamientos",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Obtiene un antecedente por su ID, si esta activo.
     *
     * @param idAntecedente ID del antecedente
     * @return Response con Antecedente o error
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAntecedenteById(
            @PathParam("id") int idAntecedente) {
        try {
            // Crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // Recupera el antecedente por su ID
            Antecedente antecedente = objDao.getById(
                    Antecedente.class,
                    "antecedentes",
                    idAntecedente
            );

            // Si no existe o su campo activo es false, retorna 404
            if (antecedente == null
                    || !Boolean.TRUE.equals(antecedente.isActivo())) {
                return new ResponseProvider(
                        false,
                        404,
                        "Antecedente no encontrado o inactivo",
                        null,
                        null
                ).toResponse();
            }

            // Retorna 200 con el antecedente encontrado
            return new ResponseProvider(
                    true,
                    200,
                    "Antecedente obtenido correctamente",
                    antecedente,
                    null
            ).toResponse();

        } catch (Exception e) {
            // Retorna 500 en caso de error durante la consulta
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener el antecedente",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Crea un nuevo antecedente en la base de datos.
     *
     * @param nuevoAntecedente objeto recibido desde el cliente
     * @return Response con datos del antecedente creado o error
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createAntecedente(Antecedente nuevoAntecedente) {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // marca el antecedente como activo por defecto
            nuevoAntecedente.setActivo(true);

            // inserta el nuevo antecedente y obtiene la entidad creada
            Antecedente creado = objDao.create("antecedentes", nuevoAntecedente);

            // si no se creo, retorna error 400
            if (creado == null) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo registrar el antecedente",
                        null,
                        null
                ).toResponse();
            }

            // recupera el antecedente recien creado para obtener valores como fecha_creado
            Antecedente antecedenteBD = objDao.getById(
                    Antecedente.class,
                    "antecedentes",
                    creado.getId()
            );

            // si no se encuentra tras crearlo, retorna error 404
            if (antecedenteBD == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "Antecedente no encontrado",
                        null,
                        null
                ).toResponse();
            }

            // construye el DTO de respuesta con campos esenciales
            AntecedenteResponseDTO dto = new AntecedenteResponseDTO();
            dto.setId(antecedenteBD.getId());
            dto.setTitulo(antecedenteBD.getTitulo());
            dto.setDiagnostico(antecedenteBD.getDiagnostico());
            dto.setFecha_creado(antecedenteBD.getFecha_creado());

            // retorna 201 con el DTO creado
            return new ResponseProvider(
                    true,
                    201,
                    "Antecedente registrado exitosamente",
                    dto,
                    null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de excepcion inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al registrar el antecedente",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Actualiza los campos de un antecedente existente. Solo modifica los
     * campos titulo y diagnostico recibidos.
     *
     * @param idAntecedente ID del antecedente a actualizar
     * @param antecedenteRequest objeto con los nuevos valores
     * @return Response con datos del antecedente actualizado o error
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateAntecedente(
            @PathParam("id") int idAntecedente,
            Antecedente antecedenteRequest) {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // verifica existencia y estado activo del antecedente
            Antecedente antecedenteBD = objDao.getById(
                    Antecedente.class,
                    "antecedentes",
                    idAntecedente
            );
            // retorna 404 si no existe o no esta activo
            if (antecedenteBD == null
                    || !Boolean.TRUE.equals(antecedenteBD.isActivo())) {
                return new ResponseProvider(
                        false,
                        404,
                        "Antecedente no encontrado o inactivo",
                        null,
                        null
                ).toResponse();
            }

            // actualiza solo titulo si se envio en la solicitud
            if (antecedenteRequest.getTitulo() != null) {
                antecedenteBD.setTitulo(antecedenteRequest.getTitulo());
            }
            // actualiza solo diagnostico si se envio en la solicitud
            if (antecedenteRequest.getDiagnostico() != null) {
                antecedenteBD.setDiagnostico(antecedenteRequest.getDiagnostico());
            }

            // ejecuta la actualizacion en la base de datos
            boolean actualizado = objDao.update(
                    antecedenteBD,
                    "antecedentes",
                    "id"
            );
            // retorna 400 si no se pudo actualizar
            if (!actualizado) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo actualizar el antecedente",
                        null,
                        null
                ).toResponse();
            }

            // construye el DTO de respuesta con los datos ya actualizados
            AntecedenteResponseDTO antecedenteDTO = new AntecedenteResponseDTO();
            antecedenteDTO.setId(antecedenteBD.getId());
            antecedenteDTO.setFecha_creado(antecedenteBD.getFecha_creado());
            antecedenteDTO.setTitulo(antecedenteBD.getTitulo());
            antecedenteDTO.setDiagnostico(antecedenteBD.getDiagnostico());

            // retorna 200 con el DTO actualizado
            return new ResponseProvider(
                    true,
                    200,
                    "Antecedente actualizado exitosamente",
                    antecedenteDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de error durante la actualizacion
            return new ResponseProvider(
                    false,
                    500,
                    "Error al actualizar el antecedente",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Elimina logicamente un antecedente (soft delete) siempre que no tenga
     * tratamientos activos asociados.
     *
     * @param idAntecedente ID del antecedente a eliminar
     * @return Response indicando si la eliminacion fue exitosa o no
     */
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteAntecedente(@PathParam("id") int idAntecedente) {
        try {
            // Crea instancia de DAO para operaciones sobre antecedentes
            AntecedenteDAO antecedenteDAO = new AntecedenteDAO();

            // Intenta desactivar logicamente el antecedente
            boolean eliminado = antecedenteDAO.softDeleteAntecedente(idAntecedente);

            // Si no se desactivo, retorna 400 con mensaje explicativo
            if (!eliminado) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo eliminar el antecedente, puede tener tratamientos asociados o no existe",
                        null,
                        null
                ).toResponse();
            }

            // Retorna 200 si la eliminacion fue exitosa
            return new ResponseProvider(
                    true,
                    200,
                    "Antecedente eliminado correctamente",
                    null,
                    null
            ).toResponse();

        } catch (Exception e) {
            // Retorna 500 en caso de excepcion inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al eliminar el antecedente",
                    e,
                    null
            ).toResponse();
        }
    }
}
