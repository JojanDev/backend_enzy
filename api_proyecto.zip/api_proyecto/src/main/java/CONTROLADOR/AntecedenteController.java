/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.Antecedente;
import MODELO.AntecedenteConTratamientosDTO;
import MODELO.AntecedenteDAO;
import MODELO.AntecedenteResponseDTO;
import MODELO.CrudDAO;
import MODELO.Tratamiento;
import MODELO.TratamientoDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author USUARIO
 */
@Path("antecedentes")
public class AntecedenteController {

    @GET
    @Path("/mascota/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllAntecedentesByIdMascota(@PathParam("id") int idMascota) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Traemos todos los antecedentes de la mascota
            List<Antecedente> antecedentesMascota = objDao.getAllByField(
                    Antecedente.class, "antecedentes", "id_mascota", idMascota
            );

            // Filtramos solo los antecedentes activos
            antecedentesMascota = antecedentesMascota.stream()
                    // .stream() convierte la lista en un flujo (stream) para poder manipularla con filtros y transformaciones
                    .filter(a -> Boolean.TRUE.equals(a.isActivo()))
                    // .filter(...) revisa cada elemento y solo deja pasar los que cumplan la condición:
                    // aquí verificamos que el atributo "activo" sea true (Boolean.TRUE evita problemas si es null)
                    .collect(Collectors.toList());
            // .collect(...) vuelve a reunir los elementos filtrados en una nueva lista

            if (antecedentesMascota.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay antecedentes activos en la mascota", null, null).toResponse();
            }

            List<AntecedenteConTratamientosDTO> antecedentesConTratamientos = new ArrayList<>();

            for (Antecedente a : antecedentesMascota) {
                AntecedenteConTratamientosDTO antecedenteConTratamientos = new AntecedenteConTratamientosDTO();

                antecedenteConTratamientos.setDiagnostico(a.getDiagnostico());
                antecedenteConTratamientos.setFecha_creado(a.getFecha_creado());
                antecedenteConTratamientos.setId(a.getId());
                antecedenteConTratamientos.setTitulo(a.getTitulo());

                // Traemos tratamientos del antecedente
                List<Tratamiento> tratamientos = objDao.getAllByField(
                        Tratamiento.class, "antecedentes_tratamientos", "id_antecedente", a.getId()
                );

                // Filtramos solo los tratamientos activos
                tratamientos = tratamientos.stream()
                        // Convierte la lista tratamientos en un flujo de datos
                        .filter(t -> Boolean.TRUE.equals(t.isActivo()))
                        // Mantiene solo los tratamientos cuyo campo "activo" sea true
                        .collect(Collectors.toList());
                // Recolecta el resultado nuevamente en una lista

                if (!tratamientos.isEmpty()) {
                    List<TratamientoDTO> tratamientosDTO = new ArrayList<>();

                    for (Tratamiento t : tratamientos) {
                        TratamientoDTO tratamientoDTO = new TratamientoDTO();
                        tratamientoDTO.setId(t.getId());
                        tratamientoDTO.setDescripcion(t.getDescripcion());
                        tratamientoDTO.setFecha_creado(t.getFecha_creado());
                        tratamientoDTO.setTitulo(t.getTitulo());
                        tratamientosDTO.add(tratamientoDTO);
                    }

                    antecedenteConTratamientos.setTratamientos(tratamientosDTO);
                }

                antecedentesConTratamientos.add(antecedenteConTratamientos);
            }

            return new ResponseProvider(true, 200, "Antecedentes con tratamientos activos obtenidos correctamente", antecedentesConTratamientos, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los antecedentes con sus tratamientos", e, null).toResponse();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createAntecedente(Antecedente nuevoAntecedente) {
        try {
            CrudDAO objDao = new CrudDAO();
            nuevoAntecedente.setActivo(true);
            Antecedente antecedenteCreado = objDao.create("antecedentes", nuevoAntecedente);

            
            if (antecedenteCreado == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar el antecedente", null, null).toResponse();
            }

            Antecedente antecedenteBD = objDao.getById(Antecedente.class, "antecedentes", antecedenteCreado.getId());

            if (antecedenteBD == null) {
                return new ResponseProvider(false, 404, "Cliente no encontrado", null, null).toResponse();
            }

            AntecedenteResponseDTO antecedenteDTO = new AntecedenteResponseDTO();

            antecedenteDTO.setId(antecedenteBD.getId());
            antecedenteDTO.setFecha_creado(antecedenteBD.getFecha_creado());
            antecedenteDTO.setTitulo(antecedenteBD.getTitulo());
            antecedenteDTO.setDiagnostico(antecedenteBD.getDiagnostico());

            return new ResponseProvider(true, 201, "Antecedente registrado exitosamente", antecedenteDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar el antecedente", e, null).toResponse();
        }
    }

    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteAntecedente(@PathParam("id") int idAntecedente) {
        try {
            AntecedenteDAO antecedenteDAO = new AntecedenteDAO();

            boolean eliminado = antecedenteDAO.softDeleteAntecedente(idAntecedente);

            if (!eliminado) {
                return new ResponseProvider(false, 400,
                        "No se pudo eliminar el antecedente, puede tener tratamientos asociados o no existe",
                        null, null).toResponse();
            }

            return new ResponseProvider(true, 200,
                    "Antecedente eliminado correctamente",
                    null, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500,
                    "Error al eliminar el antecedente", e, null).toResponse();
        }
    }

}
