package CONTROLADOR;

import MODELO.DAO.CrudDAO;
import MODELO.TipoDocumento;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 * Controlador REST para la gestión de tipos de documento.
 * Proporciona endpoint para:
 * - obtener todos los tipos de documento registrados
 */
@Path("tipos-documentos")
public class TipoDocumentoController {

    /**
     * Obtiene todos los tipos de documento registrados.
     *
     * @return Response con lista de TipoDocumento o mensaje de error
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllTiposDocumento() {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera todos los registros de la tabla 'tipos_documento'
            List<TipoDocumento> tiposDocumento = objDao.getAll(
                TipoDocumento.class,
                "tipos_documento"
            );

            // si no hay tipos de documento, retorna 404
            if (tiposDocumento.isEmpty()) {
                return new ResponseProvider(
                    false,
                    404,
                    "No hay tipos de documentos registrados",
                    null,
                    null
                ).toResponse();
            }

            // retorna 200 con la lista de tipos de documento
            return new ResponseProvider(
                true,
                200,
                "Tipos de documentos obtenidos correctamente",
                tiposDocumento,
                null
            ).toResponse();
        } catch (Exception e) {
            // en caso de excepción, retorna 500 con detalle del error
            return new ResponseProvider(
                false,
                500,
                "Error al obtener los tipos de documento",
                e,
                null
            ).toResponse();
        }
    }
}

