package CONTROLADOR;

import MODELO.DAO.CrudDAO;
import MODELO.TipoDocumento;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 * Controlador REST encargado de gestionar los tipos de documentos.
 *
 * Expone un endpoint para obtener todos los registros de la tabla
 * `tipos_documento`. La respuesta se devuelve en formato JSON.
 */
@Path("tipos-documentos")
public class TipoDocumentoController {

    /**
     * Obtiene todos los tipos de documento almacenados en la base de datos.
     *
     * @return Respuesta HTTP con la lista de tipos de documentos si existen, o
     * un mensaje de error en caso contrario.
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllTiposDocumento() {
        try {
            final CrudDAO objDao = new CrudDAO();
            final List<TipoDocumento> tiposDocumento = objDao.getAll(TipoDocumento.class, "tipos_documento");

            // Validamos si existen registros de tipos de documentos
            if (tiposDocumento.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay tipos de documentos registrados", null, null).toResponse();
            }

            // Devolvemos la lista de tipos de documentos encontrada
            return new ResponseProvider(true, 200, "Tipos de documentos obtenidos correctamente", tiposDocumento, null).toResponse();
        } catch (Exception e) {
            // En caso de error inesperado devolvemos un mensaje con código 500
            return new ResponseProvider(false, 500, "Error al obtener los tipos de documento", e, null).toResponse();
        }
    }
}
