/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.Cliente;
import MODELO.ClienteInfoDTO;
import MODELO.CrudDAO;
import MODELO.InformacionClientesPersonal;
import MODELO.TipoDocumento;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Propietario
 */
@Path("tiposDocumentos")
public class TipoDocumentoController {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllTiposDocumento() {
        try {
            final CrudDAO objDao = new CrudDAO();
            final List<TipoDocumento> tiposDocumento = objDao.getAll(TipoDocumento.class, "tipos_documento");
            
            // Validamos si existen registros de tipos de documentos
            if (tiposDocumento.isEmpty())
                return new ResponseProvider(false, 404, "No hay tipos de documentos registrados", null, null).toResponse();

            return new ResponseProvider(true, 200, "Tipos de documentos obtenidos correctamente", tiposDocumento, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los tipos de documento", e, null).toResponse(); 
        }
    }
}
