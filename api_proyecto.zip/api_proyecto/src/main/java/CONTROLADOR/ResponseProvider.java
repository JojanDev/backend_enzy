package CONTROLADOR;

import java.util.List;
import jakarta.ws.rs.core.Response; 

public class ResponseProvider<T> {
    public boolean success;
    public int code;
    public String message;
    public T data;
    public List<String> errors;
    
    public ResponseProvider(boolean success, int code, String message, T data, List<String> errors){
        this.success = success;
        this.code = code;
        this.message = message;
        this.data = data;
        this.errors  = errors;
    }
    
    public Response toResponse(){
            return Response.status(this.code)
                    .entity(this)
                    .build();
    }
}
