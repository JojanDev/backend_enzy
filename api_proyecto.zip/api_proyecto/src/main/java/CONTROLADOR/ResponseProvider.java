package CONTROLADOR;

import java.util.List;
import jakarta.ws.rs.core.Response;

/**
 * Clase genérica que estandariza las respuestas de la API REST.
 *
 * Esta clase permite construir un objeto de respuesta consistente para todas
 * las peticiones, asegurando que cada endpoint devuelva información en un mismo
 * formato.
 *
 * El objeto generado incluye: - success: indica si la operación fue exitosa o
 * no. - code: código de estado HTTP asociado a la respuesta. - message: mensaje
 * descriptivo del resultado. - data: datos obtenidos o procesados (en caso de
 * éxito). - errors: lista de errores específicos (opcional).
 *
 * @param <T> Tipo de dato que contendrá la propiedad {@code data}.
 */
public class ResponseProvider<T> {

    /**
     * Indica si la operación fue exitosa (true) o fallida (false).
     */
    public boolean success;

    /**
     * Código de estado HTTP asociado a la respuesta.
     */
    public int code;

    /**
     * Mensaje descriptivo sobre el resultado de la operación.
     */
    public String message;

    /**
     * Datos devueltos en caso de éxito.
     */
    public T data;

    /**
     * Lista de errores ocurridos (si aplica).
     */
    public List<String> errors;

    /**
     * Constructor para inicializar un objeto de respuesta.
     *
     * @param success true si la operación fue exitosa, false en caso contrario
     * @param code código de estado HTTP
     * @param message mensaje descriptivo
     * @param data datos a retornar en la respuesta
     * @param errors lista de errores en caso de fallo
     */
    public ResponseProvider(boolean success, int code, String message, T data, List<String> errors) {
        this.success = success;
        this.code = code;
        this.message = message;
        this.data = data;
        this.errors = errors;
    }

    /**
     * Convierte el objeto {@code ResponseProvider} en una respuesta HTTP
     * válida.
     *
     * @return Objeto {@link javax.ws.rs.core.Response} con el código de estado
     * y el contenido de este ResponseProvider como entidad JSON.
     */
    public Response toResponse() {
        // Construir una respuesta HTTP con el código y los datos actuales
        return Response.status(this.code)
                .entity(this)
                .build();
    }
}
