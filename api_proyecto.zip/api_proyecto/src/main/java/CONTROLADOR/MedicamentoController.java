package CONTROLADOR;

import MODELO.ConexionBD;
import MODELO.DAO.CrudDAO;
import MODELO.Medicamento;
import MODELO.DAO.MedicamentoDAO;
import MODELO.MedicamentoInfo;
import MODELO.DTO.MedicamentoResponseDTO;
import MODELO.MedicamentoTratamiento;
import MODELO.DAO.MedicamentoTratamientoDAO;
import MODELO.DTO.MedicamentoTratamientoResponseDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Controlador REST para manejar las operaciones relacionadas con medicamentos.
 * Proporciona endpoints para:
 * - obtener todos los medicamentos y sus datos adicionales
 * - obtener un medicamento por su ID
 * - gestionar información detallada de medicamentos (create, read, update, delete)
 * - listar y consultar medicamentos activos por tratamiento
 * - crear, actualizar y eliminar registros de medicamentos en tratamientos
 * - crear, actualizar y eliminar información base de medicamentos
 */
@Path("medicamentos")
public class MedicamentoController {

    /**
     * Obtiene todos los medicamentos registrados.
     *
     * @return Response con la lista de MedicamentoResponseDTO o mensaje de
     * error
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllMedicamentos() {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera todos los registros de la tabla 'medicamentos'
            List<Medicamento> medicamentos = objDao.getAll(
                    Medicamento.class,
                    "medicamentos"
            );

            // si no existen medicamentos, retorna 404
            if (medicamentos.isEmpty()) {
                return new ResponseProvider(
                        false,
                        404,
                        "No hay medicamentos registrados",
                        null,
                        null
                ).toResponse();
            }

            // lista para almacenar DTOs de respuesta
            List<MedicamentoResponseDTO> medicamentosDTO = new ArrayList<>();

            // itera sobre cada entidad Medicamento y construye su DTO
            for (Medicamento m : medicamentos) {
                MedicamentoResponseDTO medicamentoDTO = new MedicamentoResponseDTO();

                // asigna valores basicos al DTO
                medicamentoDTO.setId(m.getId());
                medicamentoDTO.setPrecio(m.getPrecio());
                medicamentoDTO.setCantidad(m.getCantidad());
                medicamentoDTO.setNumero_lote(m.getNumero_lote());
                medicamentoDTO.setFecha_caducidad(m.getFecha_caducidad());

                // obtiene informacion detallada asociada
                MedicamentoInfo infoMedicamento = objDao.getById(
                        MedicamentoInfo.class,
                        "medicamentos_info",
                        m.getId_medicamento_info()
                );

                // si existe informacion, la asigna al DTO
                if (infoMedicamento != null) {
                    medicamentoDTO.setInfo(infoMedicamento);
                }

                // agrega el DTO construido a la lista de respuesta
                medicamentosDTO.add(medicamentoDTO);
            }

            // retorna 200 con la lista de MedicamentoResponseDTO
            return new ResponseProvider(
                    true,
                    200,
                    "Medicamentos obtenidos correctamente",
                    medicamentosDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de excepcion inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener los medicamentos",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Obtiene todos los medicamentos informativos.
     *
     * @return Response con la lista de MedicamentoInfo o mensaje de error
     */
    @GET
    @Path("/info")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllMedicamentosInfo() {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera todos los registros de 'medicamentos_info'
            List<MedicamentoInfo> medicamentosInfo = objDao.getAll(
                    MedicamentoInfo.class,
                    "medicamentos_info"
            );

            // si no hay informacion, retorna 404
            if (medicamentosInfo.isEmpty()) {
                return new ResponseProvider(
                        false,
                        404,
                        "No hay medicamentos informativos registrados",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 con la lista de MedicamentoInfo
            return new ResponseProvider(
                    true,
                    200,
                    "Medicamentos informativos obtenidos correctamente",
                    medicamentosInfo,
                    null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de excepcion inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener los medicamentos informativos",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Obtiene todos los medicamentos activos asociados a un tratamiento.
     *
     * @param idTratamiento ID del tratamiento
     * @return Response con lista de MedicamentoTratamientoResponseDTO o mensaje
     * de error
     */
    @GET
    @Path("/tratamiento/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMedicamentosByIdTratamiento(
            @PathParam("id") int idTratamiento) {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera asociaciones medicamento-tratamiento
            List<MedicamentoTratamiento> medicamentosTratamiento = objDao.getAllByField(
                    MedicamentoTratamiento.class,
                    "medicamentos_tratamiento",
                    "id_tratamiento",
                    idTratamiento
            );

            // filtra solo los que estan activos
            medicamentosTratamiento = medicamentosTratamiento.stream()
                    .filter(mt -> Boolean.TRUE.equals(mt.isActivo()))
                    .collect(Collectors.toList());

            // si no hay asociaciones activas, retorna 404
            if (medicamentosTratamiento.isEmpty()) {
                return new ResponseProvider(
                        false,
                        404,
                        "No hay medicamentos activos en el tratamiento",
                        null,
                        null
                ).toResponse();
            }

            // lista para almacenar DTOs de respuesta
            List<MedicamentoTratamientoResponseDTO> medicamentosTratamientoDTO = new ArrayList<>();

            // itera y convierte cada asociacion a su DTO
            for (MedicamentoTratamiento mt : medicamentosTratamiento) {
                MedicamentoTratamientoResponseDTO dto
                        = new MedicamentoTratamientoResponseDTO();

                // asigna valores basicos y formatea duracion
                dto.setId(mt.getId());
                dto.setDosis(mt.getDosis());
                dto.setDuracion(mt.getDuracion());
                dto.setFrecuencia_aplicacion(mt.getFrecuencia_aplicacion());
                dto.setDuracionFormateada(formatearDias(mt.getDuracion()));

                // obtiene y asigna informacion del medicamento
                MedicamentoInfo medicamentoInfo = objDao.getById(
                        MedicamentoInfo.class,
                        "medicamentos_info",
                        mt.getId_medicamento_info()
                );
                if (medicamentoInfo != null) {
                    dto.setMedicamento(medicamentoInfo);
                }

                medicamentosTratamientoDTO.add(dto);
            }

            // retorna 200 con lista de MedicamentoTratamientoResponseDTO
            return new ResponseProvider(
                    true,
                    200,
                    "Medicamentos activos obtenidos correctamente",
                    medicamentosTratamientoDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de excepcion inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener los medicamentos del tratamiento",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Obtiene un medicamento por su ID.
     *
     * @param id ID del medicamento a buscar
     * @return Response con MedicamentoResponseDTO o mensaje de error si no
     * existe
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMedicamentoById(@PathParam("id") int id) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera la entidad Medicamento por su ID
            Medicamento medicamento = objDao.getById(
                    Medicamento.class,
                    "medicamentos",
                    id
            );

            // si no existe, retorna 404
            if (medicamento == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "Medicamento no encontrado",
                        null,
                        null
                ).toResponse();
            }

            // construye el DTO de respuesta con datos básicos
            MedicamentoResponseDTO medicamentoDTO = new MedicamentoResponseDTO();
            medicamentoDTO.setId(medicamento.getId());
            medicamentoDTO.setPrecio(medicamento.getPrecio());
            medicamentoDTO.setCantidad(medicamento.getCantidad());
            medicamentoDTO.setNumero_lote(medicamento.getNumero_lote());
            medicamentoDTO.setFecha_caducidad(medicamento.getFecha_caducidad());

            // obtiene y asigna la información detallada asociada
            MedicamentoInfo infoMedicamento = objDao.getById(
                    MedicamentoInfo.class,
                    "medicamentos_info",
                    medicamento.getId_medicamento_info()
            );
            medicamentoDTO.setInfo(infoMedicamento);

            // retorna 200 con el DTO construido
            return new ResponseProvider(
                    true,
                    200,
                    "Medicamento obtenido correctamente",
                    medicamentoDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de excepción inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener el medicamento",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Obtiene la información detallada de un medicamento por su ID.
     *
     * @param id ID de la información del medicamento
     * @return Response con MedicamentoInfo o mensaje de error si no existe
     */
    @GET
    @Path("/info/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMedicamentoInfoById(@PathParam("id") int id) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera la entidad MedicamentoInfo por su ID
            MedicamentoInfo medicamentoInfo = objDao.getById(
                    MedicamentoInfo.class,
                    "medicamentos_info",
                    id
            );

            // si no existe, retorna 404
            if (medicamentoInfo == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "Información de medicamento no encontrada",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 con la información encontrada
            return new ResponseProvider(
                    true,
                    200,
                    "Información de medicamento obtenida correctamente",
                    medicamentoInfo,
                    null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de excepción inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener la información del medicamento",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Obtiene un registro de MedicamentoTratamiento por su ID.
     *
     * @param id ID del registro en la tabla medicamentos_tratamiento
     * @return Response con MedicamentoTratamiento o mensaje de error si no
     * existe
     */
    @GET
    @Path("/tratamiento/item/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMedicamentoTratamientoById(@PathParam("id") int id) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera la entidad MedicamentoTratamiento por su ID
            MedicamentoTratamiento mt = objDao.getById(
                    MedicamentoTratamiento.class,
                    "medicamentos_tratamiento",
                    id
            );

            // si no existe, retorna 404
            if (mt == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "Medicamento del tratamiento no encontrado",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 con la entidad encontrada
            return new ResponseProvider(
                    true,
                    200,
                    "Medicamento del tratamiento obtenido correctamente",
                    mt,
                    null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de excepción inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener el medicamento del tratamiento",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Crea una nueva información de medicamento.
     *
     * @param nuevaInfo objeto MedicamentoInfo con los datos a registrar
     * @return Response con MedicamentoInfo creado o mensaje de error
     */
    @POST
    @Path("/info")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMedicamentoInfo(MedicamentoInfo nuevaInfo) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // inserta el nuevo registro en 'medicamentos_info'
            MedicamentoInfo infoCreada = objDao.create(
                    "medicamentos_info",
                    nuevaInfo
            );

            // si la creación falla, retorna 400
            if (infoCreada == null) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo registrar la nueva información de medicamento",
                        null,
                        null
                ).toResponse();
            }

            // retorna 201 con la entidad creada
            return new ResponseProvider(
                    true,
                    201,
                    "Información de medicamento registrada exitosamente",
                    infoCreada,
                    null
            ).toResponse();

        } catch (Exception e) {
            // retorna 500 en caso de excepción inesperada
            return new ResponseProvider(
                    false,
                    500,
                    "Error al registrar la información del medicamento",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Crea un nuevo medicamento asociado a un tratamiento.
     *
     * @param nuevo Objeto con la información del medicamento y su tratamiento
     * @return Response con el resultado de la creación
     */
    @POST
    @Path("/tratamiento/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMedicamentoTratamiento(MedicamentoTratamiento nuevo) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // marca el registro como activo por defecto
            nuevo.setActivo(true);

            // inserta el nuevo registro en 'medicamentos_tratamiento'
            MedicamentoTratamiento medicamentoCreado = objDao.create(
                    "medicamentos_tratamiento",
                    nuevo
            );

            // si la inserción falla, retorna 400
            if (medicamentoCreado == null) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo registrar el medicamento en el tratamiento",
                        null,
                        null
                ).toResponse();
            }

            // construye el DTO de respuesta con los datos insertados
            MedicamentoTratamientoResponseDTO medicamentoTratamiento
                    = new MedicamentoTratamientoResponseDTO();
            medicamentoTratamiento.setId(medicamentoCreado.getId());
            medicamentoTratamiento.setDosis(medicamentoCreado.getDosis());
            medicamentoTratamiento.setDuracion(medicamentoCreado.getDuracion());
            medicamentoTratamiento.setFrecuencia_aplicacion(
                    medicamentoCreado.getFrecuencia_aplicacion()
            );

            // formatea la duracion a representacion legible
            medicamentoTratamiento.setDuracionFormateada(
                    formatearDias(medicamentoCreado.getDuracion())
            );

            // obtiene la informacion del medicamento asociado
            MedicamentoInfo medicamentoInfo = objDao.getById(
                    MedicamentoInfo.class,
                    "medicamentos_info",
                    medicamentoCreado.getId_medicamento_info()
            );
            medicamentoTratamiento.setMedicamento(medicamentoInfo);

            // retorna 201 con el DTO de MedicamentoTratamiento creado
            return new ResponseProvider(
                    true,
                    201,
                    "Medicamento registrado en tratamiento exitosamente",
                    medicamentoTratamiento,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepciones inesperadas
            return new ResponseProvider(
                    false,
                    500,
                    "Error al registrar el medicamento en el tratamiento",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Crea un nuevo medicamento.
     *
     * @param nuevoMedicamento Objeto con los datos del medicamento a registrar
     * @return Response con el resultado de la creación
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMedicamento(Medicamento nuevoMedicamento) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // verifica que exista la informacion del medicamento
            MedicamentoInfo existeInfo = objDao.getById(
                    MedicamentoInfo.class,
                    "medicamentos_info",
                    nuevoMedicamento.getId_medicamento_info()
            );
            if (existeInfo == null) {
                return new ResponseProvider(
                        false,
                        400,
                        "No existe la información del medicamento",
                        null,
                        null
                ).toResponse();
            }

            // instancia MedicamentoDAO para validaciones adicionales
            MedicamentoDAO mediDAO = new MedicamentoDAO();

            // comprueba que el numero de lote no se repita
            boolean existeLote = mediDAO.existeLoteDeMedicamento(
                    nuevoMedicamento.getId_medicamento_info(),
                    nuevoMedicamento.getNumero_lote()
            );
            if (existeLote) {
                return new ResponseProvider(
                        false,
                        400,
                        "Este lote ya está registrado para el medicamento seleccionado",
                        null,
                        null
                ).toResponse();
            }

            // inserta el nuevo Medicamento en la tabla 'medicamentos'
            Medicamento medicamentoCreado = objDao.create(
                    "medicamentos",
                    nuevoMedicamento
            );
            if (medicamentoCreado == null) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo registrar el medicamento",
                        null,
                        null
                ).toResponse();
            }

            // construye el DTO de respuesta con datos de la entidad creada
            MedicamentoResponseDTO medicamentoDTO = new MedicamentoResponseDTO();
            medicamentoDTO.setId(medicamentoCreado.getId());
            medicamentoDTO.setPrecio(medicamentoCreado.getPrecio());
            medicamentoDTO.setCantidad(medicamentoCreado.getCantidad());
            medicamentoDTO.setNumero_lote(medicamentoCreado.getNumero_lote());
            medicamentoDTO.setFecha_caducidad(medicamentoCreado.getFecha_caducidad());
            medicamentoDTO.setInfo(existeInfo);

            // retorna 201 con el DTO de Medicamento creado
            return new ResponseProvider(
                    true,
                    201,
                    "Medicamento registrado exitosamente",
                    medicamentoDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepciones inesperadas
            return new ResponseProvider(
                    false,
                    500,
                    "Error al registrar el medicamento",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Actualiza un medicamento existente.
     *
     * @param id ID del medicamento a actualizar
     * @param medicamentoActualizado Objeto con la información actualizada del
     * medicamento
     * @return Response con el resultado de la actualización
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateMedicamento(
            @PathParam("id") int id,
            Medicamento medicamentoActualizado) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();
            // instancia MedicamentoDAO para validaciones específicas
            MedicamentoDAO mediDAO = new MedicamentoDAO();

            // verifica que exista la información base del medicamento
            MedicamentoInfo existeInfo = objDao.getById(
                    MedicamentoInfo.class,
                    "medicamentos_info",
                    medicamentoActualizado.getId_medicamento_info()
            );
            if (existeInfo == null) {
                return new ResponseProvider(
                        false,
                        400,
                        "No existe la información del medicamento",
                        null,
                        null
                ).toResponse();
            }

            // verifica que el medicamento a actualizar exista
            Medicamento medicamentoExistente = objDao.getById(
                    Medicamento.class,
                    "medicamentos",
                    id
            );
            if (medicamentoExistente == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "El medicamento no existe",
                        null,
                        null
                ).toResponse();
            }

            // comprueba duplicidad de número de lote solo si cambia el lote
            boolean existeLote = mediDAO.existeLoteDeMedicamento(
                    medicamentoActualizado.getId_medicamento_info(),
                    medicamentoActualizado.getNumero_lote()
            );
            if (existeLote
                    && medicamentoExistente.getNumero_lote() != null
                    && !medicamentoExistente.getNumero_lote()
                            .equals(medicamentoActualizado.getNumero_lote())) {
                return new ResponseProvider(
                        false,
                        400,
                        "Este lote ya está registrado para el medicamento seleccionado",
                        null,
                        null
                ).toResponse();
            }

            // asigna el ID recibido al objeto y realiza la actualización
            medicamentoActualizado.setId(id);
            boolean actualizado = objDao.update(
                    medicamentoActualizado,
                    "medicamentos",
                    "id"
            );
            if (!actualizado) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo actualizar el medicamento",
                        null,
                        null
                ).toResponse();
            }

            // construye el DTO de respuesta con los datos actualizados
            MedicamentoResponseDTO medicamentoDTO = new MedicamentoResponseDTO();
            medicamentoDTO.setId(medicamentoActualizado.getId());
            medicamentoDTO.setPrecio(medicamentoActualizado.getPrecio());
            medicamentoDTO.setCantidad(medicamentoActualizado.getCantidad());
            medicamentoDTO.setNumero_lote(medicamentoActualizado.getNumero_lote());
            medicamentoDTO.setFecha_caducidad(medicamentoActualizado.getFecha_caducidad());
            medicamentoDTO.setInfo(existeInfo);

            // retorna 200 con el DTO de medicamento actualizado
            return new ResponseProvider(
                    true,
                    200,
                    "Medicamento actualizado exitosamente",
                    medicamentoDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepciones inesperadas
            return new ResponseProvider(
                    false,
                    500,
                    "Error al actualizar el medicamento",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Actualiza la información de un medicamento.
     *
     * @param id ID de la información a actualizar
     * @param nuevaInfo Objeto con los datos actualizados de MedicamentoInfo
     * @return Response con el resultado de la actualización
     */
    @PUT
    @Path("/info/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateMedicamentoInfo(
            @PathParam("id") int id,
            MedicamentoInfo nuevaInfo) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // asigna el ID recibido al objeto de información
            nuevaInfo.setId(id);
            if (nuevaInfo.getId() == 0) {
                return new ResponseProvider(
                        false,
                        400,
                        "El ID de la información del medicamento es obligatorio para actualizar",
                        null,
                        null
                ).toResponse();
            }

            // verifica que la información exista en la base de datos
            MedicamentoInfo infoExistente = objDao.getById(
                    MedicamentoInfo.class,
                    "medicamentos_info",
                    id
            );
            if (infoExistente == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "La información de medicamento con ese ID no existe",
                        null,
                        null
                ).toResponse();
            }

            // realiza la actualización en la tabla 'medicamentos_info'
            boolean actualizada = objDao.update(
                    nuevaInfo,
                    "medicamentos_info",
                    "id"
            );
            if (!actualizada) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo actualizar la información del medicamento",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 con el objeto de información actualizado
            return new ResponseProvider(
                    true,
                    200,
                    "Información de medicamento actualizada exitosamente",
                    nuevaInfo,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepciones inesperadas
            return new ResponseProvider(
                    false,
                    500,
                    "Error al actualizar la información de medicamento",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Actualiza un medicamento dentro de un tratamiento.
     *
     * @param id ID del medicamento_tratamiento a actualizar
     * @param actualizacion objeto con los campos a modificar (dosis,
     * frecuencia, duracion)
     * @return Response con MedicamentoTratamientoResponseDTO o mensaje de error
     */
    @PUT
    @Path("/tratamiento/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateMedicamentoTratamiento(
            @PathParam("id") int id,
            MedicamentoTratamiento actualizacion) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera el registro existente de medicamentos_tratamiento
            MedicamentoTratamiento medicamentoExistente = objDao.getById(
                    MedicamentoTratamiento.class,
                    "medicamentos_tratamiento",
                    id
            );

            // si no existe el registro, devuelve 404
            if (medicamentoExistente == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "Medicamento del tratamiento no encontrado",
                        null,
                        null
                ).toResponse();
            }

            // aplica dosis si se proporciono valor no vacio
            if (actualizacion.getDosis() != null && !actualizacion.getDosis().isEmpty()) {
                medicamentoExistente.setDosis(actualizacion.getDosis());
            }

            // aplica frecuencia si se proporciono valor no vacio
            if (actualizacion.getFrecuencia_aplicacion() != null
                    && !actualizacion.getFrecuencia_aplicacion().isEmpty()) {
                medicamentoExistente.setFrecuencia_aplicacion(
                        actualizacion.getFrecuencia_aplicacion()
                );
            }

            // aplica duracion solo si es mayor que cero
            if (actualizacion.getDuracion() > 0) {
                medicamentoExistente.setDuracion(actualizacion.getDuracion());
            }

            // ejecuta la actualizacion en la tabla 'medicamentos_tratamiento'
            boolean actualizado = objDao.update(
                    medicamentoExistente,
                    "medicamentos_tratamiento",
                    "id"
            );
            if (!actualizado) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo actualizar el medicamento del tratamiento",
                        null,
                        null
                ).toResponse();
            }

            // recupera informacion del medicamento para el DTO
            MedicamentoInfo medicamentoInfo = objDao.getById(
                    MedicamentoInfo.class,
                    "medicamentos_info",
                    medicamentoExistente.getId_medicamento_info()
            );

            // construye DTO de respuesta con datos actualizados
            MedicamentoTratamientoResponseDTO medicamentoDTO
                    = new MedicamentoTratamientoResponseDTO();
            medicamentoDTO.setId(medicamentoExistente.getId());
            medicamentoDTO.setId_tratamiento(medicamentoExistente.getId_tratamiento());
            medicamentoDTO.setDosis(medicamentoExistente.getDosis());
            medicamentoDTO.setFrecuencia_aplicacion(
                    medicamentoExistente.getFrecuencia_aplicacion()
            );
            medicamentoDTO.setDuracion(medicamentoExistente.getDuracion());
            medicamentoDTO.setDuracionFormateada(
                    formatearDias(medicamentoExistente.getDuracion())
            );
            if (medicamentoInfo != null) {
                medicamentoDTO.setMedicamento(medicamentoInfo);
            }

            // retorna 200 con el DTO construido
            return new ResponseProvider(
                    true,
                    200,
                    "Medicamento del tratamiento actualizado correctamente",
                    medicamentoDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepciones inesperadas
            return new ResponseProvider(
                    false,
                    500,
                    "Error al actualizar el medicamento del tratamiento",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Elimina un medicamento de un tratamiento.
     *
     * @param id ID del medicamento_tratamiento a eliminar
     * @return Response con el resultado de la eliminacion
     */
    @DELETE
    @Path("/tratamiento/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response eliminarMedicamentoTratamiento(@PathParam("id") int id) {
        try {
            // instancia DAO especializado con conexion
            MedicamentoTratamientoDAO dao = new MedicamentoTratamientoDAO(
                    ConexionBD.conectar()
            );

            // intenta eliminar el registro
            boolean eliminado = dao.eliminarMedicamentoTratamiento(id);

            // si no se encontro o ya estaba eliminado, devuelve 404
            if (!eliminado) {
                return new ResponseProvider(
                        false,
                        404,
                        "No se encontro el medicamento del tratamiento o ya estaba eliminado",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 si se elimino correctamente
            return new ResponseProvider(
                    true,
                    200,
                    "Medicamento del tratamiento eliminado correctamente",
                    null,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepciones inesperadas
            return new ResponseProvider(
                    false,
                    500,
                    "Error al eliminar el medicamento del tratamiento",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Elimina la informacion de un medicamento. Solo permite eliminar si no
     * esta asociada a inventario ni tratamientos.
     *
     * @param id ID de MedicamentoInfo a eliminar
     * @return Response con el resultado de la eliminacion
     */
    @DELETE
    @Path("/info/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteMedicamentoInfo(@PathParam("id") int id) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // verifica existencia de la informacion del medicamento
            MedicamentoInfo medicamentoInfo = objDao.getById(
                    MedicamentoInfo.class,
                    "medicamentos_info",
                    id
            );
            if (medicamentoInfo == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "El medicamento no existe",
                        null,
                        null
                ).toResponse();
            }

            // verifica que no haya inventario asociado
            List<Medicamento> medicamentosAsociados = objDao.getAllByField(
                    Medicamento.class,
                    "medicamentos",
                    "id_medicamento_info",
                    medicamentoInfo.getId()
            );
            if (!medicamentosAsociados.isEmpty()) {
                return new ResponseProvider(
                        false,
                        400,
                        "El medicamento esta asociado a inventario y no puede eliminarse",
                        null,
                        null
                ).toResponse();
            }

            // verifica que no haya tratamientos asociados
            List<MedicamentoTratamiento> tratamientosAsociados = objDao.getAllByField(
                    MedicamentoTratamiento.class,
                    "medicamentos_tratamiento",
                    "id_medicamento_info",
                    medicamentoInfo.getId()
            );
            if (!tratamientosAsociados.isEmpty()) {
                return new ResponseProvider(
                        false,
                        400,
                        "El medicamento esta asociado a tratamientos y no puede eliminarse",
                        null,
                        null
                ).toResponse();
            }

            // ejecuta la eliminacion de la informacion
            boolean eliminado = objDao.delete(
                    id,
                    "medicamentos_info",
                    "id"
            );
            if (!eliminado) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo eliminar el medicamento",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 si la eliminacion fue exitosa
            return new ResponseProvider(
                    true,
                    200,
                    "Medicamento eliminado exitosamente",
                    null,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepciones inesperadas
            return new ResponseProvider(
                    false,
                    500,
                    "Error al eliminar el medicamento",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Convierte un número de días a formato largo y corto.
     *
     * @param totalDias cantidad total de días a formatear
     * @return array de String donde [0] es el formato largo y [1] el formato
     * corto
     */
    public static String[] formatearDias(int totalDias) {
        // constantes para el cálculo
        final int DIAS_POR_MES = 30;
        final int DIAS_POR_SEMANA = 7;

        // calcula meses completos
        int meses = totalDias / DIAS_POR_MES;
        // días restantes después de extraer meses
        int diasRestantes = totalDias % DIAS_POR_MES;
        // calcula semanas completas de los días restantes
        int semanas = diasRestantes / DIAS_POR_SEMANA;
        // días sobrantes después de extraer semanas
        int dias = diasRestantes % DIAS_POR_SEMANA;

        // arma el formato largo (ej. "1 mes, 2 semanas y 3 días")
        StringBuilder formatoLargo = new StringBuilder();
        if (meses > 0) {
            formatoLargo.append(meses)
                    .append(" mes")
                    .append(meses > 1 ? "es" : "");
        }
        if (semanas > 0) {
            formatoLargo.append(formatoLargo.length() > 0 ? ", " : "")
                    .append(semanas)
                    .append(" semana")
                    .append(semanas > 1 ? "s" : "");
        }
        if (dias > 0) {
            formatoLargo.append(formatoLargo.length() > 0 ? " y " : "")
                    .append(dias)
                    .append(" día")
                    .append(dias > 1 ? "s" : "");
        }
        // si no hay nada, muestra "0 días"
        if (formatoLargo.length() == 0) {
            formatoLargo.append("0 días");
        }

        // arma el formato corto (ej. "1 mes 2 sem 3 dia")
        StringBuilder formatoCorto = new StringBuilder();
        if (meses > 0) {
            formatoCorto.append(meses).append(" mes ");
        }
        if (semanas > 0) {
            formatoCorto.append(semanas).append(" sem ");
        }
        if (dias > 0) {
            formatoCorto.append(dias).append(" dia");
        }
        // si no hay nada, muestra "0d"
        if (formatoCorto.length() == 0) {
            formatoCorto.append("0d");
        }

        // retorna array con [formatoLargo, formatoCorto]
        return new String[]{
            formatoLargo.toString(),
            formatoCorto.toString().trim()
        };
    }

}
