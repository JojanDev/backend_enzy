package CONTROLADOR;

import MODELO.ConexionBD;
import MODELO.DAO.CrudDAO;
import MODELO.Medicamento;
import MODELO.DAO.MedicamentoDAO;
import MODELO.MedicamentoInfo;
import MODELO.DTO.MedicamentoResponseDTO;
import MODELO.MedicamentoTratamiento;
import MODELO.DAO.MedicamentoTratamientoDAO;
import MODELO.DTO.MedicamentoTratamientoResponseDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Controlador REST para manejar las operaciones relacionadas con los
 * medicamentos. Proporciona endpoints para obtener medicamentos, información de
 * medicamentos y medicamentos asociados a tratamientos.
 *
 * Autor: USUARIO
 */
@Path("medicamentos") // Define la ruta base para este controlador
public class MedicamentoController {

    /**
     * Obtiene todos los medicamentos registrados.
     *
     * @return Response con la lista de medicamentos o un mensaje de error.
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllMedicamentos() {
        try {
            CrudDAO objDao = new CrudDAO(); // Crea instancia de CrudDAO
            List<Medicamento> medicamentos = objDao.getAll(Medicamento.class, "medicamentos"); // Obtiene todos los medicamentos

            if (medicamentos.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay medicamentos registrados", null, null).toResponse();
            }

            List<MedicamentoResponseDTO> medicamentosDTO = new ArrayList<>();

            // Itera sobre cada medicamento y lo convierte a DTO
            for (Medicamento m : medicamentos) {
                MedicamentoResponseDTO medicamentoDTO = new MedicamentoResponseDTO();

                medicamentoDTO.setId(m.getId());
                medicamentoDTO.setPrecio(m.getPrecio());
                medicamentoDTO.setCantidad(m.getCantidad());
                medicamentoDTO.setNumero_lote(m.getNumero_lote());
                medicamentoDTO.setFecha_caducidad(m.getFecha_caducidad());

                // Obtiene la información detallada del medicamento
                MedicamentoInfo infoMedicamento = objDao.getById(MedicamentoInfo.class, "medicamentos_info", m.getId_medicamento_info());

                if (infoMedicamento != null) {
                    medicamentoDTO.setInfo(infoMedicamento);
                }

                medicamentosDTO.add(medicamentoDTO);
            }

            return new ResponseProvider(true, 200, "Medicamentos obtenidos correctamente", medicamentosDTO, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los medicamentos", e, null).toResponse();
        }
    }

    /**
     * Obtiene todos los medicamentos informativos.
     *
     * @return Response con la lista de medicamentos informativos o un mensaje
     * de error.
     */
    @GET
    @Path("/info/") // Ruta específica para obtener información de medicamentos
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllMedicamentosInfo() {
        try {
            CrudDAO objDao = new CrudDAO(); // Crea instancia de CrudDAO
            List<MedicamentoInfo> medicamentosInfo = objDao.getAll(MedicamentoInfo.class, "medicamentos_info"); // Obtiene todos los medicamentos informativos

            if (medicamentosInfo.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay medicamentos informativos registrados", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Medicamentos informativos obtenidos correctamente", medicamentosInfo, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los medicamentos informativos", e, null).toResponse();
        }
    }

    /**
     * Obtiene todos los medicamentos activos asociados a un tratamiento
     * específico.
     *
     * @param idTratamiento ID del tratamiento.
     * @return Response con la lista de medicamentos del tratamiento o un
     * mensaje de error.
     */
    @GET
    @Path("/tratamiento/{id}") // Ruta para obtener medicamentos de un tratamiento
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMedicamentosByIdTratamiento(@PathParam("id") int idTratamiento) {
        try {
            CrudDAO objDao = new CrudDAO(); // Crea instancia de CrudDAO

            // Obtiene todos los medicamentos del tratamiento indicado
            List<MedicamentoTratamiento> medicamentosTratamiento = objDao.getAllByField(
                    MedicamentoTratamiento.class,
                    "medicamentos_tratamiento",
                    "id_tratamiento",
                    idTratamiento
            );

            // Filtra solo los activos
            medicamentosTratamiento = medicamentosTratamiento.stream()
                    // Convierte la lista 'medicamentosTratamiento' en un Stream para poder aplicar operaciones funcionales
                    .filter(mt -> Boolean.TRUE.equals(mt.isActivo()))
                    // Filtra los elementos del Stream: solo se mantienen los objetos 'mt' cuyo método 'isActivo()' devuelve TRUE
                    // Usamos 'Boolean.TRUE.equals(...)' para evitar NullPointerException si 'isActivo()' es null
                    .collect(Collectors.toList());
            // Convierte el Stream filtrado de nuevo a una lista y reemplaza la lista original

            if (medicamentosTratamiento.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay medicamentos activos en el tratamiento", null, null).toResponse();
            }

            List<MedicamentoTratamientoResponseDTO> medicamentosTratamientoDTO = new ArrayList<>();

            // Itera sobre cada medicamento y lo convierte a DTO
            for (MedicamentoTratamiento mt : medicamentosTratamiento) {
                MedicamentoTratamientoResponseDTO medicamentoTratamiento = new MedicamentoTratamientoResponseDTO();

                medicamentoTratamiento.setDosis(mt.getDosis());
                medicamentoTratamiento.setDuracion(mt.getDuracion());
                medicamentoTratamiento.setFrecuencia_aplicacion(mt.getFrecuencia_aplicacion());
                medicamentoTratamiento.setId(mt.getId());
                medicamentoTratamiento.setDuracionFormateada(formatearDias(mt.getDuracion()));

                // Obtiene la info del medicamento
                MedicamentoInfo medicamentoInfo = objDao.getById(MedicamentoInfo.class, "medicamentos_info", mt.getId_medicamento_info());
                if (medicamentoInfo != null) {
                    medicamentoTratamiento.setMedicamento(medicamentoInfo);
                }

                medicamentosTratamientoDTO.add(medicamentoTratamiento);
            }

            return new ResponseProvider(true, 200, "Medicamentos activos obtenidos correctamente", medicamentosTratamientoDTO, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los medicamentos del tratamiento", e, null).toResponse();
        }
    }

    /**
     * Obtiene un medicamento por su ID.
     *
     * @param id ID del medicamento a buscar.
     * @return Response con la información del medicamento o un mensaje de
     * error.
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMedicamentoById(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO();
            Medicamento medicamento = objDao.getById(Medicamento.class, "medicamentos", id);

            if (medicamento == null) {
                return new ResponseProvider(false, 404, "Medicamento no encontrado", null, null).toResponse();
            }

            MedicamentoResponseDTO medicamentoDTO = new MedicamentoResponseDTO();
            medicamentoDTO.setId(medicamento.getId());
            medicamentoDTO.setPrecio(medicamento.getPrecio());
            medicamentoDTO.setCantidad(medicamento.getCantidad());
            medicamentoDTO.setNumero_lote(medicamento.getNumero_lote());
            medicamentoDTO.setFecha_caducidad(medicamento.getFecha_caducidad());

            MedicamentoInfo infoMedicamento = objDao.getById(MedicamentoInfo.class, "medicamentos_info", medicamento.getId_medicamento_info());
            medicamentoDTO.setInfo(infoMedicamento);

            return new ResponseProvider(true, 200, "Medicamento obtenido correctamente", medicamentoDTO, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener el medicamento", e, null).toResponse();
        }
    }

    /**
     * Obtiene la información detallada de un medicamento por su ID.
     *
     * @param id ID de la información del medicamento.
     * @return Response con la información o un mensaje de error.
     */
    @GET
    @Path("/info/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMedicamentoInfoById(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO();
            MedicamentoInfo medicamentoInfo = objDao.getById(MedicamentoInfo.class, "medicamentos_info", id);

            if (medicamentoInfo == null) {
                return new ResponseProvider(false, 404, "Información de medicamento no encontrada", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Información de medicamento obtenida correctamente", medicamentoInfo, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener la información del medicamento", e, null).toResponse();
        }
    }

    /**
     * Obtiene un medicamento asociado a un tratamiento por su ID.
     *
     * @param id ID del registro de medicamento en el tratamiento.
     * @return Response con la información o un mensaje de error.
     */
    @GET
    @Path("/tratamiento/item/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMedicamentoTratamientoById(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO();
            MedicamentoTratamiento mt = objDao.getById(MedicamentoTratamiento.class, "medicamentos_tratamiento", id);

            if (mt == null) {
                return new ResponseProvider(false, 404, "Medicamento del tratamiento no encontrado", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Medicamento del tratamiento obtenido correctamente", mt, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener el medicamento del tratamiento", e, null).toResponse();
        }
    }

    /**
     * Crea una nueva información de medicamento.
     *
     * @param nuevaInfo Objeto con la información del nuevo medicamento.
     * @return Response con el resultado de la creación.
     */
    @POST
    @Path("/info/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMedicamentoInfo(MedicamentoInfo nuevaInfo) {
        try {
            CrudDAO objDao = new CrudDAO();
            MedicamentoInfo infoCreada = objDao.create("medicamentos_info", nuevaInfo);

            if (infoCreada == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar la nueva información de medicamento", null, null).toResponse();
            }

            return new ResponseProvider(true, 201, "Información de medicamento registrada exitosamente", infoCreada, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar la información del medicamento", e, null).toResponse();
        }
    }

    /**
     * Crea un nuevo medicamento asociado a un tratamiento.
     *
     * @param nuevo Objeto con la información del medicamento y su tratamiento.
     * @return Response con el resultado de la creación.
     */
    @POST
    @Path("/tratamiento/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMedicamentoTratamiento(MedicamentoTratamiento nuevo) {
        try {
            CrudDAO objDao = new CrudDAO();
            nuevo.setActivo(true);
            MedicamentoTratamiento medicamentoCreado = objDao.create("medicamentos_tratamiento", nuevo);

            if (medicamentoCreado == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar el medicamento en el tratamiento", null, null).toResponse();
            }

            MedicamentoTratamientoResponseDTO medicamentoTratamiento = new MedicamentoTratamientoResponseDTO();
            medicamentoTratamiento.setDosis(medicamentoCreado.getDosis());
            medicamentoTratamiento.setDuracion(medicamentoCreado.getDuracion());
            medicamentoTratamiento.setFrecuencia_aplicacion(medicamentoCreado.getFrecuencia_aplicacion());
            medicamentoTratamiento.setId(medicamentoCreado.getId());
            medicamentoTratamiento.setDuracionFormateada(formatearDias(medicamentoCreado.getDuracion()));

            MedicamentoInfo medicamentoInfo = objDao.getById(MedicamentoInfo.class, "medicamentos_info", medicamentoCreado.getId_medicamento_info());
            medicamentoTratamiento.setMedicamento(medicamentoInfo);

            return new ResponseProvider(true, 201, "Medicamento registrado en tratamiento exitosamente", medicamentoTratamiento, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar el medicamento en el tratamiento", e, null).toResponse();
        }
    }

    /**
     * Crea un nuevo medicamento.
     *
     * @param nuevoMedicamento Objeto con los datos del medicamento a registrar.
     * @return Response con el resultado de la creación.
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMedicamento(Medicamento nuevoMedicamento) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Verifica que exista la información del medicamento
            MedicamentoInfo existeInfo = objDao.getById(MedicamentoInfo.class, "medicamentos_info", nuevoMedicamento.getId_medicamento_info());
            if (existeInfo == null) {
                return new ResponseProvider(false, 400, "No existe la información del medicamento", null, null).toResponse();
            }

            // Verifica que el número de lote no se repita
            MedicamentoDAO mediDAO = new MedicamentoDAO();
            boolean existeLote = mediDAO.existeLoteDeMedicamento(nuevoMedicamento.getId_medicamento_info(), nuevoMedicamento.getNumero_lote());
            if (existeLote) {
                return new ResponseProvider(false, 400, "Este lote ya está registrado para el medicamento seleccionado", null, null).toResponse();
            }

            // Crea el medicamento
            Medicamento medicamentoCreado = objDao.create("medicamentos", nuevoMedicamento);
            if (medicamentoCreado == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar el medicamento", null, null).toResponse();
            }

            // Construye el DTO de respuesta
            MedicamentoResponseDTO medicamentoDTO = new MedicamentoResponseDTO();
            medicamentoDTO.setId(medicamentoCreado.getId());
            medicamentoDTO.setPrecio(medicamentoCreado.getPrecio());
            medicamentoDTO.setCantidad(medicamentoCreado.getCantidad());
            medicamentoDTO.setNumero_lote(medicamentoCreado.getNumero_lote());
            medicamentoDTO.setFecha_caducidad(medicamentoCreado.getFecha_caducidad());
            medicamentoDTO.setInfo(existeInfo);

            return new ResponseProvider(true, 201, "Medicamento registrado exitosamente", medicamentoDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar el medicamento", e, null).toResponse();
        }
    }

    /**
     * Actualiza un medicamento existente.
     *
     * @param id ID del medicamento a actualizar.
     * @param medicamentoActualizado Objeto con la información actualizada del
     * medicamento.
     * @return Response con el resultado de la actualización.
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateMedicamento(@PathParam("id") int id, Medicamento medicamentoActualizado) {
        try {
            CrudDAO objDao = new CrudDAO();
            MedicamentoDAO mediDAO = new MedicamentoDAO();

            // Verifica que la información del medicamento exista
            MedicamentoInfo existeInfo = objDao.getById(MedicamentoInfo.class, "medicamentos_info", medicamentoActualizado.getId_medicamento_info());
            if (existeInfo == null) {
                return new ResponseProvider(false, 400, "No existe la información del medicamento", null, null).toResponse();
            }

            // Verifica que el medicamento a actualizar exista
            Medicamento medicamentoExistente = objDao.getById(Medicamento.class, "medicamentos", id);
            if (medicamentoExistente == null) {
                return new ResponseProvider(false, 404, "El medicamento no existe", null, null).toResponse();
            }

            // Verifica que el lote no esté duplicado en otro registro
            boolean existeLote = mediDAO.existeLoteDeMedicamento(medicamentoActualizado.getId_medicamento_info(),
                    medicamentoActualizado.getNumero_lote());
            if (existeLote && medicamentoExistente.getNumero_lote() != null
                    && !medicamentoExistente.getNumero_lote().equals(medicamentoActualizado.getNumero_lote())) {
                return new ResponseProvider(false, 400, "Este lote ya está registrado para el medicamento seleccionado", null, null).toResponse();
            }

            // Asigna el ID y actualiza
            medicamentoActualizado.setId(id);
            boolean actualizado = objDao.update(medicamentoActualizado, "medicamentos", "id");
            if (!actualizado) {
                return new ResponseProvider(false, 400, "No se pudo actualizar el medicamento", null, null).toResponse();
            }

            // Construye el DTO de respuesta
            MedicamentoResponseDTO medicamentoDTO = new MedicamentoResponseDTO();
            medicamentoDTO.setId(medicamentoActualizado.getId());
            medicamentoDTO.setPrecio(medicamentoActualizado.getPrecio());
            medicamentoDTO.setCantidad(medicamentoActualizado.getCantidad());
            medicamentoDTO.setNumero_lote(medicamentoActualizado.getNumero_lote());
            medicamentoDTO.setFecha_caducidad(medicamentoActualizado.getFecha_caducidad());
            medicamentoDTO.setInfo(existeInfo);

            return new ResponseProvider(true, 200, "Medicamento actualizado exitosamente", medicamentoDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar el medicamento", e, null).toResponse();
        }
    }

    /**
     * Actualiza la información de un medicamento.
     *
     * @param id ID de la información a actualizar.
     * @param nuevaInfo Objeto con la información actualizada.
     * @return Response con el resultado de la actualización.
     */
    @PUT
    @Path("/info/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateMedicamentoInfo(@PathParam("id") int id, MedicamentoInfo nuevaInfo) {
        try {
            CrudDAO objDao = new CrudDAO();

            nuevaInfo.setId(id);
            if (nuevaInfo.getId() == 0) {
                return new ResponseProvider(false, 400, "El ID de la información del medicamento es obligatorio para actualizar", null, null).toResponse();
            }

            // Verifica que la información exista
            MedicamentoInfo infoExistente = objDao.getById(MedicamentoInfo.class, "medicamentos_info", id);
            if (infoExistente == null) {
                return new ResponseProvider(false, 404, "La información de medicamento con ese ID no existe", null, null).toResponse();
            }

            boolean actualizada = objDao.update(nuevaInfo, "medicamentos_info", "id");
            if (!actualizada) {
                return new ResponseProvider(false, 400, "No se pudo actualizar la información del medicamento", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Información de medicamento actualizada exitosamente", nuevaInfo, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar la información de medicamento", e, null).toResponse();
        }
    }

    /**
     * Actualiza un medicamento dentro de un tratamiento.
     *
     * @param id ID del medicamento del tratamiento a actualizar.
     * @param actualizacion Objeto con los campos a actualizar (dosis,
     * frecuencia, duración).
     * @return Response con el resultado de la actualización.
     */
    @PUT
    @Path("/tratamiento/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateMedicamentoTratamiento(@PathParam("id") int id, MedicamentoTratamiento actualizacion) {
        try {
            CrudDAO objDao = new CrudDAO();

            MedicamentoTratamiento medicamentoExistente = objDao.getById(MedicamentoTratamiento.class, "medicamentos_tratamiento", id);
            if (medicamentoExistente == null) {
                return new ResponseProvider(false, 404, "Medicamento del tratamiento no encontrado", null, null).toResponse();
            }

            if (actualizacion.getDosis() != null && !actualizacion.getDosis().isEmpty()) {
                medicamentoExistente.setDosis(actualizacion.getDosis());
            }
            if (actualizacion.getFrecuencia_aplicacion() != null && !actualizacion.getFrecuencia_aplicacion().isEmpty()) {
                medicamentoExistente.setFrecuencia_aplicacion(actualizacion.getFrecuencia_aplicacion());
            }
            if (actualizacion.getDuracion() > 0) {
                medicamentoExistente.setDuracion(actualizacion.getDuracion());
            }

            boolean actualizado = objDao.update(medicamentoExistente, "medicamentos_tratamiento", "id");
            if (!actualizado) {
                return new ResponseProvider(false, 400, "No se pudo actualizar el medicamento del tratamiento", null, null).toResponse();
            }

            MedicamentoInfo medicamentoInfo = objDao.getById(MedicamentoInfo.class, "medicamentos_info", medicamentoExistente.getId_medicamento_info());

            MedicamentoTratamientoResponseDTO medicamentoDTO = new MedicamentoTratamientoResponseDTO();
            medicamentoDTO.setId(medicamentoExistente.getId());
            medicamentoDTO.setId_tratamiento(medicamentoExistente.getId_tratamiento());
            medicamentoDTO.setDosis(medicamentoExistente.getDosis());
            medicamentoDTO.setFrecuencia_aplicacion(medicamentoExistente.getFrecuencia_aplicacion());
            medicamentoDTO.setDuracion(medicamentoExistente.getDuracion());
            medicamentoDTO.setDuracionFormateada(formatearDias(medicamentoExistente.getDuracion()));

            if (medicamentoInfo != null) {
                medicamentoDTO.setMedicamento(medicamentoInfo);
            }

            return new ResponseProvider(true, 200, "Medicamento del tratamiento actualizado correctamente", medicamentoDTO, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar el medicamento del tratamiento", e, null).toResponse();
        }
    }

    /**
     * Elimina un medicamento de un tratamiento.
     *
     * @param id ID del medicamento del tratamiento a eliminar.
     * @return Response con el resultado de la eliminación.
     */
    @DELETE
    @Path("/tratamiento/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response eliminarMedicamentoTratamiento(@PathParam("id") int id) {
        try {
            MedicamentoTratamientoDAO dao = new MedicamentoTratamientoDAO(ConexionBD.conectar());
            boolean eliminado = dao.eliminarMedicamentoTratamiento(id);

            if (!eliminado) {
                return new ResponseProvider(false, 404, "No se encontró el medicamento del tratamiento o ya estaba eliminado", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Medicamento del tratamiento eliminado correctamente", null, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al eliminar el medicamento del tratamiento", e, null).toResponse();
        }
    }

    /**
     * Elimina la información de un medicamento. Solo permite eliminar si no
     * está asociada a inventario ni tratamientos.
     *
     * @param id ID de la información del medicamento a eliminar.
     * @return Response con el resultado de la eliminación.
     */
    @DELETE
    @Path("/info/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteMedicamentoInfo(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO();

            MedicamentoInfo medicamentoInfo = objDao.getById(MedicamentoInfo.class, "medicamentos_info", id);
            if (medicamentoInfo == null) {
                return new ResponseProvider(false, 404, "El medicamento no existe", null, null).toResponse();
            }

            List<Medicamento> medicamentosAsociados = objDao.getAllByField(Medicamento.class, "medicamentos", "id_medicamento_info", medicamentoInfo.getId());
            if (!medicamentosAsociados.isEmpty()) {
                return new ResponseProvider(false, 400, "El medicamento está asociado a un elemento del inventario y no puede eliminarse", null, null).toResponse();
            }

            List<MedicamentoTratamiento> tratamientosAsociados = objDao.getAllByField(MedicamentoTratamiento.class, "medicamentos_tratamiento", "id_medicamento_info", medicamentoInfo.getId());
            if (!tratamientosAsociados.isEmpty()) {
                return new ResponseProvider(false, 400, "El medicamento está asociado a tratamientos y no puede eliminarse", null, null).toResponse();
            }

            boolean eliminado = objDao.delete(id, "medicamentos_info", "id");
            if (!eliminado) {
                return new ResponseProvider(false, 400, "No se pudo eliminar el medicamento", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Medicamento eliminado exitosamente", null, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al eliminar el medicamento", e, null).toResponse();
        }
    }

    /**
     * Convierte un número de días a formato largo y corto.
     *
     * @param totalDias Número total de días.
     * @return Array con [0] = formato largo, [1] = formato corto.
     */
    public static String[] formatearDias(int totalDias) {
        final int DIAS_POR_MES = 30;
        final int DIAS_POR_SEMANA = 7;

        int meses = totalDias / DIAS_POR_MES;
        int diasRestantes = totalDias % DIAS_POR_MES;
        int semanas = diasRestantes / DIAS_POR_SEMANA;
        int dias = diasRestantes % DIAS_POR_SEMANA;

        StringBuilder formatoLargo = new StringBuilder();
        if (meses > 0) {
            formatoLargo.append(meses).append(" mes").append(meses > 1 ? "es" : "");
        }
        if (semanas > 0) {
            formatoLargo.append(formatoLargo.length() > 0 ? ", " : "").append(semanas).append(" semana").append(semanas > 1 ? "s" : "");
        }
        if (dias > 0) {
            formatoLargo.append(formatoLargo.length() > 0 ? " y " : "").append(dias).append(" día").append(dias > 1 ? "s" : "");
        }
        if (formatoLargo.length() == 0) {
            formatoLargo.append("0 días");
        }

        StringBuilder formatoCorto = new StringBuilder();
        if (meses > 0) {
            formatoCorto.append(meses).append(" mes ");
        }
        if (semanas > 0) {
            formatoCorto.append(semanas).append(" sem ");
        }
        if (dias > 0) {
            formatoCorto.append(dias).append(" dia");
        }
        if (formatoCorto.length() == 0) {
            formatoCorto.append("0d");
        }

        return new String[]{formatoLargo.toString(), formatoCorto.toString().trim()};
    }

}
