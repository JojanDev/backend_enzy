/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.Cliente;
import MODELO.CrudDAO;
import MODELO.Medicamento;
import MODELO.MedicamentoInfo;
import MODELO.MedicamentoResponseDTO;
import MODELO.MedicamentoTratamiento;
import MODELO.MedicamentoTratamientoResponseDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
@Path("medicamentos")
public class MedicamentoController {
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllMedicamentos() {
        try {
            CrudDAO objDao = new CrudDAO();
            
            List<Medicamento> medicamentos = objDao.getAll(Medicamento.class, "medicamentos");
                
            if (medicamentos.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay medicamentos registrados", null, null).toResponse();
            }
            
            List<MedicamentoResponseDTO> medicamentosDTO = new ArrayList<>();

           for (Medicamento m : medicamentos) {
               MedicamentoResponseDTO medicamentoDTO = new MedicamentoResponseDTO();

               medicamentoDTO.setId(m.getId());
               medicamentoDTO.setPrecio(m.getPrecio());
               medicamentoDTO.setStock(m.getStock());

               MedicamentoInfo infoMedicamento = objDao.getById(MedicamentoInfo.class, "medicamentos_info", m.getId_info());
               
               if (infoMedicamento == null) {
                   medicamentosDTO.add(medicamentoDTO);
                   continue;
               }

                medicamentoDTO.setInfo(infoMedicamento);

                medicamentosDTO.add(medicamentoDTO);
           }

            return new ResponseProvider(true, 200, "Medicamentos obtenidos correctamente", medicamentosDTO, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los medicamentos", e, null).toResponse(); 
        }
    }
    
    @GET
    @Path("/info/")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllMedicamentosInfo() {
        try {
            CrudDAO objDao = new CrudDAO();
            
            List<MedicamentoInfo> medicamentosInfo = objDao.getAll(MedicamentoInfo.class, "medicamentos_info");
                
            if (medicamentosInfo.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay medicamentos informativos registrados", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Medicamentos informativos obtenidos correctamente", medicamentosInfo, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los medicamentos informativos", e, null).toResponse(); 
        }
    }
    
    @GET
    @Path("/tratamiento/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMedicamentosByIdTratamiento(@PathParam("id") int idTratamiento) {
       try {
           CrudDAO objDao = new CrudDAO();

           List<MedicamentoTratamiento> medicamentosTratamiento = objDao.getAllByField(MedicamentoTratamiento.class, "medicamentos_tratamiento", "id_tratamiento", idTratamiento);


           if (medicamentosTratamiento.isEmpty()) {
               return new ResponseProvider(false, 404, "No hay medicamentos registrados en el tratamiento", null, null).toResponse();
           }

           List<MedicamentoTratamientoResponseDTO> medicamentosTratamientoDTO = new ArrayList<>();

           for (MedicamentoTratamiento mt : medicamentosTratamiento) {
               MedicamentoTratamientoResponseDTO medicamentoTratamiento = new MedicamentoTratamientoResponseDTO();

               medicamentoTratamiento.setDosis(mt.getDosis());
               medicamentoTratamiento.setDuracion(mt.getDuracion());
               medicamentoTratamiento.setFrecuencia_aplicacion(mt.getFrecuencia_aplicacion());
               medicamentoTratamiento.setId(mt.getId());

               MedicamentoInfo medicamentoInfo = objDao.getById(MedicamentoInfo.class, "medicamentos_info", mt.getId_medicamento_info());
               if (medicamentoInfo == null) {
                   medicamentosTratamientoDTO.add(medicamentoTratamiento);
                   continue;
               }

                medicamentoTratamiento.setMedicamento(medicamentoInfo);

                medicamentosTratamientoDTO.add(medicamentoTratamiento);
           }

           return new ResponseProvider(true, 200, "Tratamiento obtenido correctamente", medicamentosTratamientoDTO, null).toResponse(); 
       } catch (Exception e) {
           return new ResponseProvider(false, 500, "Error al obtener el tratamiento", e, null).toResponse(); 
       }
    }
    
    @POST
    @Path("/info/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMedicamentoInfo(MedicamentoInfo nuevaInfo) {
        try {
            CrudDAO objDao = new CrudDAO();
            MedicamentoInfo infoCreada = objDao.create("medicamentos_info", nuevaInfo);

            if (infoCreada == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar la nueva informacion de medicamento", null, null).toResponse();
            }
            
            return new ResponseProvider(true, 201, "Informacion de meidcamento registrada exitosamente", infoCreada, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar la informacion del medicamento", e, null).toResponse();
        }
    }
    
}
