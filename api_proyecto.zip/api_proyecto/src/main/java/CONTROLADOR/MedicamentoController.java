/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.Cliente;
import MODELO.CrudDAO;
import MODELO.MedicamentoInfo;
import MODELO.MedicamentoTratamiento;
import MODELO.MedicamentoTratamientoResponseDTO;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
@Path("medicamentos")
public class MedicamentoController {
     @GET
    @Path("/tratamiento/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMedicamentosByIdTratamiento(@PathParam("id") int idTratamiento) {
        try {
            CrudDAO objDao = new CrudDAO();
            
            List<MedicamentoTratamiento> medicamentosTratamiento = objDao.getAllByField(MedicamentoTratamiento.class, "medicamentos_tratamiento", "id_tratamiento", idTratamiento);
                
     
            if (medicamentosTratamiento.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay medicamentos registrados en el tratamiento", null, null).toResponse();
            }

            List<MedicamentoTratamientoResponseDTO> medicamentosTratamientoDTO = new ArrayList<>();

            for (MedicamentoTratamiento mt : medicamentosTratamiento) {
                MedicamentoTratamientoResponseDTO medicamentoTratamiento = new MedicamentoTratamientoResponseDTO();
                
                medicamentoTratamiento.setDosis(mt.getDosis());
                medicamentoTratamiento.setDuracion(mt.getDuracion());
                medicamentoTratamiento.setFrecuencia_aplicacion(mt.getFrecuencia_aplicacion());
                medicamentoTratamiento.setId(mt.getId());
       
                MedicamentoInfo medicamentoInfo = objDao.getById(MedicamentoInfo.class, "medicamentos_info", mt.getId_medicamento_info());
                if (medicamentoInfo == null) {
                    medicamentosTratamientoDTO.add(medicamentoTratamiento);
                    continue;
                }
                 
                 medicamentoTratamiento.setMedicamento(medicamentoInfo);
                 
                 medicamentosTratamientoDTO.add(medicamentoTratamiento);
            }

            return new ResponseProvider(true, 200, "Tratamiento obtenido correctamente", medicamentosTratamientoDTO, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener el tratamiento", e, null).toResponse(); 
        }
    }
}
