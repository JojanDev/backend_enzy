/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.Cliente;
import MODELO.ConexionBD;
import MODELO.CrudDAO;
import MODELO.Medicamento;
import MODELO.MedicamentoInfo;
import MODELO.MedicamentoResponseDTO;
import MODELO.MedicamentoTratamiento;
import MODELO.MedicamentoTratamientoDAO;
import MODELO.MedicamentoTratamientoResponseDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author USUARIO
 */
@Path("medicamentos")
public class MedicamentoController {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllMedicamentos() {
        try {
            CrudDAO objDao = new CrudDAO();

            List<Medicamento> medicamentos = objDao.getAll(Medicamento.class, "medicamentos");

            if (medicamentos.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay medicamentos registrados", null, null).toResponse();
            }

            List<MedicamentoResponseDTO> medicamentosDTO = new ArrayList<>();

            for (Medicamento m : medicamentos) {
                MedicamentoResponseDTO medicamentoDTO = new MedicamentoResponseDTO();

                medicamentoDTO.setId(m.getId());
                medicamentoDTO.setPrecio(m.getPrecio());
                medicamentoDTO.setCantidad(m.getCantidad());
                medicamentoDTO.setNumero_lote(m.getNumero_lote());
                medicamentoDTO.setFecha_caducidad(m.getFecha_caducidad());

                MedicamentoInfo infoMedicamento = objDao.getById(MedicamentoInfo.class, "medicamentos_info", m.getId_medicamento_info());

                if (infoMedicamento == null) {
                    medicamentosDTO.add(medicamentoDTO);
                    continue;
                }

                medicamentoDTO.setInfo(infoMedicamento);

                medicamentosDTO.add(medicamentoDTO);
            }

            return new ResponseProvider(true, 200, "Medicamentos obtenidos correctamente", medicamentosDTO, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los medicamentos", e, null).toResponse();
        }
    }

    @GET
    @Path("/info/")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllMedicamentosInfo() {
        try {
            CrudDAO objDao = new CrudDAO();

            List<MedicamentoInfo> medicamentosInfo = objDao.getAll(MedicamentoInfo.class, "medicamentos_info");

            if (medicamentosInfo.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay medicamentos informativos registrados", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Medicamentos informativos obtenidos correctamente", medicamentosInfo, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los medicamentos informativos", e, null).toResponse();
        }
    }

    @GET
    @Path("/tratamiento/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMedicamentosByIdTratamiento(@PathParam("id") int idTratamiento) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Obtenemos todos los medicamentos del tratamiento indicado
            List<MedicamentoTratamiento> medicamentosTratamiento = objDao.getAllByField(
                    MedicamentoTratamiento.class,
                    "medicamentos_tratamiento",
                    "id_tratamiento",
                    idTratamiento
            );

            // Filtramos para quedarnos solo con los activos
            medicamentosTratamiento = medicamentosTratamiento.stream()
                    .filter(mt -> Boolean.TRUE.equals(mt.isActivo())) // solo activos
                    .collect(Collectors.toList()); // volvemos a lista

            if (medicamentosTratamiento.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay medicamentos activos en el tratamiento", null, null).toResponse();
            }

            List<MedicamentoTratamientoResponseDTO> medicamentosTratamientoDTO = new ArrayList<>();

            for (MedicamentoTratamiento mt : medicamentosTratamiento) {
                MedicamentoTratamientoResponseDTO medicamentoTratamiento = new MedicamentoTratamientoResponseDTO();

                medicamentoTratamiento.setDosis(mt.getDosis());
                medicamentoTratamiento.setDuracion(mt.getDuracion());
                medicamentoTratamiento.setFrecuencia_aplicacion(mt.getFrecuencia_aplicacion());
                medicamentoTratamiento.setId(mt.getId());
                medicamentoTratamiento.setDuracionFormateada(formatearDias(mt.getDuracion()));

                // Obtenemos la info del medicamento
                MedicamentoInfo medicamentoInfo = objDao.getById(
                        MedicamentoInfo.class,
                        "medicamentos_info",
                        mt.getId_medicamento_info()
                );

                // Si no hay info, lo agregamos igual pero sin los detalles
                if (medicamentoInfo == null) {
                    medicamentosTratamientoDTO.add(medicamentoTratamiento);
                    continue;
                }

                medicamentoTratamiento.setMedicamento(medicamentoInfo);
                medicamentosTratamientoDTO.add(medicamentoTratamiento);
            }

            return new ResponseProvider(true, 200, "Medicamentos activos obtenidos correctamente", medicamentosTratamientoDTO, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los medicamentos del tratamiento", e, null).toResponse();
        }
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMedicamentoById(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO();

            Medicamento medicamento = objDao.getById(Medicamento.class, "medicamentos", id);

            if (medicamento == null) {
                return new ResponseProvider(false, 404, "Medicamento no encontrado", null, null).toResponse();
            }

            MedicamentoResponseDTO medicamentoDTO = new MedicamentoResponseDTO();

            medicamentoDTO.setId(medicamento.getId());
            medicamentoDTO.setPrecio(medicamento.getPrecio());
            medicamentoDTO.setCantidad(medicamento.getCantidad());
            medicamentoDTO.setNumero_lote(medicamento.getNumero_lote());
            medicamentoDTO.setFecha_caducidad(medicamento.getFecha_caducidad());

            MedicamentoInfo infoMedicamento = objDao.getById(MedicamentoInfo.class, "medicamentos_info", medicamento.getId_medicamento_info());

            medicamentoDTO.setInfo(infoMedicamento);

            return new ResponseProvider(true, 200, "Medicamento obtenido correctamente", medicamentoDTO, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener el medicamento", e, null).toResponse();
        }
    }

    @GET
    @Path("/info/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMedicamentoInfoById(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO();

            MedicamentoInfo medicamentoInfo = objDao.getById(MedicamentoInfo.class, "medicamentos_info", id);

            if (medicamentoInfo == null) {
                return new ResponseProvider(false, 404, "Informacion de medicamento no encontrada", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Informacion de medicamento obtenida correctamente", medicamentoInfo, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener el medicamento", e, null).toResponse();
        }
    }

    @POST
    @Path("/info/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMedicamentoInfo(MedicamentoInfo nuevaInfo) {
        try {
            CrudDAO objDao = new CrudDAO();
            MedicamentoInfo infoCreada = objDao.create("medicamentos_info", nuevaInfo);

            if (infoCreada == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar la nueva informacion de medicamento", null, null).toResponse();
            }

            return new ResponseProvider(true, 201, "Informacion de medicamento registrada exitosamente", infoCreada, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar la informacion del medicamento", e, null).toResponse();
        }
    }

    @POST
    @Path("/tratamiento/")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMedicamentoTratamiento(MedicamentoTratamiento nuevo) {
        try {
            CrudDAO objDao = new CrudDAO();
            MedicamentoTratamiento medicamentoCreado = objDao.create("medicamentos_tratamiento", nuevo);

            if (medicamentoCreado == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar el medicamento en el tratamiento", null, null).toResponse();
            }

            MedicamentoTratamientoResponseDTO medicamentoTratamiento = new MedicamentoTratamientoResponseDTO();

            medicamentoTratamiento.setDosis(medicamentoCreado.getDosis());
            medicamentoTratamiento.setDuracion(medicamentoCreado.getDuracion());
            medicamentoTratamiento.setFrecuencia_aplicacion(medicamentoCreado.getFrecuencia_aplicacion());
            medicamentoTratamiento.setId(medicamentoCreado.getId());
            medicamentoTratamiento.setDuracionFormateada(formatearDias(medicamentoCreado.getDuracion()));

            MedicamentoInfo medicamentoInfo = objDao.getById(MedicamentoInfo.class, "medicamentos_info", medicamentoCreado.getId_medicamento_info());

            medicamentoTratamiento.setMedicamento(medicamentoInfo);

            return new ResponseProvider(true, 201, "Medicamento registrado en tratamiento exitosamente", medicamentoTratamiento, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar el medicamento en el tratamiento", e, null).toResponse();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMedicamento(Medicamento nuevoMedicamento) {
        try {
            CrudDAO objDao = new CrudDAO();

            MedicamentoInfo existeInfo = objDao.getById(MedicamentoInfo.class, "medicamentos_info", nuevoMedicamento.getId_medicamento_info());

            if (existeInfo == null) {
                return new ResponseProvider(false, 400, "No existe la informacion del medicamento", null, null).toResponse();
            }

            Medicamento medicamentoCreado = objDao.create("medicamentos", nuevoMedicamento);

            if (medicamentoCreado == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar el medicamento", null, null).toResponse();
            }

            MedicamentoResponseDTO medicamentoDTO = new MedicamentoResponseDTO();

            medicamentoDTO.setId(medicamentoCreado.getId());
            medicamentoDTO.setPrecio(medicamentoCreado.getPrecio());
            medicamentoDTO.setCantidad(medicamentoCreado.getCantidad());
            medicamentoDTO.setNumero_lote(medicamentoCreado.getNumero_lote());
            medicamentoDTO.setFecha_caducidad(medicamentoCreado.getFecha_caducidad());

            MedicamentoInfo infoMedicamento = objDao.getById(MedicamentoInfo.class, "medicamentos_info", medicamentoCreado.getId_medicamento_info());

            medicamentoDTO.setInfo(infoMedicamento);

            return new ResponseProvider(true, 201, "Medicamento registrada exitosamente", medicamentoDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar el medicamento", e, null).toResponse();
        }
    }

    @PUT
    @Path("/info/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateMedicamentoInfo(@PathParam("id") int id, MedicamentoInfo nuevaInfo) {
        try {
            CrudDAO objDao = new CrudDAO();

            nuevaInfo.setId(id);
            // Validar si el ID está presente
            if (nuevaInfo.getId() == 0) {
                return new ResponseProvider(false, 400, "El ID de la informacion del medicamento es obligatorio para actualizar", null, null).toResponse();
            }

            // Verificar si la especie existe antes de actualizar
            MedicamentoInfo infoExistente = objDao.getById(MedicamentoInfo.class, "medicamentos_info", nuevaInfo.getId());

            if (infoExistente == null) {
                return new ResponseProvider(false, 404, "La informacion de medicamento con ese ID no existe", null, null).toResponse();
            }

            boolean actualizada = objDao.update(nuevaInfo, "medicamentos_info", "id");

            if (!actualizada) {
                return new ResponseProvider(false, 400, "No se pudo actualizar la informacion del medicamento", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Informacion de medicamento actualizada exitosamente", nuevaInfo, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar la Informacion de medicamento", e, null).toResponse();
        }
    }

    public static String[] formatearDias(int totalDias) {
        final int DIAS_POR_MES = 30;
        final int DIAS_POR_SEMANA = 7;

        int meses = totalDias / DIAS_POR_MES;
        int diasRestantes = totalDias % DIAS_POR_MES;

        int semanas = diasRestantes / DIAS_POR_SEMANA;
        int dias = diasRestantes % DIAS_POR_SEMANA;

        // Formato largo (ej: "2 meses, 1 semana y 3 días")
        StringBuilder formatoLargo = new StringBuilder();
        if (meses > 0) {
            formatoLargo.append(meses).append(" mes").append(meses > 1 ? "es" : "");
        }
        if (semanas > 0) {
            if (formatoLargo.length() > 0) {
                formatoLargo.append(", ");
            }
            formatoLargo.append(semanas).append(" semana").append(semanas > 1 ? "s" : "");
        }
        if (dias > 0) {
            if (formatoLargo.length() > 0) {
                formatoLargo.append(" y ");
            }
            formatoLargo.append(dias).append(" día").append(dias > 1 ? "s" : "");
        }
        if (formatoLargo.length() == 0) {
            formatoLargo.append("0 días");
        }

        // Formato corto (ej: "2m 1s 3d")
        StringBuilder formatoCorto = new StringBuilder();
        if (meses > 0) {
            formatoCorto.append(meses).append(" mes ");
        }
        if (semanas > 0) {
            formatoCorto.append(semanas).append(" sem ");
        }
        if (dias > 0) {
            formatoCorto.append(dias).append(" dia");
        }
        if (formatoCorto.length() == 0) {
            formatoCorto.append("0d");
        }

        return new String[]{formatoLargo.toString(), formatoCorto.toString().trim()};
    }
    
    @DELETE
    @Path("/tratamiento/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response eliminarMedicamentoTratamiento(@PathParam("id") int id) {
        try {
            MedicamentoTratamientoDAO dao = new MedicamentoTratamientoDAO(ConexionBD.conectar());

            boolean eliminado = dao.eliminarMedicamentoTratamiento(id);

            if (!eliminado) {
                return new ResponseProvider(false, 404, "No se encontró el medicamento del tratamiento o ya estaba eliminado", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Medicamento del tratamiento eliminado correctamente", null, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al eliminar el medicamento del tratamiento", e, null).toResponse();
        }
    }
}
