package CONTROLADOR;

import MODELO.CrudDAO;
import MODELO.LoginRequestDTO;
import MODELO.Personal;
import CONTROLADOR.ResponseProvider;
import MODELO.ConexionBD;
import MODELO.InformacionClientesPersonal;
import MODELO.PersonalDAO;
//import MODELO.PersonalPostResponseDTO;
import MODELO.IdResponse;
import MODELO.PersonalRequestDTO;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.Connection;
import java.util.List;

/**
 *
 * @author USUARIO
 */

@Path("personal")
public class PersonalController {
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response get() {
        try {
             CrudDAO objDao = new CrudDAO();
             List<Personal> personales = objDao.getAll(Personal.class, "personal");

            if (personales.isEmpty())
                return new ResponseProvider(true, 404, "No hay personal registrado", null, null).toResponse();
            
            return new ResponseProvider(true, 200, "Personal obtenido correctamente", personales, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(true, 500, "Error al obtener el personal", null, null).toResponse(); 
        }
    }
    
    //Metodo terminado
    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response postLogin(LoginRequestDTO loginDTO) {
        try {
             PersonalDAO objDao = new PersonalDAO();
        
             Personal personal = objDao.getByUsername(loginDTO.getUsuario());

            if (personal == null)
                return new ResponseProvider(true, 404, "Usuario no encontrado", null, null).toResponse();
            
            if(!personal.getContrasena().equals(loginDTO.getContrasena()))
                return new ResponseProvider(true, 404, "Contraseña incorrecta", null, null).toResponse(); 
                
            return new ResponseProvider(true, 200, "Datos de inicio de sesion validados correctamente", personal, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(true, 500, "Error al obtener el personal", null, null).toResponse(); 
        }
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createPersonal(PersonalRequestDTO personal) {
        Connection con = null;
        try {
            con = ConexionBD.conectar();
            con.setAutoCommit(false); // Inicia transacción manual

            CrudDAO objDao = new CrudDAO(con);

            // Crear y poblar objeto de información personal
            InformacionClientesPersonal infoPersonal = new InformacionClientesPersonal();
            infoPersonal.setIdTipoDocumento(personal.getIdTipoDocumento());
            infoPersonal.setNumeroDocumento(personal.getNumeroDocumento());
            infoPersonal.setNombre(personal.getNombre());
            infoPersonal.setTelefono(personal.getTelefono());
            infoPersonal.setCorreo(personal.getCorreo());
            infoPersonal.setDireccion(personal.getDireccion());

            // Insertar información personal
            InformacionClientesPersonal infoPersonalResponse = objDao.create(
                "informacion_clientes_personal",
                infoPersonal
            );

            if (infoPersonalResponse == null) {
                con.rollback();
                return new ResponseProvider<>(false, 500, "Error al crear la información personal", null, null).toResponse();
            }

            // Crear y poblar objeto personal
            Personal personalEntity = new Personal();
            personalEntity.setId_info(infoPersonalResponse.getId());
            personalEntity.setContrasena(personal.getContrasena());
            personalEntity.setUsuario(personal.getUsuario());
            personalEntity.setId_rol(2);

            // Insertar personal
            Personal personalResponse = objDao.create(
                "personal",
                personalEntity
            );

            if (personalResponse == null) {
                con.rollback();
                return new ResponseProvider<>(false, 500, "Error al crear el usuario personal", null, null).toResponse();
            }

            // Si todo fue bien
            con.commit();

           // Al final del try, después de insertar Personal correctamente:
//            PersonalPostResponseDTO responseDto = new PersonalPostResponseDTO(
//                personalResponse.getId(),
//                infoPersonalResponse.getId(),
//                personalResponse.getUsuario(),
//                infoPersonalResponse.getNombre(),
//                infoPersonalResponse.getCorreo()
//            );

            return new ResponseProvider<>(true, 201, "Personal creado correctamente", new IdResponse(personalResponse.getId()), null).toResponse();


        } catch (Exception e) {
            try {
                if (con != null) con.rollback();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return new ResponseProvider<>(false, 500, "Error inesperado al crear el personal", null, null).toResponse();
        } finally {
            try {
                if (con != null) con.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }


//    
    //     @PUT
//    @Path("/{id}")
//    @Consumes(MediaType.APPLICATION_JSON)
//    public Response actualizarPersona(@PathParam("id") int id, Personal personal) {
//        try {
//            Personal existing = buscarPersonaPorId(id);
//            if (existing == null) {
//                return Response.status(Response.Status.NOT_FOUND).build();
//            }
//            existing.setId_info(personal.getId_info());
//            existing.setContrasena(personal.getContrasena());
//            existing.setRoles(personal.getRoles());
//            existing.setUsuario(personal.getUsuario());
//
//            if (actualizarEnBD(existing)) {
//                return Response.ok(existing).build();
//            } else {
//                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//            }
//        } catch (SQLException e) {
//            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//        }
//    }
//
//    @PATCH
//    @Path("/{id}")
//    @Consumes(MediaType.APPLICATION_JSON)
//    public Response actualizarPersonaParcial(@PathParam("id") int id, Personal persona) {
//        try {
//            Personal existing = buscarPersonaPorId(id);
//            if (existing == null) {
//                return Response.status(Response.Status.NOT_FOUND).build();
//            }
//            if (persona.getContrasena() != null) {
//                existing.setContrasena(persona.getContrasena());
//            }
//            if (persona.getId_info()!= 0) {
//                existing.setId_info(persona.getId_info());
//            }
//            if (persona.getRoles()!= null) {
//                existing.setRoles(persona.getRoles());
//            }
//            
//            if (persona.getUsuario() != null) {
//                existing.setUsuario(persona.getUsuario());
//            }
//
//            if (actualizarEnBD(existing)) {
//                return Response.ok(existing).build();
//            } else {
//                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//            }
//        } catch (SQLException e) {
//            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//        }
//    }
//
//    @DELETE
//    @Path("/{id}")
//    public Response eliminarPersona(@PathParam("id") int id) {
//        try {
//            Personal existing = buscarPersonaPorId(id);
//            if (existing == null) {
//                return Response.status(Response.Status.NOT_FOUND).build();
//            }
//            if (eliminarDeBD(id)) {
//                return Response.noContent().build();
//            } else {
//                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//            }
//        } catch (SQLException e) {
//            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//        }
//    }
//
//    private Personal buscarPersonaPorId(int id) throws SQLException {
//        Personal persona = null;
//        try (Connection conn = ConexionBD.conectar();
//             PreparedStatement stmt = conn.prepareStatement("SELECT id, id_info, usuario, contrasena, roles FROM personal WHERE id = ?")) {
//            stmt.setInt(1, id);
//            try (ResultSet rs = stmt.executeQuery()) {
//                if (rs.next()) {
//                    persona = new Personal();
//                    persona.setId(rs.getInt("id"));
//                    persona.setContrasena(rs.getString("contrasena"));
//                    persona.setId_info(rs.getInt("id_info"));
//                    persona.setRoles(rs.getString("roles"));       
//                    persona.setUsuario(rs.getString("usuario"));
//                }
//            }
//        }
//        return persona;
//    }
//
//    private boolean actualizarEnBD(Personal personal) throws SQLException {
//        try (Connection conn = ConexionBD.conectar();
//             PreparedStatement stmt = conn.prepareStatement("UPDATE personal SET id_info = ?, usuario = ?, contrasena = ?, roles = ? WHERE id = ?")) {
//            stmt.setInt(1, personal.getId_info());
//            stmt.setString(2, personal.getUsuario());
//            stmt.setString(3, personal.getContrasena());
//            stmt.setString(4, personal.getRoles());
//            stmt.setInt(5, personal.getId());
//            return stmt.executeUpdate() > 0;
//        }
//    }
//
//    private boolean eliminarDeBD(int id) throws SQLException {
//        try (Connection conn = ConexionBD.conectar();
//             PreparedStatement stmt = conn.prepareStatement("DELETE FROM personal WHERE id = ?")) {
//            stmt.setInt(1, id);
//            return stmt.executeUpdate() > 0;
//        }
//    }
}