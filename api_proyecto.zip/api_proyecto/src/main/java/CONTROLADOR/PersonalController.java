package CONTROLADOR;

import MODELO.CrudDAO;
import MODELO.LoginRequestDTO;
import MODELO.Personal;
import CONTROLADOR.ResponseProvider;
import MODELO.ClienteRequestDTO;
import MODELO.ConexionBD;
import MODELO.IcpResponseDTO;
import MODELO.InformacionClientesPersonal;
import MODELO.PersonalDAO;
//import MODELO.PersonalPostResponseDTO;
import MODELO.IdResponse;
import MODELO.PersonalRequestDTO;
import MODELO.PersonalResponseDTO;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import modelo.ClienteDtoBuilder;

/**
 *
 * @author USUARIO
 */
@Path("personal")
public class PersonalController {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll() {
        try {
            CrudDAO objDao = new CrudDAO();
            List<Personal> personales = objDao.getAll(Personal.class, "personal");

            if (personales.isEmpty()) {
                return new ResponseProvider(true, 404, "No hay personal registrado", null, null).toResponse();
            }

            List<PersonalResponseDTO> personalesDTO = new ArrayList<>();

            for (Personal p : personales) {
                PersonalResponseDTO personalDTO = new PersonalResponseDTO();

                personalDTO.setId(p.getId());
                personalDTO.setUsuario(p.getUsuario());
                personalDTO.setId_rol(p.getId_rol());

                InformacionClientesPersonal info = objDao.getById(InformacionClientesPersonal.class, "informacion_clientes_personal", p.getId_info());

                IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);

                personalDTO.setInfo(infoDTO);

                personalesDTO.add(personalDTO);
            }

            return new ResponseProvider(true, 200, "Personal obtenido correctamente", personalesDTO, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(true, 500, "Error al obtener el personal", null, null).toResponse();
        }
    }

    @GET
    @Path("/noClientes")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getInfoPersonalSinClientes() {
        try {
            PersonalDAO objDao = new PersonalDAO();
            List<InformacionClientesPersonal> clientesInfo = objDao.getEmpleadosSinCliente();

            if (clientesInfo.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay informacion valida registrada", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Informacion obtenida correctamente", clientesInfo, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los datos", e, null).toResponse();
        }
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getPersonalById(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO();
            Personal personal = objDao.getById(Personal.class, "personal", id);

            if (personal == null) {
                return new ResponseProvider(true, 404, "Este empleado no existe", null, null).toResponse();
            }

            PersonalResponseDTO personalDTO = new PersonalResponseDTO();

            personalDTO.setId(personal.getId());
            personalDTO.setUsuario(personal.getUsuario());
            personalDTO.setId_rol(personal.getId_rol());

            InformacionClientesPersonal info = objDao.getById(InformacionClientesPersonal.class, "informacion_clientes_personal", personal.getId_info());

            IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);

            personalDTO.setInfo(infoDTO);

            return new ResponseProvider(true, 200, "Empleado obtenido correctamente", personalDTO, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(true, 500, "Error al obtener el empleado", null, null).toResponse();
        }
    }

    //Metodo terminado
    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response postLogin(LoginRequestDTO loginDTO) {
        try {
            PersonalDAO objDao = new PersonalDAO();

            Personal personal = objDao.getByUsername(loginDTO.getUsuario());

            if (personal == null) {
                return new ResponseProvider(true, 404, "Usuario no encontrado", null, null).toResponse();
            }

            if (!personal.getContrasena().equals(loginDTO.getContrasena())) {
                return new ResponseProvider(true, 404, "Contraseña incorrecta", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Datos de inicio de sesion validados correctamente", personal, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(true, 500, "Error al obtener el personal", null, null).toResponse();
        }
    }

    @POST
    @Path("/infoExistente")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createPersonalInformacionExistente(Personal nuevoPersonal) {
        try {
            CrudDAO objDao = new CrudDAO();

            List<Personal> personalExistente = objDao.getAllByField(Personal.class, "personal", "id_info", nuevoPersonal.getId_info());

            if (!personalExistente.isEmpty()) {
                return new ResponseProvider(false, 400, "El empleado ya esta registrado", null, null).toResponse();
            }

            PersonalDAO personalDAO = new PersonalDAO();

            Personal personal = personalDAO.getByUsername(nuevoPersonal.getUsuario());

            if (personal != null) {
                return new ResponseProvider(false, 400, "El nombre de usuario ya esta registrado, ingrese uno diferente", null, null).toResponse();
            }

            nuevoPersonal.setId_rol(2);
            Personal personalCreado = objDao.create("personal", nuevoPersonal);

            if (personalCreado == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar el empleado", null, null).toResponse();
            }

            PersonalResponseDTO personalCreadoDTO = new PersonalResponseDTO();

            personalCreadoDTO.setId(personalCreado.getId());

            InformacionClientesPersonal info = objDao.getById(InformacionClientesPersonal.class, "informacion_clientes_personal", personalCreado.getId_info());

            IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);

            personalCreadoDTO.setInfo(infoDTO);
            personalCreadoDTO.setUsuario(personalCreado.getUsuario());

            return new ResponseProvider(true, 201, "Empleado registrado exitosamente", personalCreadoDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar el empleado", e, null).toResponse();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createPersonal(PersonalRequestDTO personal) {
        PersonalDAO personalDAO = new PersonalDAO();

        Personal usuarioExistente = personalDAO.getByUsername(personal.getUsuario());

        if (usuarioExistente != null) {
            return new ResponseProvider(false, 400, "El nombre de usuario ya esta registrado, ingrese uno diferente", null, null).toResponse();
        }
        Connection con = null;
        try {
            con = ConexionBD.conectar();
            con.setAutoCommit(false); // Inicia transacción manual

            CrudDAO objDao = new CrudDAO(con);

            // Crear y poblar objeto de información personal
            InformacionClientesPersonal infoPersonal = new InformacionClientesPersonal();
            infoPersonal.setId_tipo_documento(personal.getId_tipo_documento());
            infoPersonal.setNumero_documento(personal.getNumero_documento());
            infoPersonal.setNombre(personal.getNombre());
            infoPersonal.setTelefono(personal.getTelefono());
            infoPersonal.setCorreo(personal.getCorreo());
            infoPersonal.setDireccion(personal.getDireccion());

            // Insertar información personal
            InformacionClientesPersonal infoPersonalResponse = objDao.create(
                    "informacion_clientes_personal",
                    infoPersonal
            );

            if (infoPersonalResponse == null) {
                con.rollback();
                return new ResponseProvider<>(false, 500, "Error al crear la información personal", null, null).toResponse();
            }

            // Crear y poblar objeto personal
            Personal personalEntity = new Personal();
            personalEntity.setId_info(infoPersonalResponse.getId());
            personalEntity.setContrasena(personal.getContrasena());
            personalEntity.setUsuario(personal.getUsuario());
            personalEntity.setId_rol(2);

            // Insertar personal
            Personal personalResponse = objDao.create(
                    "personal",
                    personalEntity
            );

            if (personalResponse == null) {
                con.rollback();
                return new ResponseProvider<>(false, 500, "Error al crear el usuario personal", null, null).toResponse();
            }

            // Si todo fue bien
            con.commit();

            // Al final del try, después de insertar Personal correctamente:
//            PersonalPostResponseDTO responseDto = new PersonalPostResponseDTO(
//                personalResponse.getId(),
//                infoPersonalResponse.getId(),
//                personalResponse.getUsuario(),
//                infoPersonalResponse.getNombre(),
//                infoPersonalResponse.getCorreo()
//            );
            return new ResponseProvider<>(true, 201, "Personal creado correctamente", new IdResponse(personalResponse.getId()), null).toResponse();

        } catch (Exception e) {
            try {
                if (con != null) {
                    con.rollback();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return new ResponseProvider<>(false, 500, "Error inesperado al crear el personal", null, null).toResponse();
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updatePersonal(@PathParam("id") int id, InformacionClientesPersonal personalInfoActualizado) {
        try {
            System.out.println("numero_documento recibido: " + personalInfoActualizado.getNumero_documento());
            CrudDAO objDao = new CrudDAO();

            personalInfoActualizado.setId(id);
            // Validar si el ID está presente
            if (personalInfoActualizado.getId() == 0) {
                return new ResponseProvider(false, 400, "El ID de la informacion es obligatorio para actualizar", null, null).toResponse();
            }

            // Verificar si la especie existe antes de actualizar
            InformacionClientesPersonal infoExistente = objDao.getById(InformacionClientesPersonal.class, "informacion_clientes_personal", id);

            if (infoExistente == null) {
                return new ResponseProvider(false, 404, "El empleado con ese ID de informacion no existe", null, null).toResponse();
            }

            boolean actualizada = objDao.update(personalInfoActualizado, "informacion_clientes_personal", "id");

            if (!actualizada) {
                return new ResponseProvider(false, 400, "No se pudo actualizar la informacion del empleado", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Informacion del empleado actualizada exitosamente", personalInfoActualizado, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar la informacion del empleado", e, null).toResponse();
        }
    }

    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deletePersonal(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Verificar si el tipo de producto existe
            Personal personalExistente = objDao.getById(Personal.class, "personal", id);

            if (personalExistente == null) {
                return new ResponseProvider(false, 404, "El empleado no existe", null, null).toResponse();
            }

            personalExistente.setActivo(false);

            // Eliminar tipo de producto
            boolean eliminado = objDao.update(personalExistente, "personal", "id");

            if (!eliminado) {
                return new ResponseProvider(false, 400, "No se pudo desactivar el empleado", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Empleado desactivado exitosamente", null, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al desactivar el empleado", e, null).toResponse();
        }
    }
}
