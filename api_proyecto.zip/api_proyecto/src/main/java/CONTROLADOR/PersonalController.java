package CONTROLADOR;

import MODELO.CrudDAO;
import MODELO.LoginDTO;
import MODELO.Personal;
import CONTROLADOR.ResponseProvider;
import MODELO.PersonalDAO;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 *
 * @author USUARIO
 */

@Path("personal")
public class PersonalController {
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response get() {
        try {
            final CrudDAO objDao = new CrudDAO();
            final List<Personal> personales = objDao.getAll(Personal.class, "personal");

            if (personales.isEmpty())
                return new ResponseProvider(true, 404, "No hay personal registrado", null, null).toResponse();
            
            return new ResponseProvider(true, 200, "Personal obtenido correctamente", personales, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(true, 500, "Error al obtener el personal", null, null).toResponse(); 
        }
        
        
        
        
//        return com.jojandev.api.controller.PersonalController.getAllPersonal();
//        try {
//            ResponseProvider response = PersonalService.getPersonales();
//            return response.toResponse();
//        } catch (Exception e) {
//            return new ResponseProvider(false, 500, "Error interno del servidor", null, null).toResponse();
//        }
//        try {
//            final CrudDAO objDao = new CrudDAO();
//            final List<Personal> personales = objDao.getAll("personal");
//
//            if (personales.isEmpty())
//                return new ResponseProvider(true, 404, "No hay personal registrado", null, null);
//            
//            return new ResponseProvider(true, 200, "Personal obtenido correctamente", personales, null); 
//        } catch (Exception e) {
//            return new ResponseProvider(true, 500, "Error al obtener el personal", null, null); 
//        }
    }
    
    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response postLogin(LoginDTO loginDTO) {
//        return com.jojandev.api.controller.PersonalController.login(loginDTO);
        try {
            final PersonalDAO objDao = new PersonalDAO();
        
            final Personal personal = objDao.getByUsername(loginDTO.getUsuario());

            if (personal == null)
                return new ResponseProvider(true, 404, "Usuario no encontrado", null, null).toResponse();
            
            if(!personal.getContrasena().equals(loginDTO.getContrasena()))
                return new ResponseProvider(true, 404, "Contrase�a incorrecta", null, null).toResponse(); 
                
            return new ResponseProvider(true, 200, "Datos de inicio de sesion validados correctamente", personal, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(true, 500, "Error al obtener el personal", null, null).toResponse(); 
        }
    }
//
//    @POST
//    @Consumes(MediaType.APPLICATION_JSON)
//    public Response post(Personal personal) {
//        return com.jojandev.api.controller.PersonalController.createPersonal(personal);
//    }
    
    //     @PUT
//    @Path("/{id}")
//    @Consumes(MediaType.APPLICATION_JSON)
//    public Response actualizarPersona(@PathParam("id") int id, Personal personal) {
//        try {
//            Personal existing = buscarPersonaPorId(id);
//            if (existing == null) {
//                return Response.status(Response.Status.NOT_FOUND).build();
//            }
//            existing.setId_info(personal.getId_info());
//            existing.setContrasena(personal.getContrasena());
//            existing.setRoles(personal.getRoles());
//            existing.setUsuario(personal.getUsuario());
//
//            if (actualizarEnBD(existing)) {
//                return Response.ok(existing).build();
//            } else {
//                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//            }
//        } catch (SQLException e) {
//            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//        }
//    }
//
//    @PATCH
//    @Path("/{id}")
//    @Consumes(MediaType.APPLICATION_JSON)
//    public Response actualizarPersonaParcial(@PathParam("id") int id, Personal persona) {
//        try {
//            Personal existing = buscarPersonaPorId(id);
//            if (existing == null) {
//                return Response.status(Response.Status.NOT_FOUND).build();
//            }
//            if (persona.getContrasena() != null) {
//                existing.setContrasena(persona.getContrasena());
//            }
//            if (persona.getId_info()!= 0) {
//                existing.setId_info(persona.getId_info());
//            }
//            if (persona.getRoles()!= null) {
//                existing.setRoles(persona.getRoles());
//            }
//            
//            if (persona.getUsuario() != null) {
//                existing.setUsuario(persona.getUsuario());
//            }
//
//            if (actualizarEnBD(existing)) {
//                return Response.ok(existing).build();
//            } else {
//                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//            }
//        } catch (SQLException e) {
//            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//        }
//    }
//
//    @DELETE
//    @Path("/{id}")
//    public Response eliminarPersona(@PathParam("id") int id) {
//        try {
//            Personal existing = buscarPersonaPorId(id);
//            if (existing == null) {
//                return Response.status(Response.Status.NOT_FOUND).build();
//            }
//            if (eliminarDeBD(id)) {
//                return Response.noContent().build();
//            } else {
//                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//            }
//        } catch (SQLException e) {
//            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
//        }
//    }
//
//    private Personal buscarPersonaPorId(int id) throws SQLException {
//        Personal persona = null;
//        try (Connection conn = ConexionBD.conectar();
//             PreparedStatement stmt = conn.prepareStatement("SELECT id, id_info, usuario, contrasena, roles FROM personal WHERE id = ?")) {
//            stmt.setInt(1, id);
//            try (ResultSet rs = stmt.executeQuery()) {
//                if (rs.next()) {
//                    persona = new Personal();
//                    persona.setId(rs.getInt("id"));
//                    persona.setContrasena(rs.getString("contrasena"));
//                    persona.setId_info(rs.getInt("id_info"));
//                    persona.setRoles(rs.getString("roles"));       
//                    persona.setUsuario(rs.getString("usuario"));
//                }
//            }
//        }
//        return persona;
//    }
//
//    private boolean actualizarEnBD(Personal personal) throws SQLException {
//        try (Connection conn = ConexionBD.conectar();
//             PreparedStatement stmt = conn.prepareStatement("UPDATE personal SET id_info = ?, usuario = ?, contrasena = ?, roles = ? WHERE id = ?")) {
//            stmt.setInt(1, personal.getId_info());
//            stmt.setString(2, personal.getUsuario());
//            stmt.setString(3, personal.getContrasena());
//            stmt.setString(4, personal.getRoles());
//            stmt.setInt(5, personal.getId());
//            return stmt.executeUpdate() > 0;
//        }
//    }
//
//    private boolean eliminarDeBD(int id) throws SQLException {
//        try (Connection conn = ConexionBD.conectar();
//             PreparedStatement stmt = conn.prepareStatement("DELETE FROM personal WHERE id = ?")) {
//            stmt.setInt(1, id);
//            return stmt.executeUpdate() > 0;
//        }
//    }
}