package CONTROLADOR;

import MODELO.CrudDAO;
import MODELO.LoginRequestDTO;
import MODELO.Personal;
import CONTROLADOR.ResponseProvider;
import MODELO.ConexionBD;
import MODELO.IcpResponseDTO;
import MODELO.InformacionClientesPersonal;
import MODELO.PersonalDAO;
import MODELO.IdResponse;
import MODELO.PersonalRequestDTO;
import MODELO.PersonalResponseDTO;
import MODELO.Rol;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import modelo.ClienteDtoBuilder;
/**
 * Controlador REST para manejar las operaciones relacionadas con el personal.
 * Proporciona endpoints para obtener, crear, actualizar y eliminar informaci�n de empleados.
 * 
 * @author USUARIO
 */
@Path("personal") // Define la ruta base para este controlador
public class PersonalController {

    /**
     * Obtiene todos los empleados registrados.
     *
     * @return Response con la lista de empleados o un mensaje de error.
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON) // Especifica que el m�todo produce JSON
    public Response getAll() {
        try {
            CrudDAO objDao = new CrudDAO(); // Crea una instancia de CrudDAO
            List<Personal> personales = objDao.getAll(Personal.class, "personal"); // Obtiene todos los empleados

            if (personales.isEmpty()) {
                // Si no hay empleados, retorna un mensaje de error
                return new ResponseProvider(true, 404, "No hay personal registrado", null, null).toResponse();
            }

            List<PersonalResponseDTO> personalesDTO = new ArrayList<>(); // Lista para almacenar los DTOs de empleados

            // Itera sobre cada empleado y convierte a DTO
            for (Personal p : personales) {
                PersonalResponseDTO personalDTO = new PersonalResponseDTO();
                personalDTO.setId(p.getId()); // Establece el ID
                personalDTO.setUsuario(p.getUsuario()); // Establece el usuario

                // Obtiene el rol del empleado
                Rol rol = objDao.getById(Rol.class, "roles", p.getId_rol());
                personalDTO.setRol(rol); // Establece el rol

                // Obtiene la informaci�n del cliente asociada al empleado
                InformacionClientesPersonal info = objDao.getById(InformacionClientesPersonal.class, "informacion_clientes_personal", p.getId_info());
                IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);
                personalDTO.setInfo(infoDTO); // Establece la informaci�n del cliente
                personalDTO.setActivo(p.isActivo()); // Establece el estado activo

                personalesDTO.add(personalDTO); // Agrega el DTO a la lista
            }

            // Retorna la lista de empleados en formato JSON
            return new ResponseProvider(true, 200, "Personal obtenido correctamente", personalesDTO, null).toResponse();
        } catch (Exception e) {
            // Manejo de errores
            return new ResponseProvider(true, 500, "Error al obtener el personal", null, null).toResponse();
        }
    }

    /**
     * Obtiene informaci�n de empleados que no est�n asociados a ning�n cliente.
     *
     * @return Response con la lista de empleados sin cliente o un mensaje de error.
     */
    @GET
    @Path("/noClientes") // Ruta espec�fica para obtener empleados sin clientes
    @Produces(MediaType.APPLICATION_JSON)
    public Response getInfoPersonalSinClientes() {
        try {
            PersonalDAO objDao = new PersonalDAO(); // Crea una instancia de PersonalDAO
            List<InformacionClientesPersonal> clientesInfo = objDao.getEmpleadosSinCliente(); // Obtiene empleados sin cliente

            if (clientesInfo.isEmpty()) {
                // Si no hay informaci�n, retorna un mensaje de error
                return new ResponseProvider(false, 404, "No hay informacion valida registrada", null, null).toResponse();
            }

            // Retorna la informaci�n obtenida
            return new ResponseProvider(true, 200, "Informacion obtenida correctamente", clientesInfo, null).toResponse();
        } catch (Exception e) {
            // Manejo de errores
            return new ResponseProvider(false, 500, "Error al obtener los datos", e, null).toResponse();
        }
    }
    
    /**
     * Obtiene la lista de veterinarios activos.
     *
     * @return Response con la lista de veterinarios o un mensaje de error.
     */
    @GET
    @Path("/veterinarios") // Ruta espec�fica para obtener veterinarios
    @Produces(MediaType.APPLICATION_JSON)
    public Response getPersonalVeterinario() {
        try {
            PersonalDAO personalDao = new PersonalDAO(); // Crea una instancia de PersonalDAO
            CrudDAO objDao = new CrudDAO(); // Crea una instancia de CrudDAO
            
            List<Personal> veterinarios = personalDao.obtenerVeterinariosActivos(); // Obtiene veterinarios activos

            if (veterinarios.isEmpty()) {
                // Si no hay veterinarios, retorna un mensaje de error
                return new ResponseProvider(false, 404, "No hay personal Veterinario registrado, registre personal veterinario para hacer registros de tratamientos", null, null).toResponse();
            }
            
            List<PersonalResponseDTO> personalesDTO = new ArrayList<>(); // Lista para almacenar los DTOs de veterinarios

            // Itera sobre cada veterinario y convierte a DTO
            for (Personal p : veterinarios) {
                PersonalResponseDTO personalDTO = new PersonalResponseDTO();
                personalDTO.setId(p.getId()); // Establece el ID

                // Obtiene la informaci�n del cliente asociada al veterinario
                InformacionClientesPersonal info = objDao.getById(InformacionClientesPersonal.class, "informacion_clientes_personal", p.getId_info());
                IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);
                personalDTO.setInfo(infoDTO); // Establece la informaci�n del cliente

                personalesDTO.add(personalDTO); // Agrega el DTO a la lista
            }

            // Retorna la lista de veterinarios en formato JSON
            return new ResponseProvider(true, 200, "Veterinarios obtenidos correctamente", personalesDTO, null).toResponse();
        } catch (Exception e) {
            // Manejo de errores
            return new ResponseProvider(false, 500, "Error al obtener los datos", e, null).toResponse();
        }
    }

    /**
     * Obtiene un empleado por su ID.
     *
     * @param id ID del empleado a buscar.
     * @return Response con la informaci�n del empleado o un mensaje de error.
     */
    @GET
    @Path("/{id}") // Ruta para obtener un empleado espec�fico
    @Produces(MediaType.APPLICATION_JSON)
    public Response getPersonalById(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO(); // Crea una instancia de CrudDAO
            Personal personal = objDao.getById(Personal.class, "personal", id); // Obtiene el empleado por ID

            if (personal == null) {
                // Si no se encuentra el empleado, retorna un mensaje de error
                return new ResponseProvider(true, 404, "Este empleado no existe", null, null).toResponse();
            }

            PersonalResponseDTO personalDTO = new PersonalResponseDTO(); // Crea un DTO para el empleado
            personalDTO.setId(personal.getId()); // Establece el ID
            personalDTO.setUsuario(personal.getUsuario()); // Establece el usuario

            // Obtiene el rol del empleado
            Rol rol = objDao.getById(Rol.class, "roles", personal.getId_rol());
            personalDTO.setRol(rol); // Establece el rol

            // Obtiene la informaci�n del cliente asociada al empleado
            InformacionClientesPersonal info = objDao.getById(InformacionClientesPersonal.class, "informacion_clientes_personal", personal.getId_info());
            IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);
            personalDTO.setInfo(infoDTO); // Establece la informaci�n del cliente
            personalDTO.setActivo(personal.isActivo()); // Establece el estado activo

            // Retorna la informaci�n del empleado en formato JSON
            return new ResponseProvider(true, 200, "Empleado obtenido correctamente", personalDTO, null).toResponse();
        } catch (Exception e) {
            // Manejo de errores
            return new ResponseProvider(true, 500, "Error al obtener el empleado", null, null).toResponse();
        }
    }

    /**
     * Maneja el inicio de sesi�n de un empleado.
     *
     * @param loginDTO Objeto que contiene las credenciales de inicio de sesi�n.
     * @return Response con el resultado del inicio de sesi�n.
     */
    @POST
    @Path("/login") // Ruta para el inicio de sesi�n
    @Consumes(MediaType.APPLICATION_JSON) // Especifica que el m�todo consume JSON
    @Produces(MediaType.APPLICATION_JSON)
    public Response postLogin(LoginRequestDTO loginDTO) {
        try {
            PersonalDAO objDao = new PersonalDAO(); // Crea una instancia de PersonalDAO

            // Obtiene el empleado por nombre de usuario
            Personal personal = objDao.getByUsername(loginDTO.getUsuario());

            if (personal == null) {
                // Si no se encuentra el empleado, retorna un mensaje de error
                return new ResponseProvider(true, 404, "Usuario no encontrado", null, null).toResponse();
            }
            
            // Verifica la contrase�a
            if (!personal.getContrasena().equals(loginDTO.getContrasena())) {
                return new ResponseProvider(true, 404, "Contrasena incorrecta", null, null).toResponse();
            }

            // Verifica si el usuario est� activo
            if (!personal.isActivo()) {
                return new ResponseProvider(true, 400, "Eres un usuario desactivado, contactate con un administrador", null, null).toResponse();
            }
            
            // Retorna un mensaje de �xito si las credenciales son v�lidas
            return new ResponseProvider(true, 200, "Datos de inicio de sesion validados correctamente", personal, null).toResponse();
        } catch (Exception e) {
            // Manejo de errores
            return new ResponseProvider(true, 500, "Error al obtener el personal", null, null).toResponse();
        }
    }

    /**
     * Crea un nuevo empleado utilizando informaci�n existente.
     *
     * @param nuevoPersonal Objeto que contiene la informaci�n del nuevo empleado.
     * @return Response con el resultado de la creaci�n.
     */
    @POST
    @Path("/infoExistente") // Ruta para crear un empleado con informaci�n existente
    @Consumes(MediaType.APPLICATION_JSON) // Especifica que el m�todo consume JSON
    @Produces(MediaType.APPLICATION_JSON)
    public Response createPersonalInformacionExistente(Personal nuevoPersonal) {
        try {
            CrudDAO objDao = new CrudDAO(); // Crea una instancia de CrudDAO

            // Verifica si ya existe un empleado con la misma informaci�n
            List<Personal> personalExistente = objDao.getAllByField(Personal.class, "personal", "id_info", nuevoPersonal.getId_info());

            if (!personalExistente.isEmpty()) {
                // Si ya existe, retorna un mensaje de error
                return new ResponseProvider(false, 400, "El empleado ya esta registrado", null, null).toResponse();
            }

            PersonalDAO personalDAO = new PersonalDAO(); // Crea una instancia de PersonalDAO

            // Verifica si ya existe un usuario con el mismo nombre
            Personal personal = personalDAO.getByUsername(nuevoPersonal.getUsuario());

            if (personal != null) {
                return new ResponseProvider(false, 400, "El nombre de usuario ya esta registrado, ingrese uno diferente", null, null).toResponse();
            }

            nuevoPersonal.setId_rol(nuevoPersonal.getId_rol()); // Establece el rol
            nuevoPersonal.setActivo(true); // Establece el estado activo
            
            // Crea el nuevo empleado
            Personal personalCreado = objDao.create("personal", nuevoPersonal);

            if (personalCreado == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar el empleado", null, null).toResponse();
            }

            PersonalResponseDTO personalCreadoDTO = new PersonalResponseDTO(); // Crea un DTO para el nuevo empleado
            personalCreadoDTO.setId(personalCreado.getId()); // Establece el ID
            personalCreadoDTO.setActivo(personalCreado.isActivo()); // Establece el estado activo

            // Obtiene la informaci�n del cliente asociada al nuevo empleado
            InformacionClientesPersonal info = objDao.getById(InformacionClientesPersonal.class, "informacion_clientes_personal", personalCreado.getId_info());
            IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);
            personalCreadoDTO.setInfo(infoDTO); // Establece la informaci�n del cliente
            personalCreadoDTO.setUsuario(personalCreado.getUsuario()); // Establece el usuario
            Rol rol = objDao.getById(Rol.class, "roles", personalCreado.getId_rol());
            personalCreadoDTO.setRol(rol); // Establece el rol

            // Retorna un mensaje de �xito
            return new ResponseProvider(true, 201, "Empleado registrado exitosamente", personalCreadoDTO, null).toResponse();

        } catch (Exception e) {
            // Manejo de errores
            return new ResponseProvider(false, 500, "Error al registrar el empleado", e, null).toResponse();
        }
    }

    /**
     * Crea un nuevo empleado.
     *
     * @param personal Objeto que contiene la informaci�n del nuevo empleado.
     * @return Response con el resultado de la creaci�n.
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON) // Especifica que el m�todo consume JSON
    @Produces(MediaType.APPLICATION_JSON)
    public Response createPersonal(PersonalRequestDTO personal) {
        PersonalDAO personalDAO = new PersonalDAO(); // Crea una instancia de PersonalDAO

        // Verifica si ya existe un usuario con el mismo nombre
        Personal usuarioExistente = personalDAO.getByUsername(personal.getUsuario());

        if (usuarioExistente != null) {
            return new ResponseProvider(false, 400, "El nombre de usuario ya esta registrado, ingrese uno diferente", null, null).toResponse();
        }
        
        Connection con = null; // Inicializa la conexi�n
        try {
            con = ConexionBD.conectar(); // Conecta a la base de datos
            con.setAutoCommit(false); // Inicia transacci�n manual

            CrudDAO objDao = new CrudDAO(con); // Crea una instancia de CrudDAO con la conexi�n

            // Crear y poblar objeto de informaci�n personal
            InformacionClientesPersonal infoPersonal = new InformacionClientesPersonal();
            infoPersonal.setId_tipo_documento(personal.getId_tipo_documento()); // Establece el tipo de documento
            infoPersonal.setNumero_documento(personal.getNumero_documento()); // Establece el n�mero de documento
            infoPersonal.setNombre(personal.getNombre()); // Establece el nombre
            infoPersonal.setTelefono(personal.getTelefono()); // Establece el tel�fono
            infoPersonal.setCorreo(personal.getCorreo()); // Establece el correo
            infoPersonal.setDireccion(personal.getDireccion()); // Establece la direcci�n

            // Inserta la informaci�n personal
            InformacionClientesPersonal infoPersonalResponse = objDao.create("informacion_clientes_personal", infoPersonal);

            if (infoPersonalResponse == null) {
                con.rollback(); // Realiza rollback si hay error
                return new ResponseProvider<>(false, 500, "Error al crear la información personal", null, null).toResponse();
            }

            // Crear y poblar objeto personal
            Personal personalEntity = new Personal();
            personalEntity.setId_info(infoPersonalResponse.getId()); // Establece el ID de informaci�n
            personalEntity.setContrasena(personal.getContrasena()); // Establece la contrase�a
            personalEntity.setUsuario(personal.getUsuario()); // Establece el usuario
            personalEntity.setId_rol(personal.getId_rol()); // Establece el rol
            personalEntity.setActivo(true); // Establece el estado activo

            // Inserta el personal
            Personal personalResponse = objDao.create("personal", personalEntity);

            if (personalResponse == null) {
                con.rollback(); // Realiza rollback si hay error
                return new ResponseProvider<>(false, 500, "Error al crear el usuario personal", null, null).toResponse();
            }

            // Si todo fue bien
            con.commit(); // Realiza commit de la transacci�n

            // Retorna un mensaje de �xito
            return new ResponseProvider<>(true, 201, "Personal creado correctamente", new IdResponse(personalResponse.getId()), null).toResponse();

        } catch (Exception e) {
            try {
                if (con != null) {
                    con.rollback(); // Realiza rollback si hay error
                }
            } catch (Exception ex) {
                ex.printStackTrace(); // Manejo de errores
            }
            e.printStackTrace(); // Manejo de errores
            return new ResponseProvider<>(false, 500, "Error inesperado al crear el personal", null, null).toResponse();
        } finally {
            try {
                if (con != null) {
                    con.close(); // Cierra la conexi�n
                }
            } catch (Exception ex) {
                ex.printStackTrace(); // Manejo de errores
            }
        }
    }

    /**
     * Actualiza la informaci�n de un empleado.
     *
     * @param id ID del empleado a actualizar.
     * @param personalInfoActualizado Objeto que contiene la nueva informaci�n del empleado.
     * @return Response con el resultado de la actualizaci�n.
     */
    @PUT
    @Path("/{id}") // Ruta para actualizar un empleado espec�fico
    @Consumes(MediaType.APPLICATION_JSON) // Especifica que el m�todo consume JSON
    @Produces(MediaType.APPLICATION_JSON)
    public Response updatePersonal(@PathParam("id") int id, InformacionClientesPersonal personalInfoActualizado) {
        try {
            System.out.println("numero_documento recibido: " + personalInfoActualizado.getNumero_documento());
            CrudDAO objDao = new CrudDAO(); // Crea una instancia de CrudDAO

            personalInfoActualizado.setId(id); // Establece el ID en el objeto actualizado
            // Validar si el ID est� presente
            if (personalInfoActualizado.getId() == 0) {
                return new ResponseProvider(false, 400, "El ID de la informacion es obligatorio para actualizar", null, null).toResponse();
            }

            // Verificar si la informaci�n existe antes de actualizar
            InformacionClientesPersonal infoExistente = objDao.getById(InformacionClientesPersonal.class, "informacion_clientes_personal", id);

            if (infoExistente == null) {
                return new ResponseProvider(false, 404, "El empleado con ese ID de informacion no existe", null, null).toResponse();
            }

            boolean actualizada = objDao.update(personalInfoActualizado, "informacion_clientes_personal", "id"); // Actualiza la informaci�n

            if (!actualizada) {
                return new ResponseProvider(false, 400, "No se pudo actualizar la informacion del empleado", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Informacion del empleado actualizada exitosamente", personalInfoActualizado, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar la informacion del empleado", e, null).toResponse();
        }
    }
    
    /**
     * Activa un empleado desactivado.
     *
     * @param id ID del empleado a activar.
     * @return Response con el resultado de la activaci�n.
     */
    @PUT
    @Path("/activar/{id}") // Ruta para activar un empleado espec�fico
    @Produces(MediaType.APPLICATION_JSON)
    public Response activarPersonal(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO(); // Crea una instancia de CrudDAO

            // Verificar si el empleado existe
            Personal personalExistente = objDao.getById(Personal.class, "personal", id);

            if (personalExistente == null) {
                return new ResponseProvider(false, 404, "El empleado no existe", null, null).toResponse();
            }

            personalExistente.setActivo(true); // Establece el estado activo

            // Actualiza el estado del empleado
            boolean actualizado = objDao.update(personalExistente, "personal", "id");

            if (!actualizado) {
                return new ResponseProvider(false, 400, "No se pudo activar el empleado", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Empleado se activo correctamente exitosamente", null, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al activar el empleado", e, null).toResponse();
        }
    }

    /**
     * Desactiva un empleado.
     *
     * @param id ID del empleado a desactivar.
     * @return Response con el resultado de la desactivaci�n.
     */
    @DELETE
    @Path("/{id}") // Ruta para desactivar un empleado espec�fico
    @Produces(MediaType.APPLICATION_JSON)
    public Response deletePersonal(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO(); // Crea una instancia de CrudDAO

            // Verificar si el empleado existe
            Personal personalExistente = objDao.getById(Personal.class, "personal", id);

            if (personalExistente == null) {
                return new ResponseProvider(false, 404, "El empleado no existe", null, null).toResponse();
            }
            
            // Verifica si el empleado es un administrador
            if (personalExistente.getId_rol() == 1) {
                return new ResponseProvider(false, 400, "No se puede desactivar el Admin", null, null).toResponse();                
            }

            personalExistente.setActivo(false); // Establece el estado como inactivo

            // Actualiza el estado del empleado
            boolean eliminado = objDao.update(personalExistente, "personal", "id");

            if (!eliminado) {
                return new ResponseProvider(false, 400, "No se pudo desactivar el empleado", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Empleado desactivado exitosamente", null, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al desactivar el empleado", e, null).toResponse();
        }
    }
}

