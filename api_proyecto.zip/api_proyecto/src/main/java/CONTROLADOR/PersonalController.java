package CONTROLADOR;

import MODELO.DAO.CrudDAO;
import MODELO.DTO.LoginRequestDTO;
import MODELO.Personal;
import CONTROLADOR.ResponseProvider;
import MODELO.ConexionBD;
import MODELO.DTO.IcpResponseDTO;
import MODELO.InformacionClientesPersonal;
import MODELO.DAO.PersonalDAO;
import MODELO.IdResponse;
import MODELO.DTO.PersonalRequestDTO;
import MODELO.DTO.PersonalResponseDTO;
import MODELO.Rol;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import MODELO.DTO.ClienteDtoBuilder;

/**
 * Controlador REST para manejar las operaciones relacionadas con el personal.
 * Proporciona endpoints para:
 * - listar todos los empleados registrados
 * - obtener información de empleados sin cliente asignado
 * - listar veterinarios activos
 * - consultar un empleado por su ID
 * - manejar inicio de sesión de empleados
 * - crear empleados usando información existente
 * - crear nuevos empleados junto con su información personal
 * - actualizar información de empleados
 * - activar y desactivar empleados
 */
@Path("personal")
public class PersonalController {

    /**
     * Obtiene todos los empleados registrados. Convierte cada empleado en un
     * DTO que incluye su rol y la informacion del cliente asociada.
     *
     * @return Response con la lista de PersonalResponseDTO o mensaje de error
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll() {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera todos los registros de la tabla 'personal'
            List<Personal> personales = objDao.getAll(Personal.class, "personal");

            // si no hay personal registrado, retorna 404
            if (personales.isEmpty()) {
                return new ResponseProvider(
                        true,
                        404,
                        "No hay personal registrado",
                        null,
                        null
                ).toResponse();
            }

            // lista para almacenar los DTOs de respuesta
            List<PersonalResponseDTO> personalesDTO = new ArrayList<>();

            // itera sobre cada entidad Personal y construye su DTO
            for (Personal p : personales) {
                PersonalResponseDTO personalDTO = new PersonalResponseDTO();
                personalDTO.setId(p.getId());               // asigna el ID
                personalDTO.setUsuario(p.getUsuario());     // asigna el usuario

                // obtiene y asigna el rol asociado
                Rol rol = objDao.getById(Rol.class, "roles", p.getId_rol());
                personalDTO.setRol(rol);

                // obtiene y asigna la informacion del cliente asociada
                InformacionClientesPersonal info = objDao.getById(
                        InformacionClientesPersonal.class,
                        "informacion_clientes_personal",
                        p.getId_info()
                );
                IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);
                personalDTO.setInfo(infoDTO);

                personalDTO.setActivo(p.isActivo());        // asigna el estado activo
                personalesDTO.add(personalDTO);             // agrega el DTO a la lista
            }

            // retorna 200 con la lista de DTOs construida
            return new ResponseProvider(
                    true,
                    200,
                    "Personal obtenido correctamente",
                    personalesDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepciones inesperadas
            return new ResponseProvider(
                    true,
                    500,
                    "Error al obtener el personal",
                    null,
                    null
            ).toResponse();
        }
    }

    /**
     * Obtiene informacion de empleados que no estan asociados a ningun cliente.
     *
     * @return Response con la lista de InformacionClientesPersonal o mensaje de
     * error
     */
    @GET
    @Path("/noClientes")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getInfoPersonalSinClientes() {
        try {
            // instancia PersonalDAO para consultas especializadas
            PersonalDAO objDao = new PersonalDAO();

            // recupera los empleados sin cliente asociado
            List<InformacionClientesPersonal> clientesInfo = objDao.getEmpleadosSinCliente();

            // si no hay registros, retorna 404
            if (clientesInfo.isEmpty()) {
                return new ResponseProvider(
                        false,
                        404,
                        "No hay informacion valida registrada",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 con la lista de informacion de clientes
            return new ResponseProvider(
                    true,
                    200,
                    "Informacion obtenida correctamente",
                    clientesInfo,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepciones inesperadas
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener los datos",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Obtiene la lista de veterinarios activos.
     *
     * @return Response con la lista de PersonalResponseDTO o mensaje de error
     */
    @GET
    @Path("/veterinarios")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getPersonalVeterinario() {
        try {
            // instancia PersonalDAO para obtener veterinarios
            PersonalDAO personalDao = new PersonalDAO();
            // instancia CrudDAO para recuperar info de cliente
            CrudDAO objDao = new CrudDAO();

            // recupera la lista de veterinarios activos
            List<Personal> veterinarios = personalDao.obtenerVeterinariosActivos();

            // si no hay veterinarios, retorna 404
            if (veterinarios.isEmpty()) {
                return new ResponseProvider(
                        false,
                        404,
                        "No hay personal Veterinario registrado, registre personal veterinario para hacer registros de tratamientos",
                        null,
                        null
                ).toResponse();
            }

            // lista para almacenar los DTOs de respuesta
            List<PersonalResponseDTO> personalesDTO = new ArrayList<>();

            // itera sobre cada veterinario y construye su DTO
            for (Personal p : veterinarios) {
                PersonalResponseDTO personalDTO = new PersonalResponseDTO();
                personalDTO.setId(p.getId());               // asigna el ID

                // obtiene y asigna la informacion del cliente asociada
                InformacionClientesPersonal info = objDao.getById(
                        InformacionClientesPersonal.class,
                        "informacion_clientes_personal",
                        p.getId_info()
                );
                IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);
                personalDTO.setInfo(infoDTO);

                personalesDTO.add(personalDTO);             // agrega el DTO a la lista
            }

            // retorna 200 con la lista de veterinarios
            return new ResponseProvider(
                    true,
                    200,
                    "Veterinarios obtenidos correctamente",
                    personalesDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepciones inesperadas
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener los datos",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Obtiene un empleado por su ID.
     *
     * @param id ID del empleado a buscar
     * @return Response con PersonalResponseDTO o mensaje de error si no existe
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getPersonalById(@PathParam("id") int id) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera la entidad Personal por su ID
            Personal personal = objDao.getById(
                    Personal.class,
                    "personal",
                    id
            );

            // si no existe, retorna 404
            if (personal == null) {
                return new ResponseProvider(
                        true,
                        404,
                        "Este empleado no existe",
                        null,
                        null
                ).toResponse();
            }

            // construye el DTO de respuesta con datos basicos
            PersonalResponseDTO personalDTO = new PersonalResponseDTO();
            personalDTO.setId(personal.getId());
            personalDTO.setUsuario(personal.getUsuario());

            // obtiene y asigna el rol asociado
            Rol rol = objDao.getById(Rol.class, "roles", personal.getId_rol());
            personalDTO.setRol(rol);

            // obtiene y asigna la informacion del cliente asociada
            InformacionClientesPersonal info = objDao.getById(
                    InformacionClientesPersonal.class,
                    "informacion_clientes_personal",
                    personal.getId_info()
            );
            IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);
            personalDTO.setInfo(infoDTO);

            // asigna estado activo
            personalDTO.setActivo(personal.isActivo());

            // retorna 200 con el DTO construido
            return new ResponseProvider(
                    true,
                    200,
                    "Empleado obtenido correctamente",
                    personalDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepcion inesperada
            return new ResponseProvider(
                    true,
                    500,
                    "Error al obtener el empleado",
                    null,
                    null
            ).toResponse();
        }
    }

    /**
     * Maneja el inicio de sesion de un empleado.
     *
     * @param loginDTO objeto con las credenciales de inicio de sesion
     * @return Response con el resultado del login
     */
    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response postLogin(LoginRequestDTO loginDTO) {
        try {
            // instancia PersonalDAO para consultas de personal
            PersonalDAO objDao = new PersonalDAO();

            // busca el empleado por nombre de usuario
            Personal personal = objDao.getByUsername(loginDTO.getUsuario());

            // valida existencia del usuario
            if (personal == null) {
                return new ResponseProvider(
                        true,
                        404,
                        "Usuario no encontrado",
                        null,
                        null
                ).toResponse();
            }

            // valida contraseña
            if (!personal.getContrasena().equals(loginDTO.getContrasena())) {
                return new ResponseProvider(
                        true,
                        404,
                        "Contrasena incorrecta",
                        null,
                        null
                ).toResponse();
            }

            // valida si el usuario esta activo
            if (!personal.isActivo()) {
                return new ResponseProvider(
                        true,
                        400,
                        "Usuario desactivado, contacte al administrador",
                        null,
                        null
                ).toResponse();
            }

            // retorna exito de validacion
            return new ResponseProvider(
                    true,
                    200,
                    "Datos de inicio de sesion validados correctamente",
                    personal,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepcion inesperada
            return new ResponseProvider(
                    true,
                    500,
                    "Error al obtener el empleado",
                    null,
                    null
            ).toResponse();
        }
    }

    /**
     * Crea un nuevo empleado utilizando información existente. Verifica que no
     * haya otro empleado con la misma info ni usuario duplicado.
     *
     * @param nuevoPersonal Objeto Personal con id_info y usuario a registrar
     * @return Response con PersonalResponseDTO o mensaje de error
     */
    @POST
    @Path("/infoExistente")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createPersonalInformacionExistente(Personal nuevoPersonal) {
        try {
            // instancia CrudDAO para operaciones CRUD básicas
            CrudDAO objDao = new CrudDAO();

            // busca empleados que ya usan esta información personal
            List<Personal> personalExistente = objDao.getAllByField(
                    Personal.class,
                    "personal",
                    "id_info",
                    nuevoPersonal.getId_info()
            );
            // si ya hay uno, no permite registrar duplicado
            if (!personalExistente.isEmpty()) {
                return new ResponseProvider(
                        false,
                        400,
                        "El empleado ya está registrado",
                        null,
                        null
                ).toResponse();
            }

            // instancia DAO especializado para validar usuario
            PersonalDAO personalDAO = new PersonalDAO();
            Personal usuarioExistente = personalDAO.getByUsername(nuevoPersonal.getUsuario());
            // verifica duplicado de nombre de usuario
            if (usuarioExistente != null) {
                return new ResponseProvider(
                        false,
                        400,
                        "El nombre de usuario ya está registrado, ingrese uno diferente",
                        null,
                        null
                ).toResponse();
            }

            // marca el rol y el estado activo
            nuevoPersonal.setId_rol(nuevoPersonal.getId_rol());
            nuevoPersonal.setActivo(true);

            // crea el registro en la tabla 'personal'
            Personal personalCreado = objDao.create("personal", nuevoPersonal);
            if (personalCreado == null) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo registrar el empleado",
                        null,
                        null
                ).toResponse();
            }

            // construye DTO de respuesta
            PersonalResponseDTO personalCreadoDTO = new PersonalResponseDTO();
            personalCreadoDTO.setId(personalCreado.getId());
            personalCreadoDTO.setActivo(personalCreado.isActivo());
            personalCreadoDTO.setUsuario(personalCreado.getUsuario());

            // recupera y asigna info personal asociada
            InformacionClientesPersonal info = objDao.getById(
                    InformacionClientesPersonal.class,
                    "informacion_clientes_personal",
                    personalCreado.getId_info()
            );
            IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);
            personalCreadoDTO.setInfo(infoDTO);

            // recupera y asigna rol
            Rol rol = objDao.getById(Rol.class, "roles", personalCreado.getId_rol());
            personalCreadoDTO.setRol(rol);

            // retorna 201 con el DTO del nuevo empleado
            return new ResponseProvider(
                    true,
                    201,
                    "Empleado registrado exitosamente",
                    personalCreadoDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // manejo de error inesperado
            return new ResponseProvider(
                    false,
                    500,
                    "Error al registrar el empleado",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Crea un nuevo empleado junto con su información personal. Realiza
     * transacción manual para asegurar consistencia.
     *
     * @param personal DTO con datos de info personal y credenciales
     * @return Response con IdResponse o mensaje de error
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createPersonal(PersonalRequestDTO personal) {
        PersonalDAO personalDAO = new PersonalDAO();
        // valida existencia de usuario duplicado
        Personal usuarioExistente = personalDAO.getByUsername(personal.getUsuario());
        if (usuarioExistente != null) {
            return new ResponseProvider(
                    false,
                    400,
                    "El nombre de usuario ya está registrado, ingrese uno diferente",
                    null,
                    null
            ).toResponse();
        }

        Connection con = null;
        try {
            // abre conexión y desactiva auto-commit
            con = ConexionBD.conectar();
            con.setAutoCommit(false);

            // DAO con la misma conexión para transacción
            CrudDAO objDao = new CrudDAO(con);

            // prepara entidad de info personal
            InformacionClientesPersonal infoPersonal = new InformacionClientesPersonal();
            infoPersonal.setId_tipo_documento(personal.getId_tipo_documento());
            infoPersonal.setNumero_documento(personal.getNumero_documento());
            infoPersonal.setNombre(personal.getNombre());
            infoPersonal.setTelefono(personal.getTelefono());
            infoPersonal.setCorreo(personal.getCorreo());
            infoPersonal.setDireccion(personal.getDireccion());
            // inserta info personal
            InformacionClientesPersonal infoResp = objDao.create(
                    "informacion_clientes_personal",
                    infoPersonal
            );
            if (infoResp == null) {
                con.rollback();
                return new ResponseProvider<>(
                        false,
                        500,
                        "Error al crear la información personal",
                        null,
                        null
                ).toResponse();
            }

            // prepara entidad personal con referencia a info creada
            Personal personalEntity = new Personal();
            personalEntity.setId_info(infoResp.getId());
            personalEntity.setUsuario(personal.getUsuario());
            personalEntity.setContrasena(personal.getContrasena());
            personalEntity.setId_rol(personal.getId_rol());
            personalEntity.setActivo(true);
            // inserta personal
            Personal personalResp = objDao.create("personal", personalEntity);
            if (personalResp == null) {
                con.rollback();
                return new ResponseProvider<>(
                        false,
                        500,
                        "Error al crear el usuario personal",
                        null,
                        null
                ).toResponse();
            }

            // confirma transacción
            con.commit();
            // retorna 201 con ID del nuevo empleado
            return new ResponseProvider<>(
                    true,
                    201,
                    "Personal creado correctamente",
                    new IdResponse(personalResp.getId()),
                    null
            ).toResponse();

        } catch (Exception e) {
            // rollback en caso de fallo
            try {
                if (con != null) {
                    con.rollback();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            // maneja excepción
            return new ResponseProvider<>(
                    false,
                    500,
                    "Error inesperado al crear el personal",
                    null,
                    null
            ).toResponse();
        } finally {
            // cierra conexión si se abrió
            try {
                if (con != null) {
                    con.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * Actualiza la información de un empleado.
     *
     * @param id ID del registro de info personal a actualizar
     * @param personalInfoActualizado Objeto con los nuevos valores de
     * información personal
     * @return Response con la info actualizada o un mensaje de error
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updatePersonal(
            @PathParam("id") int id,
            InformacionClientesPersonal personalInfoActualizado) {
        try {
            // imprime el numero de documento recibido para debug
            System.out.println("numero_documento recibido: "
                    + personalInfoActualizado.getNumero_documento());

            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // asigna el ID de ruta al objeto que se actualizara
            personalInfoActualizado.setId(id);

            // valida que el ID no sea cero
            if (personalInfoActualizado.getId() == 0) {
                return new ResponseProvider(
                        false,
                        400,
                        "El ID de la informacion es obligatorio para actualizar",
                        null,
                        null
                ).toResponse();
            }

            // verifica si el registro existe en la base de datos
            InformacionClientesPersonal infoExistente = objDao.getById(
                    InformacionClientesPersonal.class,
                    "informacion_clientes_personal",
                    id
            );
            if (infoExistente == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "El empleado con ese ID de informacion no existe",
                        null,
                        null
                ).toResponse();
            }

            // ejecuta la actualizacion en la tabla 'informacion_clientes_personal'
            boolean actualizada = objDao.update(
                    personalInfoActualizado,
                    "informacion_clientes_personal",
                    "id"
            );
            if (!actualizada) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo actualizar la informacion del empleado",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 con el objeto actualizado
            return new ResponseProvider(
                    true,
                    200,
                    "Informacion del empleado actualizada exitosamente",
                    personalInfoActualizado,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepciones inesperadas
            return new ResponseProvider(
                    false,
                    500,
                    "Error al actualizar la informacion del empleado",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Activa un empleado desactivado.
     *
     * @param id ID del empleado a activar
     * @return Response indicando si la activacion fue exitosa o no
     */
    @PUT
    @Path("/activar/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response activarPersonal(@PathParam("id") int id) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera el empleado por su ID
            Personal personalExistente = objDao.getById(
                    Personal.class,
                    "personal",
                    id
            );
            // si no existe, retorna 404
            if (personalExistente == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "El empleado no existe",
                        null,
                        null
                ).toResponse();
            }

            // marca el empleado como activo
            personalExistente.setActivo(true);

            // actualiza el campo 'activo' en la tabla 'personal'
            boolean actualizado = objDao.update(
                    personalExistente,
                    "personal",
                    "id"
            );
            if (!actualizado) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo activar el empleado",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 indicando exito
            return new ResponseProvider(
                    true,
                    200,
                    "Empleado activado correctamente",
                    null,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepciones inesperadas
            return new ResponseProvider(
                    false,
                    500,
                    "Error al activar el empleado",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Desactiva un empleado (soft delete marcando activo = false).
     *
     * @param id ID del empleado a desactivar
     * @return Response indicando si la desactivacion fue exitosa o no
     */
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deletePersonal(@PathParam("id") int id) {
        try {
            // instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera el empleado por su ID
            Personal personalExistente = objDao.getById(
                    Personal.class,
                    "personal",
                    id
            );
            // si no existe, retorna 404
            if (personalExistente == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "El empleado no existe",
                        null,
                        null
                ).toResponse();
            }

            // evita desactivar al admin (rol = 1)
            if (personalExistente.getId_rol() == 1) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se puede desactivar el Admin",
                        null,
                        null
                ).toResponse();
            }

            // marca el empleado como inactivo
            personalExistente.setActivo(false);

            // actualiza el campo 'activo' en la tabla 'personal'
            boolean eliminado = objDao.update(
                    personalExistente,
                    "personal",
                    "id"
            );
            if (!eliminado) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo desactivar el empleado",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 indicando exito
            return new ResponseProvider(
                    true,
                    200,
                    "Empleado desactivado exitosamente",
                    null,
                    null
            ).toResponse();

        } catch (Exception e) {
            // maneja excepciones inesperadas
            return new ResponseProvider(
                    false,
                    500,
                    "Error al desactivar el empleado",
                    e,
                    null
            ).toResponse();
        }
    }

}
