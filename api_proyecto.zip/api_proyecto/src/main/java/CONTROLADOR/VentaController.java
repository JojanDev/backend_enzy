package CONTROLADOR;

import MODELO.Cliente;
import MODELO.DTO.ClienteResponseDTO;
import MODELO.DAO.CrudDAO;
import MODELO.DetalleVenta;
import MODELO.DTO.IcpResponseDTO;
import MODELO.InformacionClientesPersonal;
import MODELO.DAO.MedicamentoDAO;
import MODELO.Personal;
import MODELO.DTO.PersonalResponseDTO;
import MODELO.DAO.ProductoDAO;
import MODELO.Venta;
import MODELO.DAO.VentaDAO;
import MODELO.DTO.VentaPerfilDTO;
import MODELO.DTO.VentaRequestDTO;
import MODELO.DTO.VentaResponseDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import MODELO.DTO.ClienteDtoBuilder;

/**
 * Controlador REST para gestionar las ventas.
 * Proporciona endpoints para:
 * - obtener todas las ventas registradas
 * - obtener una venta específica por su ID
 * - obtener el perfil completo de una venta (cliente, personal y detalles)
 * - registrar una nueva venta con sus detalles
 * - actualizar el monto de una venta existente
 */
@Path("ventas")
public class VentaController {

    /**
     * Obtiene una venta específica por su ID.
     *
     * @param id Identificador de la venta
     * @return Response con VentaResponseDTO o mensaje de error si no existe
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getVentaById(@PathParam("id") int id) {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // obtiene la venta por su ID de la tabla 'ventas'
            Venta venta = objDao.getById(
                    Venta.class,
                    "ventas",
                    id
            );

            // si no existe la venta, retorna 404
            if (venta == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "Venta no encontrada",
                        null,
                        null
                ).toResponse();
            }

            // construye el DTO de respuesta con los campos básicos de la venta
            VentaResponseDTO ventaDTO = new VentaResponseDTO();
            ventaDTO.setId(venta.getId());
            ventaDTO.setMonto(venta.getMonto());
            ventaDTO.setTotal(venta.getTotal());
            ventaDTO.setEstado(venta.getEstado());
            ventaDTO.setFecha(venta.getFecha_creado());

            // obtiene y asigna datos del cliente asociado
            Cliente cliente = objDao.getById(
                    Cliente.class,
                    "clientes",
                    venta.getId_cliente()
            );
            if (cliente != null) {
                ventaDTO.setCliente(
                        ClienteDtoBuilder.construirClienteDTO(cliente, objDao)
                );
            }

            // obtiene y asigna datos del personal asociado
            Personal personal = objDao.getById(
                    Personal.class,
                    "personal",
                    venta.getId_personal()
            );
            if (personal != null) {
                // obtiene información extra del personal
                InformacionClientesPersonal info = objDao.getById(
                        InformacionClientesPersonal.class,
                        "informacion_clientes_personal",
                        personal.getId_info()
                );
                IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);

                // construye DTO de personal y lo asigna al DTO de la venta
                PersonalResponseDTO personalDTO = new PersonalResponseDTO();
                personalDTO.setId(personal.getId());
                personalDTO.setUsuario(personal.getUsuario());
                personalDTO.setInfo(infoDTO);
                ventaDTO.setPersonal(personalDTO);
            }

            // retorna 200 con el DTO de la venta obtenida
            return new ResponseProvider(
                    true,
                    200,
                    "Venta obtenida correctamente",
                    ventaDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // imprime la traza de la excepción (solo recomendable en desarrollo)
            e.printStackTrace();
            // retorna 500 en caso de error interno
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener la venta",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Obtiene el perfil completo de una venta, incluyendo cliente, personal y
     * detalles relacionados.
     *
     * @param idVenta ID de la venta
     * @return Response con el perfil de la venta en caso de exito, o mensaje de
     * error si no se encuentra o en caso de fallo
     */
    @GET
    @Path("/perfil/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getVentaPerfil(@PathParam("id") int idVenta) {
        try {
            // crea instancia de VentaDAO para obtener datos compuestos
            VentaDAO dao = new VentaDAO();

            // solicita al DAO el DTO de perfil con todos los datos relacionados
            VentaPerfilDTO ventaPerfil = dao.obtenerVentaPerfil(idVenta);

            // si no existe el perfil de la venta, retorna 404
            if (ventaPerfil == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "No se encontro la venta",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 con el DTO de perfil de venta
            return new ResponseProvider(
                    true,
                    200,
                    "Perfil de venta obtenido",
                    ventaPerfil,
                    null
            ).toResponse();

        } catch (Exception e) {
            // imprime la traza para debug (solo en desarrollo)
            e.printStackTrace();

            // retorna 500 en caso de excepcion interna
            return new ResponseProvider(
                    false,
                    500,
                    "Error interno al obtener la venta",
                    null,
                    null
            ).toResponse();
        }
    }

    /**
     * Registra una nueva venta con sus respectivos detalles (productos,
     * medicamentos o servicios).
     *
     * @param nuevaVentaConDetalles DTO con datos de la venta y lista de
     * detalles
     * @return Response con la entidad Venta creada o mensaje de error en caso
     * de fallo
     */
    @POST
    @Path("/detalles")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createVenta(VentaRequestDTO nuevaVentaConDetalles) {
        try {
            // instancia CrudDAO para persistir venta y detalles
            CrudDAO objDao = new CrudDAO();

            // construye la entidad Venta a partir del DTO de entrada
            Venta nuevaVenta = new Venta();
            nuevaVenta.setId_cliente(nuevaVentaConDetalles.getId_cliente());
            nuevaVenta.setId_personal(nuevaVentaConDetalles.getId_personal());
            nuevaVenta.setMonto(nuevaVentaConDetalles.getMonto());
            nuevaVenta.setTotal(nuevaVentaConDetalles.getTotal());

            // determina el estado: completa si monto == total, pendiente de lo contrario
            String estado = nuevaVentaConDetalles.getMonto()
                    .compareTo(nuevaVentaConDetalles.getTotal()) == 0
                    ? "completada"
                    : "pendiente";
            nuevaVenta.setEstado(estado);

            // persiste la venta en la base de datos
            Venta ventaCreada = objDao.create("ventas", nuevaVenta);
            if (ventaCreada == null) {
                // falla de insercion de la venta
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo registrar la venta",
                        null,
                        null
                ).toResponse();
            }

            // persiste cada detalle de la venta
            for (DetalleVenta dt : nuevaVentaConDetalles.getDetalles_venta()) {
                DetalleVenta nuevoDetalle = new DetalleVenta();
                nuevoDetalle.setCantidad(dt.getCantidad());
                nuevoDetalle.setSubtotal(dt.getSubtotal());
                nuevoDetalle.setPrecio(dt.getPrecio());
                nuevoDetalle.setId_medicamento(dt.getId_medicamento());
                nuevoDetalle.setId_producto(dt.getId_producto());
                nuevoDetalle.setId_servicio(dt.getId_servicio());
                nuevoDetalle.setId_venta(ventaCreada.getId());
                nuevoDetalle.setValor_adicional(dt.getValor_adicional());

                // crea el registro en 'detalles_ventas'
                objDao.create("detalles_ventas", nuevoDetalle);
            }

            // prepara DAOs para actualizacion de stock
            MedicamentoDAO medicamentoDAO = new MedicamentoDAO();
            ProductoDAO productoDAO = new ProductoDAO();

            // actualiza stock de productos o medicamentos segun corresponda
            for (DetalleVenta detalle : nuevaVentaConDetalles.getDetalles_venta()) {
                if (detalle.getId_producto() != null) {
                    // resta stock de producto
                    productoDAO.restarStock(
                            detalle.getId_producto(),
                            detalle.getCantidad()
                    );
                } else if (detalle.getId_medicamento() != null) {
                    // resta cantidad de medicamento
                    medicamentoDAO.restarCantidad(
                            detalle.getId_medicamento(),
                            detalle.getCantidad()
                    );
                }
                // si es servicio, no se modifica ningun stock
            }

            // retorna 201 con la entidad Venta registrada
            return new ResponseProvider(
                    true,
                    201,
                    "Venta registrada exitosamente",
                    ventaCreada,
                    null
            ).toResponse();

        } catch (Exception e) {
            // manejo de excepcion interna
            return new ResponseProvider(
                    false,
                    500,
                    "Error al registrar la venta",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Actualiza el monto de una venta específica.
     *
     * @param id ID de la venta a actualizar
     * @param montoNuevo nuevo monto a asignar a la venta
     * @return Response con el resultado de la operación: - 200 si el monto se
     * actualizó correctamente - 404 si la venta no se encontró o no se pudo
     * actualizar - 500 en caso de error interno
     */
    @PUT
    @Path("/{id}/monto")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response actualizarMontoVenta(
            @PathParam("id") int id,
            double montoNuevo) {
        try {
            // instancia el DAO especializado para operaciones de venta
            VentaDAO ventaDAO = new VentaDAO();

            // intenta actualizar el monto de la venta en la base de datos
            boolean actualizado = ventaDAO.actualizarMonto(id, montoNuevo);

            // si la actualizacion falla o la venta no existe, devuelve 404
            if (!actualizado) {
                return new ResponseProvider(
                        false,
                        404,
                        "Venta no encontrada o no se pudo actualizar",
                        null,
                        null
                ).toResponse();
            }

            // si todo sale bien, devuelve 200 con mensaje de confirmacion
            return new ResponseProvider(
                    true,
                    200,
                    "Monto actualizado correctamente",
                    null,
                    null
            ).toResponse();

        } catch (Exception e) {
            // manejo de excepcion inesperada, retorna 500 con detalle
            return new ResponseProvider(
                    false,
                    500,
                    "Error al actualizar el monto de la venta",
                    e,
                    null
            ).toResponse();
        }
    }

}
