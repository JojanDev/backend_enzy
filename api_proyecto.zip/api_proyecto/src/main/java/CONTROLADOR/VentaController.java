package CONTROLADOR;

import MODELO.Cliente;
import MODELO.DTO.ClienteResponseDTO;
import MODELO.DAO.CrudDAO;
import MODELO.DetalleVenta;
import MODELO.DTO.IcpResponseDTO;
import MODELO.InformacionClientesPersonal;
import MODELO.DAO.MedicamentoDAO;
import MODELO.Personal;
import MODELO.DTO.PersonalResponseDTO;
import MODELO.DAO.ProductoDAO;
import MODELO.Venta;
import MODELO.DAO.VentaDAO;
import MODELO.DTO.VentaPerfilDTO;
import MODELO.DTO.VentaRequestDTO;
import MODELO.DTO.VentaResponseDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import MODELO.DTO.ClienteDtoBuilder;

/**
 * Controlador REST para gestionar las ventas.
 * Ofrece endpoints para consultar, crear y actualizar ventas.
 */
@Path("ventas")
public class VentaController {

    /**
     * Obtiene todas las ventas registradas en el sistema.
     * 
     * @return Response con lista de ventas en formato DTO
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllVentas() {
        try {
            CrudDAO objDao = new CrudDAO();
            List<Venta> ventas = objDao.getAll(Venta.class, "ventas");

            if (ventas.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay ventas registradas", null, null).toResponse();
            }

            List<VentaResponseDTO> ventasDTO = new ArrayList<>();

            // Construcción manual de DTOs para evitar exponer la entidad directamente
            for (Venta v : ventas) {
                VentaResponseDTO ventaDTO = new VentaResponseDTO();
                ventaDTO.setId(v.getId());
                ventaDTO.setMonto(v.getMonto());
                ventaDTO.setTotal(v.getTotal());
                ventaDTO.setEstado(v.getEstado());
                ventaDTO.setFecha(v.getFecha_creado());

                // ===== Cliente =====
                Cliente cliente = objDao.getById(Cliente.class, "clientes", v.getId_cliente());
                if (cliente != null) {
                    ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
                    ventaDTO.setCliente(clienteDTO);
                }

                // ===== Personal =====
                Personal personal = objDao.getById(Personal.class, "personal", v.getId_personal());
                if (personal != null) {
                    // Se carga información detallada del personal asociado a la venta
                    InformacionClientesPersonal info = objDao.getById(
                            InformacionClientesPersonal.class,
                            "informacion_clientes_personal",
                            personal.getId_info()
                    );
                    IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);

                    PersonalResponseDTO personalDTO = new PersonalResponseDTO();
                    personalDTO.setId(personal.getId());
                    personalDTO.setUsuario(personal.getUsuario());
                    personalDTO.setInfo(infoDTO);

                    ventaDTO.setPersonal(personalDTO);
                }

                ventasDTO.add(ventaDTO);
            }

            return new ResponseProvider(true, 200, "Ventas obtenidas correctamente", ventasDTO, null).toResponse();

        } catch (Exception e) {
            e.printStackTrace(); // Solo recomendable en desarrollo
            return new ResponseProvider(false, 500, "Error interno al obtener las ventas", null, null).toResponse();
        }
    }

    /**
     * Obtiene una venta específica por su ID.
     * 
     * @param id Identificador de la venta
     * @return Response con los datos de la venta en formato DTO
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getVentaById(@PathParam("id") int id) {
        try {
            final CrudDAO objDao = new CrudDAO();

            Venta venta = objDao.getById(Venta.class, "ventas", id);
            if (venta == null) {
                return new ResponseProvider(false, 404, "Venta no encontrada", null, null).toResponse();
            }

            // Construcción del DTO manualmente
            VentaResponseDTO ventaDTO = new VentaResponseDTO();
            ventaDTO.setId(venta.getId());
            ventaDTO.setMonto(venta.getMonto());
            ventaDTO.setTotal(venta.getTotal());
            ventaDTO.setEstado(venta.getEstado());
            ventaDTO.setFecha(venta.getFecha_creado());

            // ===== Cliente =====
            Cliente cliente = objDao.getById(Cliente.class, "clientes", venta.getId_cliente());
            if (cliente != null) {
                ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
                ventaDTO.setCliente(clienteDTO);
            }

            // ===== Personal =====
            Personal personal = objDao.getById(Personal.class, "personal", venta.getId_personal());
            if (personal != null) {
                InformacionClientesPersonal info = objDao.getById(
                        InformacionClientesPersonal.class,
                        "informacion_clientes_personal",
                        personal.getId_info()
                );
                IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);

                PersonalResponseDTO personalDTO = new PersonalResponseDTO();
                personalDTO.setId(personal.getId());
                personalDTO.setUsuario(personal.getUsuario());
                personalDTO.setInfo(infoDTO);

                ventaDTO.setPersonal(personalDTO);
            }

            return new ResponseProvider(true, 200, "Venta obtenida correctamente", ventaDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener la venta", e, null).toResponse();
        }
    }

    /**
     * Obtiene el perfil completo de una venta, incluyendo cliente, personal
     * y detalles relacionados.
     * 
     * @param idVenta ID de la venta
     * @return Response con el perfil de la venta
     */
    @GET
    @Path("/perfil/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getVentaPerfil(@PathParam("id") int idVenta) {
        try {
            VentaDAO dao = new VentaDAO();
            VentaPerfilDTO ventaPerfil = dao.obtenerVentaPerfil(idVenta);

            if (ventaPerfil == null) {
                return new ResponseProvider(false, 404, "No se encontro la venta", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Perfil de venta obtenido", ventaPerfil, null).toResponse();

        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseProvider(false, 500, "Error interno al obtener la venta", null, null).toResponse();
        }
    }

    /**
     * Registra una nueva venta con sus respectivos detalles (productos, medicamentos o servicios).
     * 
     * @param nuevaVentaConDetalles DTO con la información de la venta y sus detalles
     * @return Response con la venta creada
     */
    @POST
    @Path("/detalles")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createVenta(VentaRequestDTO nuevaVentaConDetalles) {
        try {
            CrudDAO objDao = new CrudDAO();

            Venta nuevaVenta = new Venta();
            nuevaVenta.setId_cliente(nuevaVentaConDetalles.getId_cliente());
            nuevaVenta.setId_personal(nuevaVentaConDetalles.getId_personal());
            nuevaVenta.setMonto(nuevaVentaConDetalles.getMonto());
            nuevaVenta.setTotal(nuevaVentaConDetalles.getTotal());
            
            // Definir estado según si el monto coincide con el total
            String estado = nuevaVentaConDetalles.getMonto()
                    .compareTo(nuevaVentaConDetalles.getTotal()) == 0
                    ? "completada"
                    : "pendiente";
            nuevaVenta.setEstado(estado);

            // Persistir venta
            Venta ventaCreada = objDao.create("ventas", nuevaVenta);
            if (ventaCreada == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar la venta", null, null).toResponse();
            }

            // Persistir detalles asociados
            for (DetalleVenta dt : nuevaVentaConDetalles.getDetalles_venta()) {
                DetalleVenta nuevoDetalle = new DetalleVenta();
                nuevoDetalle.setCantidad(dt.getCantidad());
                nuevoDetalle.setSubtotal(dt.getSubtotal());
                nuevoDetalle.setPrecio(dt.getPrecio());
                nuevoDetalle.setId_medicamento(dt.getId_medicamento());
                nuevoDetalle.setId_producto(dt.getId_producto());
                nuevoDetalle.setId_servicio(dt.getId_servicio());
                nuevoDetalle.setId_venta(ventaCreada.getId());
                nuevoDetalle.setValor_adicional(dt.getValor_adicional());

                objDao.create("detalles_ventas", nuevoDetalle);
            }

            // Actualizar stock de productos o medicamentos
            MedicamentoDAO medicamentoDAO = new MedicamentoDAO();
            ProductoDAO productoDAO = new ProductoDAO();
            for (DetalleVenta detalle : nuevaVentaConDetalles.getDetalles_venta()) {
                if (detalle.getId_producto() != null) {
                    productoDAO.restarStock(detalle.getId_producto(), detalle.getCantidad());
                } else if (detalle.getId_medicamento() != null) {
                    medicamentoDAO.restarCantidad(detalle.getId_medicamento(), detalle.getCantidad());
                }
                // Si es un servicio, no se toca stock
            }

            return new ResponseProvider(true, 201, "Venta registrada exitosamente", ventaCreada, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar la venta", e, null).toResponse();
        }
    }

    /**
     * Actualiza el monto de una venta específica.
     * 
     * @param id ID de la venta
     * @param montoNuevo nuevo monto a asignar
     * @return Response con resultado de la operación
     */
    @PUT
    @Path("/{id}/monto")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response actualizarMontoVenta(@PathParam("id") int id, double montoNuevo) {
        try {
            VentaDAO ventaDAO = new VentaDAO();

            boolean actualizado = ventaDAO.actualizarMonto(id, montoNuevo);
            if (!actualizado) {
                return new ResponseProvider(false, 404, "Venta no encontrada o no se pudo actualizar", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Monto actualizado correctamente", null, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar el monto de la venta", e, null).toResponse();
        }
    }

}
