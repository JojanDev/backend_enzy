/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.Cliente;
import MODELO.ClienteResponseDTO;
import MODELO.CrudDAO;
import MODELO.DetalleVenta;
import MODELO.IcpResponseDTO;
import MODELO.InformacionClientesPersonal;
import MODELO.MedicamentoDAO;
import MODELO.Personal;
import MODELO.PersonalResponseDTO;
import MODELO.ProductoDAO;
import MODELO.Venta;
import MODELO.VentaDAO;
import MODELO.VentaRequestDTO;
import MODELO.VentaResponseDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import modelo.ClienteDtoBuilder;

/**
 *
 * @author USUARIO
 */
@Path("ventas")
public class VentaController {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllVentas() {
        try {
            CrudDAO objDao = new CrudDAO();
            List<Venta> ventas = objDao.getAll(Venta.class, "ventas");

            if (ventas.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay ventas registradas", null, null).toResponse();
            }

            List<VentaResponseDTO> ventasDTO = new ArrayList<>();

            for (Venta v : ventas) {
                VentaResponseDTO ventaDTO = new VentaResponseDTO();
                ventaDTO.setId(v.getId());
                ventaDTO.setMonto(v.getMonto());
                ventaDTO.setTotal(v.getTotal());
                ventaDTO.setEstado(v.getEstado());
                ventaDTO.setFecha(v.getFecha_creado()); // map de fecha_creado → fecha DTO

                // Cliente
                Cliente cliente = objDao.getById(Cliente.class, "clientes", v.getId_cliente());
                if (cliente != null) {
                    ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
                    ventaDTO.setCliente(clienteDTO);
                }

                // Personal
                Personal personal = objDao.getById(Personal.class, "personal", v.getId_personal());
                if (personal != null) {
                    InformacionClientesPersonal info = objDao.getById(
                            InformacionClientesPersonal.class,
                            "informacion_clientes_personal",
                            personal.getId_info()
                    );
                    IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);

                    PersonalResponseDTO personalDTO = new PersonalResponseDTO();
                    personalDTO.setId(personal.getId());
                    personalDTO.setUsuario(personal.getUsuario());
                    personalDTO.setInfo(infoDTO);

                    ventaDTO.setPersonal(personalDTO);
                }

                ventasDTO.add(ventaDTO);
            }

            return new ResponseProvider(true, 200, "Ventas obtenidas correctamente", ventasDTO, null).toResponse();

        } catch (Exception e) {
            e.printStackTrace(); // útil en desarrollo
            return new ResponseProvider(false, 500, "Error interno al obtener las ventas", null, null).toResponse();
        }
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getVentaById(@PathParam("id") int id) {
        try {
            final CrudDAO objDao = new CrudDAO();

            // Obtener la venta por ID
            Venta venta = objDao.getById(Venta.class, "ventas", id);
            if (venta == null) {
                return new ResponseProvider(false, 404, "Venta no encontrada", null, null).toResponse();
            }

            // Construir el DTO de la venta
            VentaResponseDTO ventaDTO = new VentaResponseDTO();
            ventaDTO.setId(venta.getId());
            ventaDTO.setMonto(venta.getMonto());
            ventaDTO.setTotal(venta.getTotal());
            ventaDTO.setEstado(venta.getEstado());
            ventaDTO.setFecha(venta.getFecha_creado());

            // ===== Cliente =====
            Cliente cliente = objDao.getById(Cliente.class, "clientes", venta.getId_cliente());
            if (cliente != null) {
                ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
                ventaDTO.setCliente(clienteDTO);
            }

            // ===== Personal =====
            Personal personal = objDao.getById(Personal.class, "personal", venta.getId_personal());
            if (personal != null) {
                InformacionClientesPersonal info = objDao.getById(
                        InformacionClientesPersonal.class,
                        "informacion_clientes_personal",
                        personal.getId_info()
                );
                IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);

                PersonalResponseDTO personalDTO = new PersonalResponseDTO();
                personalDTO.setId(personal.getId());
                personalDTO.setUsuario(personal.getUsuario());
                personalDTO.setInfo(infoDTO);

                ventaDTO.setPersonal(personalDTO);
            }

            // Respuesta final
            return new ResponseProvider(true, 200, "Venta obtenida correctamente", ventaDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener la venta", e, null).toResponse();
        }
    }

    @POST
    @Path("/detalles")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createVenta(VentaRequestDTO nuevaVentaConDetalles) {
        try {
            CrudDAO objDao = new CrudDAO();

            Venta nuevaVenta = new Venta();

            nuevaVenta.setId_cliente(nuevaVentaConDetalles.getId_cliente());
            nuevaVenta.setId_personal(nuevaVentaConDetalles.getId_personal());
            nuevaVenta.setMonto(nuevaVentaConDetalles.getMonto());
            nuevaVenta.setTotal(nuevaVentaConDetalles.getTotal());
            
            System.out.println("ID Cliente: " + nuevaVentaConDetalles.getId_cliente());


            String estado = nuevaVentaConDetalles.getMonto()
                    .compareTo(nuevaVentaConDetalles.getTotal()) == 0
                    ? "completada"
                    : "pendiente";

            nuevaVenta.setEstado(estado);

            Venta ventaCreada = objDao.create("ventas", nuevaVenta);

            if (ventaCreada == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar la venta", null, null).toResponse();
            }

            for (DetalleVenta dt : nuevaVentaConDetalles.getDetalles_venta()) {
                DetalleVenta nuevoDetalle = new DetalleVenta();

                nuevoDetalle.setCantidad(dt.getCantidad());
                nuevoDetalle.setSubtotal(dt.getSubtotal());
                nuevoDetalle.setPrecio(dt.getPrecio());

                nuevoDetalle.setId_medicamento(dt.getId_medicamento());
                nuevoDetalle.setId_producto(dt.getId_producto());
                nuevoDetalle.setId_servicio(dt.getId_servicio());
                nuevoDetalle.setId_venta(ventaCreada.getId());
                nuevoDetalle.setValor_adicional(dt.getValor_adicional());
                
                System.out.println("Valor adicional: " + dt.getValor_adicional());


                DetalleVenta detalleCreado = objDao.create("detalles_ventas", nuevoDetalle);
            }

            MedicamentoDAO medicamentoDAO = new MedicamentoDAO();
            ProductoDAO productoDAO = new ProductoDAO();

            for (DetalleVenta detalle : nuevaVentaConDetalles.getDetalles_venta()) {
                if (detalle.getId_producto() != null) {
                    // Es un producto → restar stock en productos
                    productoDAO.restarStock(detalle.getId_producto(), detalle.getCantidad());
                } else if (detalle.getId_medicamento() != null) {
                    // Es un medicamento → restar stock en medicamentos
                    medicamentoDAO.restarCantidad(detalle.getId_medicamento(), detalle.getCantidad());
                }
                // Si es servicio, no hacemos nada con stock
            }

            return new ResponseProvider(true, 201, "Venta registrado exitosamente", ventaCreada, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar el cliente", e, null).toResponse();
        }
    }

    @PUT
    @Path("/{id}/monto")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response actualizarMontoVenta(@PathParam("id") int id, double montoNuevo) {
        try {
            VentaDAO ventaDAO = new VentaDAO();

            boolean actualizado = ventaDAO.actualizarMonto(id, montoNuevo);

            if (!actualizado) {
                return new ResponseProvider(false, 404, "Venta no encontrada o no se pudo actualizar", null, null)
                        .toResponse();
            }

            return new ResponseProvider(true, 200, "Monto actualizado correctamente", null, null)
                    .toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar el monto de la venta", e, null)
                    .toResponse();
        }
    }

}
