package CONTROLADOR;

import MODELO.DAO.CrudDAO;
import MODELO.Rol;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 * Controlador REST para la gestión de roles dentro del sistema.
 * 
 * Proporciona endpoint para:
 * - obtener todos los roles registrados (excluyendo al superadministrador, ID = 1)
 * 
 * Las respuestas se estructuran con ResponseProvider:
 * - 200: operación exitosa con lista de roles
 * - 404: no hay roles registrados
 * - 500: error interno al consultar
 */
@Path("roles")
public class RolController {

    /**
     * Obtiene todos los roles registrados en la base de datos,
     * excluyendo el rol superadministrador (ID = 1).
     *
     * @return Response con:
     *         - lista de {@link Rol} si existen roles válidos
     *         - código 404 si no hay roles registrados
     *         - código 500 si ocurre un error interno
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllRoles() {
        try {
            // instancia el DAO para interactuar con la base de datos
            CrudDAO objDao = new CrudDAO();

            // consulta todos los roles de la tabla "roles"
            List<Rol> roles = objDao.getAll(Rol.class, "roles");

            // si no se encontraron roles, retorna 404
            if (roles.isEmpty()) {
                return new ResponseProvider(
                    false,
                    404,
                    "No hay roles registrados",
                    null,
                    null
                ).toResponse();
            }

            // elimina el rol superadministrador (ID = 1) de la lista
            for (int i = 0; i < roles.size(); i++) {
                if (roles.get(i).getId() == 1) {
                    roles.remove(i);
                    break; // sale tras eliminar el rol reservado
                }
            }

            // retorna 200 con la lista de roles restantes
            return new ResponseProvider(
                true,
                200,
                "Roles obtenidos correctamente",
                roles,
                null
            ).toResponse();

        } catch (Exception e) {
            // en caso de excepción, retorna 500 con la info del error
            return new ResponseProvider(
                false,
                500,
                "Error al obtener los roles",
                e,
                null
            ).toResponse();
        }
    }
}
