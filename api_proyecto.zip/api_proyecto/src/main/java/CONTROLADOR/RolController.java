package CONTROLADOR;

import MODELO.DAO.CrudDAO;
import MODELO.Rol;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 * Controlador REST para la gestión de roles dentro del sistema.
 * 
 * Este controlador expone el endpoint relacionado con los roles,
 * permitiendo obtener todos los registros existentes en la base de datos.
 * 
 * Restricciones:
 * - El rol con ID = 1 (superadministrador) no se incluye en los resultados,
 *   ya que es un rol reservado dentro del sistema.
 * 
 * Los métodos retornan respuestas estructuradas mediante {@link ResponseProvider}.
 * En caso de error, se envía una respuesta con código HTTP apropiado y un
 * mensaje descriptivo.
 * 
 * Ruta base del recurso: "/roles"
 */
@Path("roles")
public class RolController {

    /**
     * Obtiene todos los roles registrados en la base de datos,
     * excluyendo el rol con ID = 1 (superadministrador).
     * 
     * @return Respuesta en formato JSON con:
     *         - Código 200 si los roles se obtuvieron correctamente.
     *         - Código 404 si no hay roles registrados.
     *         - Código 500 si ocurre un error en la consulta.
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllRoles() {
        try {
            // Inicializar el DAO para interactuar con la base de datos
            CrudDAO objDao = new CrudDAO();

            // Consultar todos los roles registrados en la tabla "roles"
            List<Rol> roles = objDao.getAll(Rol.class, "roles");

            // Validar si existen roles en la base de datos
            if (roles.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay roles registrados", null, null).toResponse();
            }

            // Eliminar de la lista el rol con ID = 1 (superadministrador)
            // Esto garantiza que no se muestre ni se manipule desde el frontend
            for (int i = 0; i < roles.size(); i++) {
                if (roles.get(i).getId() == 1) {
                    roles.remove(i);
                    break; // salir del bucle al encontrarlo
                }
            }

            // Respuesta exitosa con la lista de roles
            return new ResponseProvider(true, 200, "Roles obtenidos correctamente", roles, null).toResponse();

        } catch (Exception e) {
            // Manejo de errores: se retorna código 500 con información de la excepción
            return new ResponseProvider(false, 500, "Error al obtener los roles", e, null).toResponse();
        }
    }
}
