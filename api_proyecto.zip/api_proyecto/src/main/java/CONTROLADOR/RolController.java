/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.CrudDAO;
import MODELO.Rol;
import MODELO.Servicio;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 *
 * @author USUARIO
 */
@Path("roles")
public class RolController {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllRoles() {
        try {
            CrudDAO objDao = new CrudDAO();
            List<Rol> roles = objDao.getAll(Rol.class, "roles");

            // Validamos si existen registros de tipos de documentos
            if (roles.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay roles registrados", null, null).toResponse();
            }

            for (int i = 0; i < roles.size(); i++) {
                if (1 ==  roles.get(i).getId()) {
                    roles.remove(i);
                    break; // sale del bucle después de eliminar
                }
            }

            return new ResponseProvider(true, 200, "Roles obtenidos correctamente", roles, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los roles", e, null).toResponse();
        }
    }
}
