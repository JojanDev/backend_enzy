/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.CrudDAO;
import MODELO.Especie;
import MODELO.Mascota;
import MODELO.Raza;
import MODELO.RazaResponseDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 *
 * @author USUARIO
 */

@Path("razas")
public class RazaController {
    
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getRazaById(@PathParam("id") int idRaza) {
        try {
            CrudDAO objDao = new CrudDAO();
            Raza raza = objDao.getById(Raza.class, "razas", idRaza);
                
            if (raza == null) {
                return new ResponseProvider(false, 404, "Raza no encontrada", null, null).toResponse();
            }
            
            Especie especieRaza = objDao.getById(Especie.class, "especies", raza.getId_especie());
            
            RazaResponseDTO razaDTO = new RazaResponseDTO();
            razaDTO.setEspecie(especieRaza);
            razaDTO.setId(raza.getId());
            razaDTO.setNombre(raza.getNombre());
                

            return new ResponseProvider(true, 200, "Raza obtenida correctamente", razaDTO, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener la especie", e, null).toResponse(); 
        }
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createRaza(Raza nuevaRaza) {
        try {
            CrudDAO objDao = new CrudDAO();
            Raza razaCreada = objDao.create("razas", nuevaRaza);

            if (razaCreada == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar la raza", null, null).toResponse();
            }
            
            return new ResponseProvider(true, 201, "Raza registrada exitosamente", razaCreada, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar la raza", e, null).toResponse();
        }
    }
    
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateRaza(@PathParam("id") int id, Raza razaActualizada ) {
        try {
            CrudDAO objDao = new CrudDAO();

            razaActualizada.setId(id);
            // Validar si el ID está presente
            if (razaActualizada.getId() == 0) {
                return new ResponseProvider(false, 400, "El ID de la raza es obligatorio para actualizar", null, null).toResponse();
            }

            // Verificar si la especie existe antes de actualizar
            Raza razaExistente = objDao.getById(Raza.class, "razas", razaActualizada.getId());

            if (razaExistente == null) {
                return new ResponseProvider(false, 404, "La raza con ese ID no existe", null, null).toResponse();
            }

            boolean actualizada = objDao.update(razaActualizada, "razas", "id");

            if (!actualizada) {
                return new ResponseProvider(false, 400, "No se pudo actualizar la raza", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Raza actualizada exitosamente", razaActualizada, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar la especie", e, null).toResponse();
        }
    }
    
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteTipoProducto(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Verificar si el tipo de producto existe
            Raza razaExistente = objDao.getById(Raza.class, "razas", id);
            if (razaExistente == null) {
                return new ResponseProvider(false, 404, "La raza no existe", null, null).toResponse();
            }

            // Verificar si hay productos asociados a ese tipo
            List<Mascota> mascotasAsociadas = objDao.getAllByField(Mascota.class, "mascotas", "id_raza", razaExistente.getId());

            if (!mascotasAsociadas.isEmpty()) {
                return new ResponseProvider(false, 400, "La raza tiene mascotas asociadas", null, null).toResponse();
            }

            // Eliminar tipo de producto
            boolean eliminado = objDao.delete(id, "razas", "id");

            if (!eliminado) {
                return new ResponseProvider(false, 400, "No se pudo eliminar la raza", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Raza eliminada exitosamente", null, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al eliminar la raza", e, null).toResponse();
        }
    }
}
