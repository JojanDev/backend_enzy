package CONTROLADOR;

import MODELO.DAO.CrudDAO;
import MODELO.Especie;
import MODELO.Mascota;
import MODELO.Raza;
import MODELO.DTO.RazaResponseDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 * Controlador REST para la gestión de razas. Proporciona operaciones CRUD
 * (crear, leer, actualizar y eliminar) sobre las razas, así como validaciones
 * relacionadas (como existencia de la raza o mascotas asociadas).
 *
 * Los métodos retornan respuestas en formato JSON estandarizadas mediante
 * ResponseProvider.
 */
@Path("razas")
public class RazaController {

    /**
     * Obtiene una raza específica por su ID.
     *
     * @param idRaza identificador único de la raza
     * @return Response con la raza encontrada o un error si no existe
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getRazaById(@PathParam("id") int idRaza) {
        try {
            CrudDAO objDao = new CrudDAO();
            Raza raza = objDao.getById(Raza.class, "razas", idRaza);

            if (raza == null) {
                // Si no se encuentra la raza, se devuelve error 404
                return new ResponseProvider(false, 404, "Raza no encontrada", null, null).toResponse();
            }

            // Obtener la especie asociada a la raza
            Especie especieRaza = objDao.getById(Especie.class, "especies", raza.getId_especie());

            // Crear DTO de respuesta para incluir especie y datos de la raza
            RazaResponseDTO razaDTO = new RazaResponseDTO();
            razaDTO.setEspecie(especieRaza);
            razaDTO.setId(raza.getId());
            razaDTO.setNombre(raza.getNombre());

            return new ResponseProvider(true, 200, "Raza obtenida correctamente", razaDTO, null).toResponse();
        } catch (Exception e) {
            // Manejo de errores internos
            return new ResponseProvider(false, 500, "Error al obtener la especie", e, null).toResponse();
        }
    }

    /**
     * Crea una nueva raza en la base de datos.
     *
     * @param nuevaRaza objeto con los datos de la nueva raza
     * @return Response con la raza registrada o error en caso de fallo
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createRaza(Raza nuevaRaza) {
        try {
            CrudDAO objDao = new CrudDAO();
            Raza razaCreada = objDao.create("razas", nuevaRaza);

            if (razaCreada == null) {
                // Si no se pudo registrar, retorna error 400
                return new ResponseProvider(false, 400, "No se pudo registrar la raza", null, null).toResponse();
            }

            return new ResponseProvider(true, 201, "Raza registrada exitosamente", razaCreada, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar la raza", e, null).toResponse();
        }
    }

    /**
     * Actualiza los datos de una raza existente.
     *
     * @param id identificador único de la raza a actualizar
     * @param razaActualizada objeto con los nuevos valores
     * @return Response con la raza actualizada o mensaje de error
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateRaza(@PathParam("id") int id, Raza razaActualizada) {
        try {
            CrudDAO objDao = new CrudDAO();

            razaActualizada.setId(id);

            // Validar si el ID está presente
            if (razaActualizada.getId() == 0) {
                return new ResponseProvider(false, 400, "El ID de la raza es obligatorio para actualizar", null, null).toResponse();
            }

            // Verificar si la raza existe antes de actualizar
            Raza razaExistente = objDao.getById(Raza.class, "razas", razaActualizada.getId());

            if (razaExistente == null) {
                return new ResponseProvider(false, 404, "La raza con ese ID no existe", null, null).toResponse();
            }

            // Realizar la actualización en base de datos
            boolean actualizada = objDao.update(razaActualizada, "razas", "id");

            if (!actualizada) {
                return new ResponseProvider(false, 400, "No se pudo actualizar la raza", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Raza actualizada exitosamente", razaActualizada, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar la especie", e, null).toResponse();
        }
    }

    /**
     * Elimina una raza por su ID.
     *
     * @param id identificador único de la raza
     * @return Response con el resultado de la operación
     */
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteRaza(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Verificar si la raza existe
            Raza razaExistente = objDao.getById(Raza.class, "razas", id);
            if (razaExistente == null) {
                return new ResponseProvider(false, 404, "La raza no existe", null, null).toResponse();
            }

            // Verificar si existen mascotas asociadas a esa raza
            List<Mascota> mascotasAsociadas = objDao.getAllByField(Mascota.class, "mascotas", "id_raza", razaExistente.getId());

            if (!mascotasAsociadas.isEmpty()) {
                return new ResponseProvider(false, 400, "La raza tiene mascotas asociadas", null, null).toResponse();
            }

            // Intentar eliminar la raza
            boolean eliminado = objDao.delete(id, "razas", "id");

            if (!eliminado) {
                return new ResponseProvider(false, 400, "No se pudo eliminar la raza", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Raza eliminada exitosamente", null, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al eliminar la raza", e, null).toResponse();
        }
    }
}
