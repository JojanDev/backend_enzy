package CONTROLADOR;

import MODELO.DAO.CrudDAO;
import MODELO.Especie;
import MODELO.Mascota;
import MODELO.Raza;
import MODELO.DTO.RazaResponseDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 * Controlador REST para la gestion de razas. Proporciona operaciones CRUD
 * (crear, leer, actualizar y eliminar) sobre las razas, asi como validaciones
 * relacionadas (como existencia de la raza o mascotas asociadas).
 *
 * Endpoints:
 *   GET    /razas/{id}    obtiene una raza por su ID
 *   POST   /razas         crea una nueva raza
 *   PUT    /razas/{id}    actualiza una raza existente
 *   DELETE /razas/{id}    elimina una raza
 *
 * Los metodos retornan respuestas en formato JSON estandarizadas mediante
 * ResponseProvider.
 */
@Path("razas")
public class RazaController {

    /**
     * Obtiene una raza especifica por su ID.
     *
     * @param idRaza identificador unico de la raza
     * @return Response con la raza encontrada o un error si no existe
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getRazaById(@PathParam("id") int idRaza) {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera la raza de la tabla 'razas' usando el ID proporcionado
            Raza raza = objDao.getById(Raza.class, "razas", idRaza);

            // si no existe la raza, retorna un 404 indicando que no se encontro
            if (raza == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "Raza no encontrada",
                        null,
                        null
                ).toResponse();
            }

            // obtiene la especie asociada a la raza desde la tabla 'especies'
            Especie especieRaza = objDao.getById(
                    Especie.class,
                    "especies",
                    raza.getId_especie()
            );

            // construye un DTO de respuesta que agrupa datos de raza y especie
            RazaResponseDTO razaDTO = new RazaResponseDTO();
            razaDTO.setEspecie(especieRaza);
            razaDTO.setId(raza.getId());
            razaDTO.setNombre(raza.getNombre());

            // retorna 200 con el DTO que incluye la raza y su especie
            return new ResponseProvider(
                    true,
                    200,
                    "Raza obtenida correctamente",
                    razaDTO,
                    null
            ).toResponse();

        } catch (Exception e) {
            // en caso de excepcion, retorna 500 con el detalle del error
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener la especie",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Crea una nueva raza en la base de datos.
     *
     * @param nuevaRaza objeto con los datos de la nueva raza
     * @return Response con la raza registrada o error en caso de fallo
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createRaza(Raza nuevaRaza) {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // inserta la nueva raza en la tabla 'razas'
            Raza razaCreada = objDao.create("razas", nuevaRaza);

            // si la creacion fallo, retorna 400 indicando que no se registro
            if (razaCreada == null) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo registrar la raza",
                        null,
                        null
                ).toResponse();
            }

            // retorna 201 con el objeto raza que se acabo de crear
            return new ResponseProvider(
                    true,
                    201,
                    "Raza registrada exitosamente",
                    razaCreada,
                    null
            ).toResponse();

        } catch (Exception e) {
            // en caso de error interno, retorna 500 con el detalle de la excepcion
            return new ResponseProvider(
                    false,
                    500,
                    "Error al registrar la raza",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Actualiza los datos de una raza existente.
     *
     * @param id identificador unico de la raza a actualizar
     * @param razaActualizada objeto con los nuevos valores de la raza
     * @return Response con la raza actualizada o mensaje de error
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateRaza(@PathParam("id") int id, Raza razaActualizada) {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // sincroniza el ID recibido en la ruta con el objeto de raza
            razaActualizada.setId(id);

            // valida que el ID no sea cero antes de proceder
            if (razaActualizada.getId() == 0) {
                return new ResponseProvider(
                        false,
                        400,
                        "El ID de la raza es obligatorio para actualizar",
                        null,
                        null
                ).toResponse();
            }

            // verifica si la raza existe en la base de datos
            Raza razaExistente = objDao.getById(
                    Raza.class,
                    "razas",
                    razaActualizada.getId()
            );
            // si no existe, retorna 404 indicando que no se encontro
            if (razaExistente == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "La raza con ese ID no existe",
                        null,
                        null
                ).toResponse();
            }

            // ejecuta la actualizacion en la tabla 'razas'
            boolean actualizada = objDao.update(
                    razaActualizada,
                    "razas",
                    "id"
            );
            // si la operacion de update falla, retorna 400
            if (!actualizada) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo actualizar la raza",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 con la raza ya actualizada
            return new ResponseProvider(
                    true,
                    200,
                    "Raza actualizada exitosamente",
                    razaActualizada,
                    null
            ).toResponse();

        } catch (Exception e) {
            // captura cualquier excepcion y retorna 500 con el detalle
            return new ResponseProvider(
                    false,
                    500,
                    "Error al actualizar la especie",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Elimina una raza segun su ID.
     *
     * @param id identificador unico de la raza a eliminar
     * @return Response con el resultado de la operacion de eliminacion
     */
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteRaza(@PathParam("id") int id) {
        try {
            // crea instancia de CrudDAO para gestionar operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // verifica si la raza existe en la tabla 'razas'
            Raza razaExistente = objDao.getById(
                    Raza.class,
                    "razas",
                    id
            );
            // si no se encuentra, retorna 404 indicando que la raza no existe
            if (razaExistente == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "La raza no existe",
                        null,
                        null
                ).toResponse();
            }

            // obtiene todas las mascotas asociadas a esta raza para validar integridad
            List<Mascota> mascotasAsociadas = objDao.getAllByField(
                    Mascota.class,
                    "mascotas",
                    "id_raza",
                    razaExistente.getId()
            );
            // si hay mascotas asociadas, evita eliminar la raza y retorna 400
            if (!mascotasAsociadas.isEmpty()) {
                return new ResponseProvider(
                        false,
                        400,
                        "La raza tiene mascotas asociadas",
                        null,
                        null
                ).toResponse();
            }

            // intenta eliminar la raza de la tabla 'razas'
            boolean eliminado = objDao.delete(
                    id,
                    "razas",
                    "id"
            );
            // si la eliminacion falla, retorna 400 con mensaje de error
            if (!eliminado) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo eliminar la raza",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 confirmando que la raza se elimino exitosamente
            return new ResponseProvider(
                    true,
                    200,
                    "Raza eliminada exitosamente",
                    null,
                    null
            ).toResponse();

        } catch (Exception e) {
            // en caso de excepcion imprevista, retorna 500 con el detalle del error
            return new ResponseProvider(
                    false,
                    500,
                    "Error al eliminar la raza",
                    e,
                    null
            ).toResponse();
        }
    }

}
