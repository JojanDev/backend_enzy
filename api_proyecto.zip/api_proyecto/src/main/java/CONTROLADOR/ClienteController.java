    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.Cliente;
import MODELO.ClienteResponseDTO;
import MODELO.ClienteRequestDTO;
import MODELO.ConexionBD;
import MODELO.CrudDAO;
import MODELO.IcpResponseDTO;
import MODELO.InformacionClientesPersonal;
import MODELO.TipoDocumento;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import modelo.ClienteDtoBuilder;

/**
 *
 * @author USUARIO
 */

@Path("clientes")
public class ClienteController {
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllClientes() {
        try {
            final CrudDAO objDao = new CrudDAO();
            final List<Cliente> clientes = objDao.getAll(Cliente.class, "clientes");

            if (clientes.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay clientes registrados", null, null).toResponse();
            }

            List<ClienteResponseDTO> clientesInfo = new ArrayList<>();

            for (Cliente c : clientes) {
                ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(c, objDao);
                if (clienteDTO != null) {
                    clientesInfo.add(clienteDTO);
                }
            }


            return new ResponseProvider(true, 200, "Clientes obtenidos correctamente", clientesInfo, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los clientes", e, null).toResponse(); 
        }
    }

    
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getClienteById(@PathParam("id") int id) {
        try {
            final CrudDAO objDao = new CrudDAO();

            // Obtener el cliente
            Cliente cliente = objDao.getById(Cliente.class, "clientes", id);
            if (cliente == null) {
                return new ResponseProvider(false, 404, "Cliente no encontrado", null, null).toResponse();
            }

            // Intentar construir el DTO completo
            ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);
            if (clienteDTO == null) {
                return new ResponseProvider(false, 500, "No se pudo obtener la información completa del cliente", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Cliente obtenido correctamente", clienteDTO, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener el cliente", e, null).toResponse();
        }
    }


    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createCliente(ClienteRequestDTO cliente) {
        Connection con = null;
        try {
            con = ConexionBD.conectar();
            con.setAutoCommit(false); // Inicia transacción manual

            CrudDAO objDao = new CrudDAO(con);

            // Crear y poblar objeto de información personal
            InformacionClientesPersonal infoCliente = new InformacionClientesPersonal();
            infoCliente.setIdTipoDocumento(cliente.getIdTipoDocumento());
            infoCliente.setNumeroDocumento(cliente.getNumeroDocumento());
            infoCliente.setNombre(cliente.getNombre());
            infoCliente.setTelefono(cliente.getTelefono());
            infoCliente.setCorreo(cliente.getCorreo());
            infoCliente.setDireccion(cliente.getDireccion());

            // Insertar información personal
            InformacionClientesPersonal infoClienteResponse = objDao.create(
                "informacion_clientes_personal",
                infoCliente
            );

            if (infoClienteResponse == null) {
                con.rollback();
                return new ResponseProvider<>(false, 500, "Error al crear la información del cliente", null, null).toResponse();
            }

            // Crear y poblar objeto cliente
            Cliente clienteEntity = new Cliente();
            clienteEntity.setId_info(infoClienteResponse.getId());


            // Insertar cliente
            Cliente clienteResponse = objDao.create(
                "clientes",
                clienteEntity
            );

            if (clienteResponse == null) {
                con.rollback();
                return new ResponseProvider<>(false, 500, "Error al crear el cliente", null, null).toResponse();
            }

            // Si todo fue bien
            con.commit();
            
            TipoDocumento tipoDocumento = objDao.getById(TipoDocumento.class, "tipos_documento", infoClienteResponse.getIdTipoDocumento());
            
            IcpResponseDTO infoDTO = new IcpResponseDTO(
                    infoClienteResponse.getId(),
                    tipoDocumento,
                    infoClienteResponse.getNumeroDocumento(),
                    infoClienteResponse.getNombre(),
                    infoClienteResponse.getTelefono(),
                    infoClienteResponse.getCorreo(),
                    infoClienteResponse.getDireccion()
            );

           // Al final del try, después de insertar cliente correctamente:
            ClienteResponseDTO responseDto = new ClienteResponseDTO(
                    clienteResponse.getId(),
                    infoDTO
            );

            return new ResponseProvider<>(true, 201, "Cliente creado correctamente", responseDto, null).toResponse();

            
        } catch (Exception e) {
            try {
                if (con != null) con.rollback();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return new ResponseProvider<>(false, 500, "Error inesperado al crear el cliente", null, null).toResponse();
        } finally {
            try {
                if (con != null) con.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
