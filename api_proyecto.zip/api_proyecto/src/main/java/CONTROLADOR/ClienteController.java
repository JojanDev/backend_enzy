/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.Cliente;
import MODELO.ClienteInfoDTO;
import MODELO.CrudDAO;
import MODELO.InformacionClientesPersonal;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */

@Path("clientes")
public class ClienteController {
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllClientes() {
        try {
            final CrudDAO objDao = new CrudDAO();
            final List<Cliente> clientes = objDao.getAll(Cliente.class, "clientes");
            
            // Validamos si existen clientes
            if (clientes.isEmpty())
                return new ResponseProvider(false, 404, "No hay clientes registrados", null, null).toResponse();
            
            List<ClienteInfoDTO> clientesInfo = new ArrayList<>();
            
            for (Cliente c : clientes) {
                List<InformacionClientesPersonal> info = objDao.getById(InformacionClientesPersonal.class, "informacion_clientes_personal", c.getId_info());
                ClienteInfoDTO dto = new ClienteInfoDTO();
                dto.setId(c.getId());
                dto.setInfo(info.get(0));
                clientesInfo.add(dto);
            }
            
            return new ResponseProvider(true, 200, "Clientes obtenidos correctamente", clientesInfo, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los clientes", e, null).toResponse(); 
        }
    }
}
