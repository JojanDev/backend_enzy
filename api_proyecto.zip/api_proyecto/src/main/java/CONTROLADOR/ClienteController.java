package CONTROLADOR;

import MODELO.Cliente;
import MODELO.DAO.ClienteDAO;
import MODELO.DTO.ClienteResponseDTO;
import MODELO.ConexionBD;
import MODELO.DAO.CrudDAO;
import MODELO.DTO.IcpResponseDTO;
import MODELO.InformacionClientesPersonal;
import MODELO.TipoDocumento;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import MODELO.DTO.ClienteDtoBuilder;
import java.sql.SQLException;

/**
 * Controlador REST para gestionar operaciones relacionadas con clientes.
 * Proporciona endpoints para:
 * - obtener todos los clientes registrados
 * - obtener clientes sin empleado asociado
 * - obtener cliente por ID
 * - crear cliente con informacion personal nueva
 * - crear cliente reutilizando informacion personal existente
 * - actualizar informacion personal de cliente existente
 */
@Path("clientes")
public class ClienteController {

        /**
     * Obtiene todos los clientes registrados en la base de datos.
     * Cada cliente se transforma en un DTO con informacion adicional.
     *
     * @return Response con lista de ClienteResponseDTO o error si no hay registros
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllClientes() {
        try {
            // Crea instancia de CrudDAO para operaciones CRUD
            final CrudDAO objDao = new CrudDAO();

            // Recupera todos los registros de la tabla 'clientes'
            final List<Cliente> clientes = objDao.getAll(Cliente.class, "clientes");

            // Si no hay clientes, retorna 404
            if (clientes.isEmpty()) {
                return new ResponseProvider(
                    false,
                    404,
                    "No hay clientes registrados",
                    null,
                    null
                ).toResponse();
            }

            // Lista para almacenar DTOs enriquecidos
            List<ClienteResponseDTO> clientesInfo = new ArrayList<>();

            // Recorre cada cliente y construye su DTO
            for (Cliente c : clientes) {
                // Utiliza el builder para obtener el DTO con datos extra
                ClienteResponseDTO clienteDTO =
                    ClienteDtoBuilder.construirClienteDTO(c, objDao);
                // Agrega el DTO si se construyo correctamente
                if (clienteDTO != null) {
                    clientesInfo.add(clienteDTO);
                }
            }

            // Retorna 200 con la lista de DTOs de clientes
            return new ResponseProvider(
                true,
                200,
                "Clientes obtenidos correctamente",
                clientesInfo,
                null
            ).toResponse();

        } catch (Exception e) {
            // Retorna 500 en caso de error inesperado
            return new ResponseProvider(
                false,
                500,
                "Error al obtener los clientes",
                e,
                null
            ).toResponse();
        }
    }

    /**
     * Obtiene informacion de clientes que no estan asociados a ningun empleado.
     * Utiliza una consulta especializada en ClienteDAO.
     *
     * @return Response con lista de InformacionClientesPersonal o error
     */
    @GET
    @Path("/noEmpleados")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getInfoClientesSinEmpleado() {
        try {
            // Crea instancia de ClienteDAO para consulta especializada
            ClienteDAO objDao = new ClienteDAO();

            // Recupera clientes sin empleado asignado
            List<InformacionClientesPersonal> clientesInfo =
                objDao.getClientesSinEmpleado();

            // Si no hay resultados, retorna 404
            if (clientesInfo.isEmpty()) {
                return new ResponseProvider(
                    false,
                    404,
                    "No hay informacion valida registrada",
                    null,
                    null
                ).toResponse();
            }

            // Retorna 200 con la lista de informacion de clientes
            return new ResponseProvider(
                true,
                200,
                "Informacion obtenida correctamente",
                clientesInfo,
                null
            ).toResponse();

        } catch (Exception e) {
            // Retorna 500 en caso de error durante la consulta
            return new ResponseProvider(
                false,
                500,
                "Error al obtener los datos",
                e,
                null
            ).toResponse();
        }
    }

    /**
     * Obtiene un cliente por su ID, incluyendo informacion adicional en DTO.
     *
     * @param id ID del cliente a consultar
     * @return Response con ClienteResponseDTO o error si no existe
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getClienteById(@PathParam("id") int id) {
        try {
            // Crea instancia de CrudDAO para operaciones CRUD
            final CrudDAO objDao = new CrudDAO();

            // Recupera el cliente por su ID
            Cliente cliente = objDao.getById(Cliente.class, "clientes", id);

            // Si el cliente no existe, retorna 404
            if (cliente == null) {
                return new ResponseProvider(
                    false,
                    404,
                    "Cliente no encontrado",
                    null,
                    null
                ).toResponse();
            }

            // Construye DTO enriquecido con informacion adicional
            ClienteResponseDTO clienteDTO =
                ClienteDtoBuilder.construirClienteDTO(cliente, objDao);

            // Si no se pudo construir el DTO completo, retorna 500
            if (clienteDTO == null) {
                return new ResponseProvider(
                    false,
                    500,
                    "No se pudo obtener la informacion completa del cliente",
                    null,
                    null
                ).toResponse();
            }

            // Retorna 200 con el DTO del cliente
            return new ResponseProvider(
                true,
                200,
                "Cliente obtenido correctamente",
                clienteDTO,
                null
            ).toResponse();

        } catch (Exception e) {
            // Retorna 500 en caso de error inesperado
            return new ResponseProvider(
                false,
                500,
                "Error al obtener el cliente",
                e,
                null
            ).toResponse();
        }
    }

       /**
     * Crea un nuevo cliente junto con su informacion personal.
     * Realiza dos inserciones en la base de datos usando transaccion manual
     * para asegurar la consistencia de ambas operaciones.
     *
     * @param cliente objeto con los datos personales del cliente
     * @return Response con ClienteResponseDTO si se crea exitosamente, o error
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createCliente(InformacionClientesPersonal cliente) {
        Connection con = null;
        try {
            // Abre conexion y desactiva auto-commit para manejar transaccion manual
            con = ConexionBD.conectar();
            con.setAutoCommit(false);

            // Instancia DAO usando la misma conexion para compartir transaccion
            CrudDAO objDao = new CrudDAO(con);

            // Construye el objeto de informacion personal a partir del JSON recibido
            InformacionClientesPersonal infoCliente = new InformacionClientesPersonal();
            infoCliente.setId_tipo_documento(cliente.getId_tipo_documento());
            infoCliente.setNumero_documento(cliente.getNumero_documento());
            infoCliente.setNombre(cliente.getNombre());
            infoCliente.setTelefono(cliente.getTelefono());
            infoCliente.setCorreo(cliente.getCorreo());
            infoCliente.setDireccion(cliente.getDireccion());

            // Inserta la informacion personal y obtiene el registro creado
            InformacionClientesPersonal infoClienteResponse =
                objDao.create("informacion_clientes_personal", infoCliente);

            // Si falla la insercion de info personal, revierte y retorna error
            if (infoClienteResponse == null) {
                con.rollback();
                return new ResponseProvider<>(
                    false,
                    500,
                    "Error al crear la informacion del cliente",
                    null,
                    null
                ).toResponse();
            }

            // Prepara la entidad Cliente con la referencia a info personal
            Cliente clienteEntity = new Cliente();
            clienteEntity.setId_info(infoClienteResponse.getId());

            // Inserta el cliente en la tabla 'clientes'
            Cliente clienteResponse =
                objDao.create("clientes", clienteEntity);

            // Si falla la insercion de cliente, revierte y retorna error
            if (clienteResponse == null) {
                con.rollback();
                return new ResponseProvider<>(
                    false,
                    500,
                    "Error al crear el cliente",
                    null,
                    null
                ).toResponse();
            }

            // Confirma la transaccion tras inserciones exitosas
            con.commit();

            // Recupera el tipo de documento para completar el DTO
            TipoDocumento tipoDocumento = objDao.getById(
                TipoDocumento.class,
                "tipos_documento",
                infoClienteResponse.getId_tipo_documento()
            );

            // Construye DTO de informacion personal enriquecido
            IcpResponseDTO infoDTO = new IcpResponseDTO(
                infoClienteResponse.getId(),
                tipoDocumento,
                infoClienteResponse.getNumero_documento(),
                infoClienteResponse.getNombre(),
                infoClienteResponse.getTelefono(),
                infoClienteResponse.getCorreo(),
                infoClienteResponse.getDireccion()
            );

            // Construye DTO de respuesta con ID de cliente e info personal
            ClienteResponseDTO responseDto =
                new ClienteResponseDTO(clienteResponse.getId(), infoDTO);

            // Retorna 201 con el DTO del cliente creado
            return new ResponseProvider<>(
                true,
                201,
                "Cliente creado correctamente",
                responseDto,
                null
            ).toResponse();

        } catch (Exception e) {
            // En caso de error, revierte transaccion si la conexion existe
            try {
                if (con != null) {
                    con.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            // Imprime traza de excepcion y retorna 500
            e.printStackTrace();
            return new ResponseProvider<>(
                false,
                500,
                "Error inesperado al crear el cliente",
                null,
                null
            ).toResponse();

        } finally {
            // Cierra la conexion si fue abierta
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

        /**
     * Crea un nuevo cliente utilizando informacion personal ya existente.
     * Inserta solo en la tabla 'clientes' y reutiliza la informacion personal.
     *
     * @param nuevoCliente objeto Cliente con referencia a informacion personal existente
     * @return Response con ClienteResponseDTO si se crea exitosamente, o error
     */
    @POST
    @Path("/infoExistente")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createPersonalInformacionExistente(Cliente nuevoCliente) {
        try {
            // Instancia CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // Inserta el nuevo cliente en la tabla 'clientes'
            Cliente clienteCreado = objDao.create("clientes", nuevoCliente);

            // Si falla la insercion, retorna 400
            if (clienteCreado == null) {
                return new ResponseProvider(
                    false,
                    400,
                    "No se pudo registrar el cliente",
                    null,
                    null
                ).toResponse();
            }

            // Recupera la informacion personal asociada al cliente recien creado
            InformacionClientesPersonal info = objDao.getById(
                InformacionClientesPersonal.class,
                "informacion_clientes_personal",
                clienteCreado.getId_info()
            );

            // Construye el DTO de informacion personal enriquecido
            IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);

            // Construye el DTO de cliente completo con ID e info personal
            ClienteResponseDTO clienteCreadoDTO =
                new ClienteResponseDTO(clienteCreado.getId(), infoDTO);

            // Retorna 201 con el DTO del cliente creado
            return new ResponseProvider(
                true,
                201,
                "Cliente registrado exitosamente",
                clienteCreadoDTO,
                null
            ).toResponse();

        } catch (Exception e) {
            // Retorna 500 en caso de error inesperado
            return new ResponseProvider(
                false,
                500,
                "Error al registrar el cliente",
                e,
                null
            ).toResponse();
        }
    }

    /**
     * Actualiza la informacion personal de un cliente existente.
     * Modifica los datos en 'informacion_clientes_personal' segun el ID proporcionado.
     *
     * @param id                          ID del cliente a actualizar
     * @param clienteInfoActualizado      objeto con los nuevos valores de informacion personal
     * @return Response indicando si la actualizacion fue exitosa o no
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateCliente(
            @PathParam("id") int id,
            InformacionClientesPersonal clienteInfoActualizado) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Asigna el ID de ruta al objeto que se actualizara
            clienteInfoActualizado.setId(id);

            // Validacion: el ID debe ser mayor a cero
            if (clienteInfoActualizado.getId() == 0) {
                return new ResponseProvider(
                    false,
                    400,
                    "El ID del cliente es obligatorio para actualizar",
                    null,
                    null
                ).toResponse();
            }

            // Verifica que exista un registro con ese ID
            InformacionClientesPersonal clienteExistente = objDao.getById(
                InformacionClientesPersonal.class,
                "informacion_clientes_personal",
                id
            );

            // Si no existe, retorna 404
            if (clienteExistente == null) {
                return new ResponseProvider(
                    false,
                    404,
                    "El cliente con ese ID no existe",
                    null,
                    null
                ).toResponse();
            }

            // Ejecuta la actualizacion en la base de datos
            boolean actualizada = objDao.update(
                clienteInfoActualizado,
                "informacion_clientes_personal",
                "id"
            );

            // Si no se actualizo, retorna 400
            if (!actualizada) {
                return new ResponseProvider(
                    false,
                    400,
                    "No se pudo actualizar la informacion del cliente",
                    null,
                    null
                ).toResponse();
            }

            // Retorna 200 con la informacion actualizada
            return new ResponseProvider(
                true,
                200,
                "Informacion del cliente actualizada exitosamente",
                clienteInfoActualizado,
                null
            ).toResponse();

        } catch (Exception e) {
            // Retorna 500 en caso de error durante la operacion
            return new ResponseProvider(
                false,
                500,
                "Error al actualizar la informacion del cliente",
                e,
                null
            ).toResponse();
        }
    }
}
