package CONTROLADOR;

import MODELO.Cliente;
import MODELO.DAO.ClienteDAO;
import MODELO.DTO.ClienteResponseDTO;
import MODELO.ConexionBD;
import MODELO.DAO.CrudDAO;
import MODELO.DTO.IcpResponseDTO;
import MODELO.InformacionClientesPersonal;
import MODELO.TipoDocumento;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import MODELO.DTO.ClienteDtoBuilder;

/**
 * Controlador REST para gestionar operaciones relacionadas con clientes.
 * Permite consultar todos los clientes, obtener clientes sin empleado asociado
 * y buscar por ID.
 */
@Path("clientes")
public class ClienteController {

    /**
     * Obtiene todos los clientes registrados en la base de datos. Cada cliente
     * se transforma en un DTO enriquecido con información adicional.
     *
     * @return Respuesta con la lista de clientes o mensaje de error si no hay
     * registros.
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllClientes() {
        try {
            final CrudDAO objDao = new CrudDAO();

            // Consulta todos los registros de la tabla 'clientes'
            final List<Cliente> clientes = objDao.getAll(Cliente.class, "clientes");

            if (clientes.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay clientes registrados", null, null).toResponse();
            }

            List<ClienteResponseDTO> clientesInfo = new ArrayList<>();

            // Recorre cada cliente y construye su DTO correspondiente
            for (Cliente c : clientes) {
                ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(c, objDao);
                if (clienteDTO != null) {
                    clientesInfo.add(clienteDTO);
                }
            }

            return new ResponseProvider(true, 200, "Clientes obtenidos correctamente", clientesInfo, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los clientes", e, null).toResponse();
        }
    }

    /**
     * Obtiene información de clientes que no están asociados a ningún empleado.
     * Utiliza una consulta especializada en ClienteDAO.
     *
     * @return Respuesta con la lista de clientes sin empleado o mensaje de
     * error.
     */
    @GET
    @Path("/noEmpleados")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getInfoClientesSinEmpleado() {
        try {
            ClienteDAO objDao = new ClienteDAO();

            // Consulta clientes que no tienen relación con la tabla 'personal'
            List<InformacionClientesPersonal> clientesInfo = objDao.getClientesSinEmpleado();

            if (clientesInfo.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay informacion valida registrada", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Informacion obtenida correctamente", clientesInfo, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los datos", e, null).toResponse();
        }
    }

    /**
     * Obtiene un cliente por su ID, incluyendo información adicional mediante
     * DTO.
     *
     * @param id ID del cliente a consultar.
     * @return Respuesta con el cliente encontrado o mensaje de error si no
     * existe.
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getClienteById(@PathParam("id") int id) {
        try {
            final CrudDAO objDao = new CrudDAO();

            // Consulta el cliente por su ID
            Cliente cliente = objDao.getById(Cliente.class, "clientes", id);

            if (cliente == null) {
                return new ResponseProvider(false, 404, "Cliente no encontrado", null, null).toResponse();
            }

            // Construye el DTO enriquecido con información adicional
            ClienteResponseDTO clienteDTO = ClienteDtoBuilder.construirClienteDTO(cliente, objDao);

            if (clienteDTO == null) {
                return new ResponseProvider(false, 500, "No se pudo obtener la información completa del cliente", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Cliente obtenido correctamente", clienteDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener el cliente", e, null).toResponse();
        }
    }

    /**
     * Crea un nuevo cliente junto con su información personal. Este método
     * realiza dos inserciones: una en 'informacion_clientes_personal' y otra en
     * 'clientes'. Utiliza transacciones manuales para asegurar consistencia
     * entre ambas operaciones.
     *
     * @param cliente Objeto con los datos personales del cliente.
     * @return Respuesta con el cliente creado o mensaje de error.
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createCliente(InformacionClientesPersonal cliente) {
        Connection con = null;
        try {
            con = ConexionBD.conectar();
            con.setAutoCommit(false); // Inicia transacción manual

            CrudDAO objDao = new CrudDAO(con);

            // Construye el objeto de información personal a partir del JSON recibido
            InformacionClientesPersonal infoCliente = new InformacionClientesPersonal();
            infoCliente.setId_tipo_documento(cliente.getId_tipo_documento());
            infoCliente.setNumero_documento(cliente.getNumero_documento());
            infoCliente.setNombre(cliente.getNombre());
            infoCliente.setTelefono(cliente.getTelefono());
            infoCliente.setCorreo(cliente.getCorreo());
            infoCliente.setDireccion(cliente.getDireccion());

            // Inserta la información personal en la base de datos
            InformacionClientesPersonal infoClienteResponse = objDao.create("informacion_clientes_personal", infoCliente);

            if (infoClienteResponse == null) {
                con.rollback(); // Revierte la transacción si falla la inserción
                return new ResponseProvider<>(false, 500, "Error al crear la información del cliente", null, null).toResponse();
            }

            // Crea el objeto Cliente con la referencia a la información personal recién insertada
            Cliente clienteEntity = new Cliente();
            clienteEntity.setId_info(infoClienteResponse.getId());

            // Inserta el cliente en la base de datos
            Cliente clienteResponse = objDao.create("clientes", clienteEntity);

            if (clienteResponse == null) {
                con.rollback(); // Revierte la transacción si falla la inserción
                return new ResponseProvider<>(false, 500, "Error al crear el cliente", null, null).toResponse();
            }

            con.commit(); // Confirma la transacción si todo fue exitoso

            // Obtiene el tipo de documento para construir el DTO completo
            TipoDocumento tipoDocumento = objDao.getById(TipoDocumento.class, "tipos_documento", infoClienteResponse.getId_tipo_documento());

            IcpResponseDTO infoDTO = new IcpResponseDTO(
                    infoClienteResponse.getId(),
                    tipoDocumento,
                    infoClienteResponse.getNumero_documento(),
                    infoClienteResponse.getNombre(),
                    infoClienteResponse.getTelefono(),
                    infoClienteResponse.getCorreo(),
                    infoClienteResponse.getDireccion()
            );

            ClienteResponseDTO responseDto = new ClienteResponseDTO(clienteResponse.getId(), infoDTO);

            return new ResponseProvider<>(true, 201, "Cliente creado correctamente", responseDto, null).toResponse();

        } catch (Exception e) {
            try {
                if (con != null) {
                    con.rollback(); // Intenta revertir la transacción en caso de error
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return new ResponseProvider<>(false, 500, "Error inesperado al crear el cliente", null, null).toResponse();

        } finally {
            try {
                if (con != null) {
                    con.close(); // Cierra la conexión
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * Crea un nuevo cliente utilizando información personal ya existente. Este
     * método solo inserta en la tabla 'clientes' y reutiliza la información
     * personal.
     *
     * @param nuevoCliente Objeto Cliente con referencia a la información
     * personal existente.
     * @return Respuesta con el cliente creado o mensaje de error.
     */
    @POST
    @Path("/infoExistente")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createPersonalInformacionExistente(Cliente nuevoCliente) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Inserta el cliente en la base de datos
            Cliente clienteCreado = objDao.create("clientes", nuevoCliente);

            if (clienteCreado == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar el cliente", null, null).toResponse();
            }

            // Obtiene la información personal asociada al cliente
            InformacionClientesPersonal info = objDao.getById(
                    InformacionClientesPersonal.class,
                    "informacion_clientes_personal",
                    clienteCreado.getId_info()
            );

            // Construye el DTO de información personal
            IcpResponseDTO infoDTO = ClienteDtoBuilder.construirInfoDTO(info, objDao);

            // Construye el DTO de cliente completo
            ClienteResponseDTO clienteCreadoDTO = new ClienteResponseDTO(clienteCreado.getId(), infoDTO);

            return new ResponseProvider(true, 201, "Cliente registrado exitosamente", clienteCreadoDTO, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar el cliente", e, null).toResponse();
        }
    }

    /**
     * Actualiza la información personal de un cliente existente. Este método
     * modifica los datos en la tabla 'informacion_clientes_personal' según el
     * ID proporcionado.
     *
     * @param id ID del cliente a actualizar.
     * @param clienteInfoActualizado Objeto con los nuevos valores para la
     * información personal.
     * @return Respuesta indicando si la actualización fue exitosa o no.
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateCliente(@PathParam("id") int id, InformacionClientesPersonal clienteInfoActualizado) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Asigna el ID recibido por parámetro al objeto que será actualizado
            clienteInfoActualizado.setId(id);

            // Validación básica: el ID debe ser mayor a cero
            if (clienteInfoActualizado.getId() == 0) {
                return new ResponseProvider(false, 400, "El ID del cliente es obligatorio para actualizar", null, null).toResponse();
            }

            // Verifica si existe un registro con ese ID en la base de datos
            InformacionClientesPersonal clienteExistente = objDao.getById(
                    InformacionClientesPersonal.class,
                    "informacion_clientes_personal",
                    id
            );

            if (clienteExistente == null) {
                return new ResponseProvider(false, 404, "El cliente con ese ID no existe", null, null).toResponse();
            }

            // Realiza la actualización en la base de datos
            boolean actualizada = objDao.update(clienteInfoActualizado, "informacion_clientes_personal", "id");

            if (!actualizada) {
                return new ResponseProvider(false, 400, "No se pudo actualizar la información del cliente", null, null).toResponse();
            }

            // Retorna la información actualizada como parte de la respuesta
            return new ResponseProvider(true, 200, "Información del cliente actualizada exitosamente", clienteInfoActualizado, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar la información del cliente", e, null).toResponse();
        }
    }

}
