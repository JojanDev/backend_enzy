/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.Cliente;
import MODELO.CrudDAO;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 *
 * @author USUARIO
 */

@Path("clientes")
public class ClienteController {
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllClientes() {
        try {
            final CrudDAO objDao = new CrudDAO();
            final List<Cliente> clientes = objDao.getAll(Cliente.class, "clientes");

            if (clientes.isEmpty())
                return new ResponseProvider(false, 404, "No hay clientes registrado", null, null).toResponse();
            
            return new ResponseProvider(true, 200, "Clientes obtenidos correctamente", clientes, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los clientes", null, null).toResponse(); 
        }
    }
}
