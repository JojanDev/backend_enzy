package CONTROLADOR;

import MODELO.DAO.CrudDAO;
import MODELO.Producto;
import MODELO.TipoProducto;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 * Controlador REST para la gestion de tipos de producto.
 * Proporciona endpoints para:
 * - listar todos los tipos de producto
 * - consultar un tipo de producto por su ID
 * - crear un nuevo tipo de producto
 * - actualizar un tipo de producto existente
 * - eliminar un tipo de producto
 *
 * Utiliza CrudDAO para operaciones CRUD y ResponseProvider para respuestas JSON estandarizadas.
 */
@Path("tipos-productos")
public class TipoProductoController {

    /**
     * Obtiene todos los tipos de productos registrados en la base de datos.
     *
     * @return Response con la lista de TipoProducto o mensaje de error si no
     * hay registros
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllTiposProductos() {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera todos los registros de la tabla 'tipos_productos'
            List<TipoProducto> tiposProductos = objDao.getAll(
                    TipoProducto.class,
                    "tipos_productos"
            );

            // si no hay tipos registrados, retorna 404
            if (tiposProductos.isEmpty()) {
                return new ResponseProvider(
                        false,
                        404,
                        "No hay tipos de productos registrados",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 con la lista de tipos de producto
            return new ResponseProvider(
                    true,
                    200,
                    "Tipos de productos obtenidos correctamente",
                    tiposProductos,
                    null
            ).toResponse();

        } catch (Exception e) {
            // en caso de error interno, retorna 500 con detalle de la excepcion
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener los tipos de productos",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Busca un tipo de producto por su ID.
     *
     * @param idTipo ID del tipo de producto a consultar
     * @return Response con el TipoProducto encontrado o mensaje de error si no
     * existe
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTipoProductoById(@PathParam("id") int idTipo) {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // recupera el registro de tipo de producto por ID
            TipoProducto tipoProducto = objDao.getById(
                    TipoProducto.class,
                    "tipos_productos",
                    idTipo
            );

            // si no se encontro el tipo, retorna 404
            if (tipoProducto == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "Tipo de producto no encontrado",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 con el tipo de producto encontrado
            return new ResponseProvider(
                    true,
                    200,
                    "Tipo de producto obtenido correctamente",
                    tipoProducto,
                    null
            ).toResponse();

        } catch (Exception e) {
            // en caso de error interno, retorna 500 con detalle de la excepcion
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener el tipo de producto",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Crea un nuevo tipo de producto.
     *
     * @param nuevoTipo Objeto TipoProducto con los datos a registrar
     * @return Response con el TipoProducto creado o mensaje de error si falla
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createTipoProducto(TipoProducto nuevoTipo) {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // inserta el nuevo tipo en la tabla 'tipos_productos'
            TipoProducto tipoCreado = objDao.create(
                    "tipos_productos",
                    nuevoTipo
            );

            // si la insercion falla, retorna 400
            if (tipoCreado == null) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo registrar el tipo de producto",
                        null,
                        null
                ).toResponse();
            }

            // retorna 201 con el tipo de producto creado
            return new ResponseProvider(
                    true,
                    201,
                    "Tipo de producto registrado exitosamente",
                    tipoCreado,
                    null
            ).toResponse();

        } catch (Exception e) {
            // en caso de error interno, retorna 500 con detalle de la excepcion
            return new ResponseProvider(
                    false,
                    500,
                    "Error al registrar el tipo de producto",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Actualiza un tipo de producto existente.
     *
     * @param id ID del tipo de producto a actualizar
     * @param tipoActualizado Objeto TipoProducto con los nuevos valores
     * @return Response con el TipoProducto actualizado o mensaje de error si
     * falla
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateTipoProducto(
            @PathParam("id") int id,
            TipoProducto tipoActualizado) {
        try {
            // crea instancia de CrudDAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // asigna el ID de ruta al objeto que se actualizara
            tipoActualizado.setId(id);

            // valida que el ID no sea cero
            if (tipoActualizado.getId() == 0) {
                return new ResponseProvider(
                        false,
                        400,
                        "El ID del tipo de producto es obligatorio para actualizar",
                        null,
                        null
                ).toResponse();
            }

            // verifica existencia del registro en la base de datos
            TipoProducto tipoExistente = objDao.getById(
                    TipoProducto.class,
                    "tipos_productos",
                    tipoActualizado.getId()
            );
            if (tipoExistente == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "El tipo de producto con ese ID no existe",
                        null,
                        null
                ).toResponse();
            }

            // ejecuta la actualizacion en la tabla 'tipos_productos'
            boolean actualizada = objDao.update(
                    tipoActualizado,
                    "tipos_productos",
                    "id"
            );
            // si la actualizacion falla, retorna 400
            if (!actualizada) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo actualizar el tipo de producto",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 con el objeto actualizado
            return new ResponseProvider(
                    true,
                    200,
                    "Tipo de producto actualizado exitosamente",
                    tipoActualizado,
                    null
            ).toResponse();

        } catch (Exception e) {
            // en caso de error interno, retorna 500 con detalle de la excepcion
            return new ResponseProvider(
                    false,
                    500,
                    "Error al actualizar el tipo de producto",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Elimina un tipo de producto por su ID.
     *
     * @param id ID del tipo de producto a eliminar
     * @return Response indicando si se eliminó correctamente o mensaje de error
     */
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteTipoProducto(@PathParam("id") int id) {
        try {
            // instancia el DAO para operaciones CRUD
            CrudDAO objDao = new CrudDAO();

            // verifica si el tipo de producto existe en la base de datos
            TipoProducto tipoExistente = objDao.getById(
                    TipoProducto.class,
                    "tipos_productos",
                    id
            );
            if (tipoExistente == null) {
                // no existe el registro, retorna 404 para informar al cliente
                return new ResponseProvider(
                        false,
                        404,
                        "El tipo de producto no existe",
                        null,
                        null
                ).toResponse();
            }

            // obtiene lista de productos asociados a este tipo para evitar eliminacion inconsistente
            List<Producto> productosAsociados = objDao.getAllByField(
                    Producto.class,
                    "productos",
                    "id_tipo",
                    tipoExistente.getId()
            );
            if (!productosAsociados.isEmpty()) {
                // si hay productos vinculados, no permite eliminar el tipo
                return new ResponseProvider(
                        false,
                        400,
                        "El tipo tiene productos asociados",
                        null,
                        null
                ).toResponse();
            }

            // ejecuta la eliminacion del tipo de producto en la tabla 'tipos_productos'
            boolean eliminado = objDao.delete(
                    id,
                    "tipos_productos",
                    "id"
            );
            if (!eliminado) {
                // la operacion de borrado fallo, retorna 400
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo eliminar el tipo de producto",
                        null,
                        null
                ).toResponse();
            }

            // tipo de producto eliminado correctamente, retorna 200
            return new ResponseProvider(
                    true,
                    200,
                    "Tipo de producto eliminado exitosamente",
                    null,
                    null
            ).toResponse();

        } catch (Exception e) {
            // captura excepciones inesperadas y retorna 500 con el error
            return new ResponseProvider(
                    false,
                    500,
                    "Error al eliminar el tipo de producto",
                    e,
                    null
            ).toResponse();
        }
    }

}
