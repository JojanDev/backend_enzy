package CONTROLADOR;

import MODELO.DAO.CrudDAO;
import MODELO.Producto;
import MODELO.TipoProducto;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 * Controlador REST para la gestion de Tipos de Producto.
 *
 * Expone operaciones CRUD contra la tabla tipos_productos usando CrudDAO
 * y respuestas estandarizadas con ResponseProvider.
 */
@Path("tipos-productos")
public class TipoProductoController {

    /**
     * Obtiene todos los tipos de productos registrados en la base de datos.
     *
     * @return Response con la lista de tipos de productos o mensaje de error
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllTiposProductos() {
        try {
            final CrudDAO objDao = new CrudDAO();
            final List<TipoProducto> tiposProductos = objDao.getAll(TipoProducto.class, "tipos_productos");

            // Validamos si existen registros
            if (tiposProductos.isEmpty()) {
                return new ResponseProvider(false, 404, "No hay tipos de productos registrados", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Tipos de productos obtenidos correctamente", tiposProductos, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los tipos de productos", e, null).toResponse();
        }
    }

    /**
     * Busca un tipo de producto por su ID.
     *
     * @param idTipo ID del tipo de producto
     * @return Response con el tipo de producto encontrado o mensaje de error
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTipoProductoById(@PathParam("id") int idTipo) {
        try {
            CrudDAO objDao = new CrudDAO();
            TipoProducto tipoProducto = objDao.getById(TipoProducto.class, "tipos_productos", idTipo);

            if (tipoProducto == null) {
                return new ResponseProvider(false, 404, "Tipo de producto no encontrado", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Tipo de producto obtenido correctamente", tipoProducto, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener el tipo de producto", e, null).toResponse();
        }
    }

    /**
     * Crea un nuevo tipo de producto.
     *
     * @param nuevoTipo Objeto con los datos del nuevo tipo de producto
     * @return Response indicando si se creó correctamente
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createTipoProducto(TipoProducto nuevoTipo) {
        try {
            CrudDAO objDao = new CrudDAO();
            TipoProducto tipoCreado = objDao.create("tipos_productos", nuevoTipo);

            if (tipoCreado == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar el tipo de producto", null, null).toResponse();
            }

            // Si todo sale bien, retornamos el tipo creado
            return new ResponseProvider(true, 201, "Tipo de producto registrado exitosamente", tipoCreado, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar el tipo de producto", e, null).toResponse();
        }
    }

    /**
     * Actualiza un tipo de producto existente.
     *
     * @param id ID del tipo de producto a actualizar
     * @param tipoActualizado Objeto con los datos nuevos
     * @return Response indicando si la actualización fue exitosa
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateTipoProducto(@PathParam("id") int id, TipoProducto tipoActualizado) {
        try {
            CrudDAO objDao = new CrudDAO();

            tipoActualizado.setId(id); // Asignamos el ID al objeto recibido

            // Validar si el ID es válido
            if (tipoActualizado.getId() == 0) {
                return new ResponseProvider(false, 400, "El ID del Tipo de producto es obligatorio para actualizar", null, null).toResponse();
            }

            // Verificamos si existe en la base de datos
            TipoProducto tipoExistente = objDao.getById(TipoProducto.class, "tipos_productos", tipoActualizado.getId());

            if (tipoExistente == null) {
                return new ResponseProvider(false, 404, "El tipo de producto con ese ID no existe", null, null).toResponse();
            }

            boolean actualizada = objDao.update(tipoActualizado, "tipos_productos", "id");

            if (!actualizada) {
                return new ResponseProvider(false, 400, "No se pudo actualizar el tipo de producto", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Tipo de producto actualizado exitosamente", tipoActualizado, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar el tipo de producto", e, null).toResponse();
        }
    }

    /**
     * Elimina un tipo de producto por su ID.
     *
     * @param id ID del tipo de producto a eliminar
     * @return Response indicando si se eliminó correctamente
     */
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteTipoProducto(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Verificar si el tipo de producto existe
            TipoProducto tipoExistente = objDao.getById(TipoProducto.class, "tipos_productos", id);
            if (tipoExistente == null) {
                return new ResponseProvider(false, 404, "El tipo de producto no existe", null, null).toResponse();
            }

            // Validamos si hay productos asociados a este tipo antes de eliminar
            List<Producto> productosAsociados = objDao.getAllByField(Producto.class, "productos", "id_tipo", tipoExistente.getId());

            if (!productosAsociados.isEmpty()) {
                return new ResponseProvider(false, 400, "El tipo tiene productos asociados", null, null).toResponse();
            }

            // Eliminamos el tipo de producto
            boolean eliminado = objDao.delete(id, "tipos_productos", "id");

            if (!eliminado) {
                return new ResponseProvider(false, 400, "No se pudo eliminar el tipo de producto", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Tipo de producto eliminado exitosamente", null, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al eliminar el tipo de producto", e, null).toResponse();
        }
    }
}
