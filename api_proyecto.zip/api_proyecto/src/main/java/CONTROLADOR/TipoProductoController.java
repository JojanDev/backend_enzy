/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.CrudDAO;
import MODELO.Producto;
import MODELO.TipoProducto;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 *
 * @author Propietario
 */
@Path("tipos-productos")
public class TipoProductoController {
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllTiposProductos() {
        try {
            final CrudDAO objDao = new CrudDAO();
            final List<TipoProducto> tiposProductos = objDao.getAll(TipoProducto.class, "tipos_productos");
            
            // Validamos si existen registros de tipos de documentos
            if (tiposProductos.isEmpty())
                return new ResponseProvider(false, 404, "No hay tipos de productos registrados", null, null).toResponse();

            return new ResponseProvider(true, 200, "Tipos de productos obtenidos correctamente", tiposProductos, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los tipos de productos", e, null).toResponse(); 
        }
    }
    
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTipoProductoById(@PathParam("id") int idTipo) {
        try {
            CrudDAO objDao = new CrudDAO();
            TipoProducto tipoProducto = objDao.getById(TipoProducto.class, "tipos_productos", idTipo);
                
            if (tipoProducto == null) {
                return new ResponseProvider(false, 404, "Tipo de producto no encontrado", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Tipo de producto obtenido correctamente", tipoProducto, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener el tipo de producto", e, null).toResponse(); 
        }
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createTipoProducto(TipoProducto nuevoTipo) {
        try {
            CrudDAO objDao = new CrudDAO();
            TipoProducto tipoCreado = objDao.create("tipos_productos", nuevoTipo);

            if (tipoCreado == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar el tipo de producto", null, null).toResponse();
            }
            
            return new ResponseProvider(true, 201, "Tipo de producto registrado exitosamente", tipoCreado, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar el antecedente", e, null).toResponse();
        }
    }
    
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateTipoProducto(@PathParam("id") int id, TipoProducto tipoActualizado ) {
        try {
            CrudDAO objDao = new CrudDAO();

            tipoActualizado.setId(id);
            // Validar si el ID está presente
            if (tipoActualizado.getId() == 0) {
                return new ResponseProvider(false, 400, "El ID del Tipo de producto es obligatorio para actualizar", null, null).toResponse();
            }

            // Verificar si la especie existe antes de actualizar
            TipoProducto tipoExistente = objDao.getById(TipoProducto.class, "tipos_productos", tipoActualizado.getId());

            if (tipoExistente == null) {
                return new ResponseProvider(false, 404, "El tipo de producto con ese ID no existe", null, null).toResponse();
            }

            boolean actualizada = objDao.update(tipoActualizado, "tipos_productos", "id");

            if (!actualizada) {
                return new ResponseProvider(false, 400, "No se pudo actualizar el tipo de producto", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Tipo de producto actualizado exitosamente", tipoActualizado, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar el tipo de producto", e, null).toResponse();
        }
    }
    
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteTipoProducto(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Verificar si el tipo de producto existe
            TipoProducto tipoExistente = objDao.getById(TipoProducto.class, "tipos_productos", id);
            if (tipoExistente == null) {
                return new ResponseProvider(false, 404, "El tipo de producto no existe", null, null).toResponse();
            }

            // Verificar si hay productos asociados a ese tipo
            List<Producto> productosAsociados = objDao.getAllByField(Producto.class, "productos", "id_tipo", tipoExistente.getId());

            if (!productosAsociados.isEmpty()) {
                return new ResponseProvider(false, 400, "El tipo tiene productos asociados", null, null).toResponse();
            }

            // Eliminar tipo de producto
            boolean eliminado = objDao.delete(id, "tipos_productos", "id");

            if (!eliminado) {
                return new ResponseProvider(false, 400, "No se pudo eliminar el tipo de producto", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Tipo de producto eliminado exitosamente", null, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al eliminar el tipo de producto", e, null).toResponse();
        }
    }
}
