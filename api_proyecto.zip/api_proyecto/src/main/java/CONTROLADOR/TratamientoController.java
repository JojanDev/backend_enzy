package CONTROLADOR;

import MODELO.DAO.TratamientoDAO;
import MODELO.ConexionBD;
import MODELO.DAO.CrudDAO;
import MODELO.Tratamiento;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.Connection;

/**
 * Controlador REST para gestionar los tratamientos asociados a los antecedentes.
 *
 * Permite obtener, crear, actualizar y eliminar tratamientos desde la base de datos.
 * Utiliza la clase CrudDAO para las operaciones CRUD genericas y un DAO especifico
 * para la eliminacion de tratamientos.
 *
 * Endpoints:
 *   GET    /tratamientos/{id}   obtiene un tratamiento por su ID
 *   POST   /tratamientos        crea un nuevo tratamiento
 *   PUT    /tratamientos/{id}   actualiza un tratamiento existente
 *   DELETE /tratamientos/{id}   elimina un tratamiento
 *
 */
@Path("tratamientos")
public class TratamientoController {


    /**
     * Obtiene un tratamiento por su ID.
     *
     * @param idTratamiento ID del tratamiento a buscar
     * @return Response con el tratamiento encontrado o mensaje de error si no
     * existe
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTratamientoById(@PathParam("id") int idTratamiento) {
        try {
            // crea instancia de CrudDAO para operaciones CRUD en la tabla de tratamientos
            CrudDAO objDao = new CrudDAO();

            // recupera el tratamiento de la tabla 'antecedentes_tratamientos' usando el ID
            Tratamiento tratamiento = objDao.getById(
                    Tratamiento.class,
                    "antecedentes_tratamientos",
                    idTratamiento
            );

            // si no se encuentra ningun registro, retorna 404 para indicar inexistencia
            if (tratamiento == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "Tratamiento no encontrado",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 con el objeto Tratamiento recuperado
            return new ResponseProvider(
                    true,
                    200,
                    "Tratamiento obtenido correctamente",
                    tratamiento,
                    null
            ).toResponse();

        } catch (Exception e) {
            // en caso de excepcion inesperada, retorna 500 con el detalle del error
            return new ResponseProvider(
                    false,
                    500,
                    "Error al obtener el tratamiento",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Crea un nuevo tratamiento y lo asocia a un antecedente.
     *
     * @param nuevoTratamieno Objeto Tratamiento con los datos a registrar
     * @return Response con el tratamiento creado o error en el registro
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createTratamiento(Tratamiento nuevoTratamieno) {
        try {
            // instancia CrudDAO para insertar el nuevo tratamiento
            CrudDAO objDao = new CrudDAO();

            // establece el tratamiento como activo por defecto al crearlo
            nuevoTratamieno.setActivo(true);

            // inserta en la tabla 'antecedentes_tratamientos' y obtiene entidad persistida
            Tratamiento tratamientoCreado = objDao.create(
                    "antecedentes_tratamientos",
                    nuevoTratamieno
            );

            // si create devuelve null, la insercion fallo y se retorna 400
            if (tratamientoCreado == null) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo registrar el tratamiento al antecedente",
                        null,
                        null
                ).toResponse();
            }

            // recarga desde BD para asegurar que todos campos (p.ej. IDs generados) esten completos
            Tratamiento antecedenteBD = objDao.getById(
                    Tratamiento.class,
                    "antecedentes_tratamientos",
                    tratamientoCreado.getId()
            );

            // retorna 201 con la entidad completa obtenida tras la creacion
            return new ResponseProvider(
                    true,
                    201,
                    "Tratamiento registrado exitosamente",
                    antecedenteBD,
                    null
            ).toResponse();

        } catch (Exception e) {
            // captura cualquier error interno y retorna 500 con detalle de excepcion
            return new ResponseProvider(
                    false,
                    500,
                    "Error al registrar el tratamiento",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Actualiza los datos de un tratamiento existente.
     *
     * @param idTratamiento ID del tratamiento a actualizar
     * @param tratamientoActualizado Objeto con los datos a modificar
     * @return Response con el tratamiento actualizado o error si no existe
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateTratamiento(
            @PathParam("id") int idTratamiento,
            Tratamiento tratamientoActualizado) {
        try {
            // instancia CrudDAO para operaciones de lectura y actualizacion
            CrudDAO objDao = new CrudDAO();

            // recupera desde BD la version actual para aplicar solo los cambios necesarios
            Tratamiento tratamientoBD = objDao.getById(
                    Tratamiento.class,
                    "antecedentes_tratamientos",
                    idTratamiento
            );
            // si no existe el registro, retorna 404 para indicar que no hay nada que actualizar
            if (tratamientoBD == null) {
                return new ResponseProvider(
                        false,
                        404,
                        "Tratamiento no encontrado",
                        null,
                        null
                ).toResponse();
            }

            // actualiza campo id_personal si viene modificado
            if (tratamientoActualizado.getId_personal() != 0
                    && tratamientoActualizado.getId_personal() != tratamientoBD.getId_personal()) {
                tratamientoBD.setId_personal(tratamientoActualizado.getId_personal());
            }

            // actualiza titulo solo si es distinto y no vacio
            if (tratamientoActualizado.getTitulo() != null
                    && !tratamientoActualizado.getTitulo().isEmpty()
                    && !tratamientoActualizado.getTitulo().equals(tratamientoBD.getTitulo())) {
                tratamientoBD.setTitulo(tratamientoActualizado.getTitulo());
            }

            // actualiza descripcion solo si es distinto y no vacio
            if (tratamientoActualizado.getDescripcion() != null
                    && !tratamientoActualizado.getDescripcion().isEmpty()
                    && !tratamientoActualizado.getDescripcion().equals(tratamientoBD.getDescripcion())) {
                tratamientoBD.setDescripcion(tratamientoActualizado.getDescripcion());
            }

            // ejecuta update para persistir los cambios en la tabla correspondiente
            boolean actualizado = objDao.update(
                    tratamientoBD,
                    "antecedentes_tratamientos",
                    "id"
            );
            // si update retorna false, la operacion fallo y devolvemos 400
            if (!actualizado) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo actualizar el tratamiento",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 con la entidad actualizada
            return new ResponseProvider(
                    true,
                    200,
                    "Tratamiento actualizado exitosamente",
                    tratamientoBD,
                    null
            ).toResponse();

        } catch (Exception e) {
            // manejo de excepciones imprevistas retornando 500 con info de error
            return new ResponseProvider(
                    false,
                    500,
                    "Error al actualizar el tratamiento",
                    e,
                    null
            ).toResponse();
        }
    }

    /**
     * Elimina un tratamiento por su ID.
     *
     * @param idTratamiento identificador unico del tratamiento a eliminar
     * @return Response indicando si se elimino correctamente o mensaje de error
     */
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response eliminarTratamiento(@PathParam("id") int idTratamiento) {
        try (Connection con = ConexionBD.conectar()) {
            // abre conexion a la base de datos
            TratamientoDAO dao = new TratamientoDAO(con);

            // realiza la eliminacion del tratamiento validando que no tenga medicamentos asociados
            boolean eliminado = dao.eliminarTratamiento(idTratamiento);

            // si la eliminacion fallo, retorna 400 con mensaje explicativo
            if (!eliminado) {
                return new ResponseProvider(
                        false,
                        400,
                        "No se pudo eliminar el tratamiento. Puede que tenga medicamentos asociados.",
                        null,
                        null
                ).toResponse();
            }

            // retorna 200 indicando exito en la eliminacion
            return new ResponseProvider(
                    true,
                    200,
                    "Tratamiento eliminado correctamente",
                    null,
                    null
            ).toResponse();

        } catch (Exception e) {
            // captura excepciones imprevistas y retorna 500 con detalle de error
            return new ResponseProvider(
                    false,
                    500,
                    "Error al intentar eliminar el tratamiento",
                    e,
                    null
            ).toResponse();
        }
    }

}
