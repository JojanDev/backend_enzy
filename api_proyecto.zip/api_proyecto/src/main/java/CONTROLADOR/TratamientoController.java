package CONTROLADOR;

import MODELO.DAO.TratamientoDAO;
import MODELO.ConexionBD;
import MODELO.DAO.CrudDAO;
import MODELO.Tratamiento;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.Connection;

/**
 * Controlador REST para gestionar los tratamientos asociados a los
 * antecedentes.
 *
 * Permite obtener, crear, actualizar y eliminar tratamientos desde la base de
 * datos. Utiliza la clase CrudDAO para las operaciones CRUD genéricas y un DAO
 * específico para la eliminación de tratamientos.
 *
 * @author USUARIO
 */
@Path("tratamientos")
public class TratamientoController {

    /**
     * Obtiene un tratamiento por su ID.
     *
     * @param idTratamiento ID del tratamiento a buscar
     * @return Respuesta con el tratamiento encontrado o mensaje de error
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTratamientoById(@PathParam("id") int idTratamiento) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Se busca el tratamiento en la tabla "antecedentes_tratamientos"
            Tratamiento tratamiento = objDao.getById(Tratamiento.class, "antecedentes_tratamientos", idTratamiento);

            if (tratamiento == null) {
                return new ResponseProvider(false, 404, "Tratamiento no encontrado", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Tratamiento obtenido correctamente", tratamiento, null).toResponse();
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener el tratamiento", e, null).toResponse();
        }
    }

    /**
     * Crea un nuevo tratamiento y lo asocia a un antecedente.
     *
     * @param nuevoTratamieno Objeto Tratamiento con los datos a registrar
     * @return Respuesta con el tratamiento creado o error en el registro
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createTratamiento(Tratamiento nuevoTratamieno) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Todo tratamiento nuevo se registra como activo
            nuevoTratamieno.setActivo(true);

            // Se inserta en la tabla correspondiente
            Tratamiento tratamientoCreado = objDao.create("antecedentes_tratamientos", nuevoTratamieno);

            if (tratamientoCreado == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar el tratamiento al antecedente", null, null).toResponse();
            }

            // Se vuelve a consultar desde la BD para obtener los datos completos
            Tratamiento antecedenteBD = objDao.getById(Tratamiento.class, "antecedentes_tratamientos", tratamientoCreado.getId());

            return new ResponseProvider(true, 201, "Tratamiento registrado exitosamente", antecedenteBD, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar el tratamiento", e, null).toResponse();
        }
    }

    /**
     * Actualiza los datos de un tratamiento existente.
     *
     * @param idTratamiento ID del tratamiento a actualizar
     * @param tratamientoActualizado Objeto con los datos a modificar
     * @return Respuesta con el tratamiento actualizado o error si no existe
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateTratamiento(@PathParam("id") int idTratamiento, Tratamiento tratamientoActualizado) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Se consulta el tratamiento en la base de datos
            Tratamiento tratamientoBD = objDao.getById(Tratamiento.class, "antecedentes_tratamientos", idTratamiento);
            if (tratamientoBD == null) {
                return new ResponseProvider(false, 404, "Tratamiento no encontrado", null, null).toResponse();
            }

            // Se actualizan solo los campos modificados
            if (tratamientoActualizado.getId_personal() != 0 && tratamientoActualizado.getId_personal() != tratamientoBD.getId_personal()) {
                tratamientoBD.setId_personal(tratamientoActualizado.getId_personal());
            }

            if (tratamientoActualizado.getTitulo() != null && !tratamientoActualizado.getTitulo().isEmpty()
                    && !tratamientoActualizado.getTitulo().equals(tratamientoBD.getTitulo())) {
                tratamientoBD.setTitulo(tratamientoActualizado.getTitulo());
            }

            if (tratamientoActualizado.getDescripcion() != null && !tratamientoActualizado.getDescripcion().isEmpty()
                    && !tratamientoActualizado.getDescripcion().equals(tratamientoBD.getDescripcion())) {
                tratamientoBD.setDescripcion(tratamientoActualizado.getDescripcion());
            }

            // Se ejecuta la actualización en la base de datos
            boolean actualizado = objDao.update(tratamientoBD, "antecedentes_tratamientos", "id");
            if (!actualizado) {
                return new ResponseProvider(false, 400, "No se pudo actualizar el tratamiento", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Tratamiento actualizado exitosamente", tratamientoBD, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar el tratamiento", e, null).toResponse();
        }
    }

    /**
     * Elimina un tratamiento por su ID.
     *
     * @param idTratamiento ID del tratamiento a eliminar
     * @return Respuesta indicando si se eliminó correctamente o no
     */
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response eliminarTratamiento(@PathParam("id") int idTratamiento) {
        try (Connection con = ConexionBD.conectar()) {
            TratamientoDAO dao = new TratamientoDAO(con);

            // Se elimina el tratamiento, verificando si no tiene medicamentos asociados
            boolean eliminado = dao.eliminarTratamiento(idTratamiento);

            if (!eliminado) {
                return new ResponseProvider(false, 400, "No se pudo eliminar el tratamiento. Puede que tenga medicamentos asociados.", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Tratamiento eliminado correctamente", null, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al intentar eliminar el tratamiento", e, null).toResponse();
        }
    }
}
