/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.CrudDAO;
import MODELO.Tratamiento;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 *
 * @author USUARIO
 */
@Path("tratamientos")
public class TratamientoController {
        
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTratamientoById(@PathParam("id") int idTratamiento) {
        try {
            CrudDAO objDao = new CrudDAO();
            Tratamiento tratamiento = objDao.getById(Tratamiento.class, "antecedentes_tratamientos", idTratamiento);
                
     
            if (tratamiento == null) {
                return new ResponseProvider(false, 404, "Tratamiento no encontrado", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Tratamiento obtenido correctamente", tratamiento, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener el tratamiento", e, null).toResponse(); 
        }
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createAntecedente(Tratamiento nuevoTratamieno) {
        try {
            CrudDAO objDao = new CrudDAO();
            Tratamiento tratamientoCreado = objDao.create(Tratamiento.class, "antecedentes_tratamientos", nuevoTratamieno);

            if (tratamientoCreado == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar el tratamiento al antecedente", null, null).toResponse();
            }           
            
            Tratamiento antecedenteBD = objDao.getById(Tratamiento.class, "antecedentes_tratamientos", tratamientoCreado.getId());

            return new ResponseProvider(true, 201, "Tratamiento registrado exitosamente", antecedenteBD, null).toResponse();
            
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar el tratamiento", e, null).toResponse();
        }
    }
}
