package CONTROLADOR; // Paquete donde se encuentra esta clase

// Importación de filtros y anotaciones de Jakarta para REST
import jakarta.ws.rs.container.ContainerRequestContext;  // Contexto de la solicitud
import jakarta.ws.rs.container.ContainerResponseContext; // Contexto de la respuesta
import jakarta.ws.rs.container.ContainerResponseFilter;  // Interfaz para filtrar respuestas
import jakarta.ws.rs.ext.Provider;                       // Marca la clase como proveedor

import java.io.IOException; // Excepción que puede lanzar el método filter

// Anotación que indica que esta clase se usa como filtro en todas las respuestas
@Provider
public class CorsFilter implements ContainerResponseFilter {

    // Método que se ejecuta automáticamente en cada respuesta del backend
    @Override
    public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext) throws IOException {
        // Permite que cualquier origen (dominio) acceda al backend
        responseContext.getHeaders().add("Access-Control-Allow-Origin", "*");

        // Permite que se usen estas cabeceras en la solicitud (como JSON, autorización, etc.)
        responseContext.getHeaders().add("Access-Control-Allow-Headers", "origin, content-type, accept, authorization");

        // Permite estos métodos HTTP desde el frontend
        responseContext.getHeaders().add("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD");
    }
}
