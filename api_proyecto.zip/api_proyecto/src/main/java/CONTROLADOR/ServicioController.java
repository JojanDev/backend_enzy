/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CONTROLADOR;

import MODELO.CrudDAO;
import MODELO.DetalleVenta;
import MODELO.Producto;
import MODELO.Servicio;
import MODELO.TipoProducto;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 *
 * @author USUARIO
 */

@Path("servicios")
public class ServicioController {
 
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllServicios() {
        try {
            final CrudDAO objDao = new CrudDAO();
            final List<Servicio> servicios = objDao.getAll(Servicio.class, "servicios");
            
            // Validamos si existen registros de tipos de documentos
            if (servicios.isEmpty())
                return new ResponseProvider(false, 404, "No hay servicios registrados", null, null).toResponse();

            return new ResponseProvider(true, 200, "Servicios obtenidos correctamente", servicios, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener los servicios", e, null).toResponse(); 
        }
    }
    
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getServiceById(@PathParam("id") int idServicio) {
        try {
            CrudDAO objDao = new CrudDAO();
            Servicio servicio = objDao.getById(Servicio.class, "servicios", idServicio);
                
            if (servicio == null) {
                return new ResponseProvider(false, 404, "Servicio no encontrado", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Servicio obtenido correctamente", servicio, null).toResponse(); 
        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al obtener el servicio", e, null).toResponse(); 
        }
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createServicio(Servicio nuevoServicio) {
        try {
            CrudDAO objDao = new CrudDAO();
            Servicio servicioCreado = objDao.create("servicios", nuevoServicio);

            if (servicioCreado == null) {
                return new ResponseProvider(false, 400, "No se pudo registrar el servicio", null, null).toResponse();
            }
            
            return new ResponseProvider(true, 201, "Servicio registrado exitosamente", servicioCreado, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al registrar el antecedente", e, null).toResponse();
        }
    }
    
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateServicio(@PathParam("id") int id, Servicio servicioActualizado ) {
        try {
            CrudDAO objDao = new CrudDAO();

            servicioActualizado.setId(id);
            // Validar si el ID está presente
            if (servicioActualizado.getId() == 0) {
                return new ResponseProvider(false, 400, "El ID del Servicio es obligatorio para actualizar", null, null).toResponse();
            }

            Servicio servicioExistente = objDao.getById(Servicio.class, "servicios", servicioActualizado.getId());

            if (servicioExistente == null) {
                return new ResponseProvider(false, 404, "El servicio con ese ID no existe", null, null).toResponse();
            }

            boolean actualizada = objDao.update(servicioActualizado, "servicios", "id");

            if (!actualizada) {
                return new ResponseProvider(false, 400, "No se pudo actualizar el servicio", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Servicio actualizado exitosamente", servicioActualizado, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al actualizar el servicio", e, null).toResponse();
        }
    }
    
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteServicio(@PathParam("id") int id) {
        try {
            CrudDAO objDao = new CrudDAO();

            // Verificar si el tipo de producto existe
            Servicio servicioExistente = objDao.getById(Servicio.class, "servicios", id);
            
            if (servicioExistente == null) {
                return new ResponseProvider(false, 404, "El servicio no existe", null, null).toResponse();
            }

            List<DetalleVenta> detallesVentasAsocidas = objDao.getAllByField(DetalleVenta.class, "detalles_ventas", "id_servicio", servicioExistente.getId());

            if (!detallesVentasAsocidas.isEmpty()) {
                return new ResponseProvider(false, 400, "El servicio tiene detalles de ventas asociadas", null, null).toResponse();
            }

            // Eliminar tipo de producto
            boolean eliminado = objDao.delete(id, "servicios", "id");

            if (!eliminado) {
                return new ResponseProvider(false, 400, "No se pudo eliminar el servicio", null, null).toResponse();
            }

            return new ResponseProvider(true, 200, "Servicio eliminado exitosamente", null, null).toResponse();

        } catch (Exception e) {
            return new ResponseProvider(false, 500, "Error al eliminar el servicio", e, null).toResponse();
        }
    }
}
